# specs/070-reproducibility.md

## Purpose
재현성 보장.

## Requirements
- seed 고정 옵션 제공
- deterministic 모드 제공(성능 저하 허용)
- git sha + config hash를 모든 로그에 기록

## Acceptance Tests
- deterministic 모드에서 같은 입력에 같은 출력(허용 오차 내)이 나온다.
