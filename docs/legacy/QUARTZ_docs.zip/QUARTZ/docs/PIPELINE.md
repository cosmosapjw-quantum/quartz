# QUARTZ Detailed Pipeline

## 1) 목표
- 학습/데이터 생성은 (가능하면) GPU에서 “빡세게”
- 실행/대국/평가는 소비자 CPU에서 “가볍게”
- baseline과 QUARTZ를 **완전히 동일 조건**으로 돌려 Elo 차이를 측정
- 커리큘럼을 stage gate로 통제(통과해야만 다음 게임/보드로 이동)

---

## 2) 파이프라인 단계(표준: CPU 엔진 + GPU 학습)

### 단계 A: Self-Play Data Generation (Linux, CPU 엔진)
입력: 현재 모델(teacher 또는 student)  
출력: 게임 trajectory

- 각 게임에서 MCTS로 π_target(방문 분포)을 만들고, 엔진으로 착수
- 게임 종료 후 결과 z를 전체 step에 전파
- 저장 스키마(권장):
  - `state` (canonical tensor)
  - `pi_target` (sparse 가능, top-k 권장)
  - `z` (win/loss/draw)
  - `meta`: move_idx, player, time_used_ms, sims, root_value, root_entropy, difficulty_bucket

병렬화:
- “게임 단위”는 프로세스로 병렬 (GIL/락 영향 최소)
- “게임 내부 MCTS”는 스레드 병렬
- leaf inference는 (선택) GPU 배치 서버로 모아서 처리(3090 1장에서도 효과 큼)

### 단계 B: Replay Buffer / Dataset
- on-disk + in-memory 캐시 혼합(파일 수 폭발 방지)
- 균형:
  - 최신 데이터 가중(learning agility)
  - 오래된 데이터 일부 유지(망각 방지)
- stage별로 데이터/모델을 분리 관리(“단계 오염” 방지)

### 단계 C: Training (GPU)
- PyTorch로 학습
- loss:
  - policy: KL(π_target || π_pred) 또는 cross-entropy
  - value: MSE(v_pred, z)
  - regularization: L2, entropy(선택)
- 체크포인트:
  - 최근 N개 보관 + best(평가로 선정)
- export:
  - CPU 런타임이 받는 형태(ONNX 또는 TorchScript)

### 단계 D: Distillation (Teacher → Student, 선택이지만 강력 권장)
- teacher 체크포인트를 고정하고
- student를 “CPU 배포 조건(작은 모델/짧은 탐색 예산)”에 맞춰 학습
- 목표:
  - CPU-only에서도 Elo가 유지/상승
  - latency(ONNX) 목표를 만족

계약: `specs/085-distillation.md`

### 단계 E: CPU Runtime Packaging
- NN 추론:
  - ONNXRuntime(oneDNN) 권장 (CPU에 강함)
- 엔진/핫루프:
  - pybind11 + (필요시) C++ MCTS core
- 빌드 타깃:
  - AVX2 최소
  - Intel/AMD 자동 감지(런타임 플래그)

### 단계 F: Evaluation (Stage Gate)
1) 내부 평가(필수):
- baseline vs candidate match (예: 200~1000 games)
- 고정 opening set, 색상 스왑, seed 고정
- Elo 계산 + 신뢰구간(CI)
- 시간 분포(쉬움/평균/어려움) 만족 여부 자동 판정

2) 외부 평가(선택):
- Gomocup Manager 토너먼트

---

## 3) 파이프라인 변형: “완전 GPU teacher”(mctx/JAX) 경로(옵션)
목표: **교사 데이터 생성 속도/효율**을 최대화하고 싶을 때.

- 아이디어:
  - 환경(게임 룰) + MCTS + NN forward를 모두 가속기 친화적으로 구성
  - 큰 배치로 한 번에 많은 self-play를 생성
- 장점:
  - teacher 부팅(초기 강한 정책 확보)이 빨라질 수 있다.
- 단점/리스크:
  - CPU 엔진(배포/평가)과 탐색 분포가 달라져 “정렬(추가학습)”이 필수
  - 게임 환경을 JAX로 옮기는 비용이 크며, correctness 테스트가 꼭 필요

권장 운영:
- teacher만 이 경로로 만들고,
- distillation + 소량 CPU self-play로 student를 배포 분포에 맞춘다.

---

## 4) “공정 비교”를 보장하는 실험 프로토콜
- baseline과 QUARTZ는 동일:
  - 같은 executable, 같은 NN, 같은 TT, 같은 스레드 수, 같은 time budget policy
- QUARTZ vs baseline 차이는 오직:
  - `SearchController` 교체(모듈 ON/OFF)

---

## 5) 실험 산출물(Artifacts)
- 모델 체크포인트(teacher/student)
- export 모델(실행, ONNX)
- self-play 데이터(stage별 폴더)
- match 로그(JSONL)
- KPI 대시보드(그래프)
- stage gate 리포트(통과/실패 이유 1페이지)

---

## 6) “다음 단계로 넘어가기”의 최소 조건(요약)
정의는 `specs/090-curriculum.md`를 따른다. 요약만 적으면:

- 기능: acceptance tests 통과(엔진/NN/export)
- 시간: 분포 목표를 안정적으로 만족
- 성능: baseline 대비 Elo가 의미 있게 상승(또는 최소 비열화)
