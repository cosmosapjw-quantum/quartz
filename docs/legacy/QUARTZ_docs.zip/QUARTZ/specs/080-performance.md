# specs/080-performance.md

## Purpose
성능 목표/측정 기준을 spec으로 고정.

---

## Targets (v0)
- CPU-only runtime(평가/배포 기준)
- “시간 분포”가 안정적으로 유지되어야 한다(쉬운/평균/어려움)
  - 기본 목표:
    - 쉬운 수 p50 ≤ 0.5s
    - 전체 mean ≤ 5s
    - 어려운 수(상위 구간) mean ≤ 15s
    - 최악 p99 ≤ 30s cap
- 로그에 nps/eval/sec/time histogram 기록

---

## Non-Goals
- v0에서 19x19 바둑 CPU-only “강한 엔진”은 목표 밖(가능성 실험만).

---

## Acceptance Tests
- 8 threads 기준, 동일 하드웨어에서 baseline이 “시간 초과/크래시” 없이 100게임을 완주한다.
- p99 move_time이 cap(30s)을 넘지 않는다.
- stage별 기본 예산(예: mean 5s)에서 “분포가 붕괴”(대량 타임아웃/스파이크)하지 않는다.
