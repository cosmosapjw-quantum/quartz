# specs/090-curriculum.md

## Purpose
프로젝트 커리큘럼(게임/보드 크기 확장 순서)과 “단계별 승격 조건(stage gate)”을 계약으로 고정한다.  
목표는 **쉬운 게임부터 CPU-only 엔진이 속도/안정성/Elo를 만족하는지 확인하면서** 단계적으로 확장하는 것.

---

## Global Defaults
### Time Budget Policy (default)
- easy: p50 ≤ 0.5s
- overall mean ≤ 5s
- hard(bucket 상위): mean ≤ 15s
- cap: p99 ≤ 30s

난이도 버킷은 config로 정의(예: root entropy 임계값)하고, 항상 로그에 남긴다.

### Minimum Match Size
- Gate-Lite: 200 games
- Gate-Strict: 400 games (가능하면), 최소 200

### Stability
- crash_count = 0
- timeout_count = 0
- illegal_move_count = 0

---

## Stage List (Order is normative)
### S0: TicTacToe
- stage_id: `ttt`
- 목적: 파이프라인/재현성/평가 자동화
- Gate-Strict:
  - 충분한 예산(>=0.2s)에서 최적 수 선택(테스트 케이스 세트 통과)

### S1: Gomoku 9×9
- stage_id: `gomoku9`
- 추천 모델:
  - teacher: Teacher-S
  - student: Student-S
- Gate-Strict:
  - QUARTZ ON/OFF 비교에서 ΔElo > 0 (권장: CI 하한도 > 0)
  - time distribution 목표 만족(특히 easy p50)

### S2: Gomoku 13×13
- stage_id: `gomoku13`
- 추천 모델:
  - teacher: Teacher-M (또는 Teacher-S 전이)
  - student: Student-S
- Gate-Strict:
  - QUARTZ ON/OFF ΔElo > 0
  - 전이(fine-tune) 실험을 최소 1회 수행하고 결과를 기록(from-scratch 대비 시간/효율)

### S3: Gomoku 15×15
- stage_id: `gomoku15`
- 추천 모델:
  - teacher: Teacher-M (필요 시 Teacher-L)
  - student: Student-S (필요 시 quant)
- Gate-Strict:
  - QUARTZ ON/OFF ΔElo > 0
  - 고정 opening set + 색상 스왑 프로토콜 준수

### S4: Renju 15×15
- stage_id: `renju15`
- Gate-Strict:
  - 불법수(금수) = 0
  - QUARTZ ON/OFF ΔElo > 0 (또는 최소 비열화 없음 + 안정적 시간 분포)

### S5: Chess + Chess960 (Feasibility Only)
- stage_id: `chess`
- stage_id2: `chess960`
- 목표: “아마추어 수준 가능성”만 탐색
- Gate-Lite+:
  - 안정성/시간 분포 통과
  - QUARTZ ON/OFF 최소 비열화 없음(명백한 퇴행이면 실패)
  - 외부 강자와의 정면 benchmark는 요구하지 않음(스모크만)

### S6: Go 9×9
- stage_id: `go9`
- 추천 모델:
  - teacher: Teacher-L(또는 M + gpool 강화)
  - student: Student-S
- Gate-Strict(현실적으로 완화 가능):
  - 안정성/시간 분포 통과
  - baseline 대비 QUARTZ가 최소 비열화하지 않음
  - (선택) teacher→student distill 후에도 성능이 유지되는지 보고

### S7: Go 19×19 (Feasibility Only)
- stage_id: `go19`
- Gate-Lite:
  - 파이프라인이 돌아간다(학습 신호, 크래시 0)
  - 시간 cap 준수
  - “가능성” 결론을 남긴다(현실적인 compute 요구 추정 포함)

---

## Stage Gate Output (normative)
stage gate는 반드시 아래를 산출해야 한다.
- `verdict`: PASS/FAIL
- `reasons`: 실패/보류 이유(최대 5개)
- `elo_delta` + `ci`
- `time_summary`: p50/mean/p95/p99 + bucket별 mean
- `stability_summary`: crash/timeout/illegal_move
- `artifacts`: 모델/로그/설정 해시 목록
