"""QUARTZ training module — re-exports from standalone alphazero_train.py.

This avoids maintaining two copies of the training code.
For standalone use: python python/alphazero_train.py
For pip-installed use: quartz-train (pyproject.toml entry point)
"""
import importlib.util
import os
import sys

# Load the standalone module dynamically to avoid circular imports
_standalone = os.path.join(os.path.dirname(__file__), '..', 'python', 'alphazero_train.py')
if not os.path.exists(_standalone):
    # pip-installed: alphazero_train.py is co-located
    _standalone = os.path.join(os.path.dirname(__file__), 'alphazero_train.py')

if os.path.exists(_standalone):
    spec = importlib.util.spec_from_file_location("alphazero_train", _standalone)
    _mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(_mod)
    # Re-export key names
    main = _mod.main
    AlphaZeroNet = _mod.AlphaZeroNet
    TreeMCTS = _mod.TreeMCTS
    ReplayBuffer = _mod.ReplayBuffer
    SelfPlayWorker = _mod.SelfPlayWorker
else:
    def main():
        print("ERROR: alphazero_train.py not found. Run from project root.")
        sys.exit(1)

if __name__ == "__main__":
    main()
