# specs/050-training.md

## Purpose
훈련(teacher)과 distillation(student)을 포함한 학습 파이프라인의 계약.

---

## Inputs
- replay dataset(records) from `specs/040-selfplay.md`

## Outputs
- checkpoint (teacher 또는 student)
- exported model (cpu runtime; ONNX/TS)

---

## Training Modes
### Mode T: Teacher Training (self-play 강화학습)
- loss:
  - policy: KL(π_target || π_pred) 또는 cross-entropy
  - value: MSE(v_pred, z)
  - reg: L2 (필수)
- 목적:
  - 빠르게 “쓸만한 교사”를 만들고, 데이터 품질을 끌어올린다.

### Mode S: Student Distillation (teacher→student)
- loss(기본):
  - policy: KL(soft_teacher || student_pred)  (temperature 사용 가능)
  - value: MSE(v_student, v_teacher) 또는 MSE(v_student, z)
  - reg: L2
- 추가(선택):
  - student를 “CPU 배포 분포”에 맞추기 위한 짧은 self-play fine-tune
- 계약 상세: `specs/085-distillation.md`

---

## Evaluation Gate
- 새 체크포인트는 내부 평가에서 baseline 대비 성능이 떨어지면 “승격”하지 않는다(옵션: arena).
- student 체크포인트는 다음을 동시에 만족해야 승격한다:
  - (성능) teacher 대비 지나치게 무너지지 않음(목표는 stage별로)
  - (속도) CPU microbench latency 목표 만족(ONNX)

---

## Acceptance Tests
- 1 epoch 학습이 NaN 없이 끝난다.
- checkpoint 로딩/저장 호환.
- export 후 CPU inference smoke test 통과.
- distillation 모드에서도 동일한 스모크/저장/로드 테스트가 통과한다.
