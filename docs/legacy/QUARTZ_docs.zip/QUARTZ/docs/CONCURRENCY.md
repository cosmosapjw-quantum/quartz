# Concurrency & Locking Design (Baseline)

이 문서는 baseline MCTS를 “멀티스레드 합산 5초/수”에서 안정적으로 돌리기 위한 설계를 고정한다.  
QUARTZ 모듈은 여기 위에서만 바뀐다(스케줄러/할당 정책).

---

## 1) 목표/제약
- 스레드 수: N threads (CPU 코어 수 기반)
- 공유:
  - 하나의 SearchTree
  - 하나의 TranspositionTable(TT)
- lock contention 최소화
- 재현성 모드 제공(속도 ↓ 가능)

---

## 2) 핵심 자료구조
### 2.1 NodeStats (state node)
- `N`: int (atomic)
- `W`: float (atomic add or lock)
- `Q`: float (derived or cached)
- `children`: map(move → edge_id) (확장 시점에만 수정)
- `expanded_flag`: atomic bool

### 2.2 EdgeStats (state-action edge)
- `Nsa`, `Wsa`, `Qsa`, `Psa`
- `virtual_loss`: int/float (atomic)

### 2.3 TT Entry
- `key` (64-bit)
- `node_id`
- `depth` or `age`
- collision policy: (예) always-replace or depth-prefer

---

## 3) 동시성 패턴
### 3.1 Selection (락 최소)
- 읽기 위주
- child stats는 atomic으로 읽음
- virtual loss는 선택한 edge에 atomic increment

### 3.2 Expansion (exactly-once)
- leaf에서 `expanded_flag`를 CAS로 올림
- 성공한 1개 스레드만:
  - legal moves 생성
  - NN inference 요청/대기
  - children 생성/연결

다른 스레드는:
- 같은 노드를 다시 만나면 expanded 완료될 때까지 “짧게” 대기하거나
- 다른 경로로 돌아가도록 selection에서 자연 분기

### 3.3 Backup
- 경로의 edge stats에
  - virtual loss 제거
  - N/W 업데이트
- 업데이트는 per-edge lock or atomic add
  - float atomic은 플랫폼 따라 구현 난이도 있음 → C++쪽에서 처리 추천

---

## 4) TT 동시성
### 4.1 버킷 락(lock striping)
- 해시 테이블을 B개 버킷으로 나누고
- 삽입/갱신은 해당 버킷만 락
- 조회는 락 없이 읽고(optimistic), 충돌 시 락 잡고 재검증

### 4.2 왜 TT는 shared가 필수냐
- 같은 상태가 여러 경로에서 재사용되면
  - search 효율이 급상승
  - 특히 오목/체스에서 강함
- QUARTZ의 geometry/curvature 모듈도 TT가 있으면 더 강해질 여지가 큼(나중 얘기)

---

## 5) Python free-threading vs C++
- Python free-threading(= no-GIL) 빌드를 쓰면
  - “파이썬 레벨 CPU 연산”도 멀티스레드로 병렬 가능
- 하지만 MCTS의 핫루프는:
  - 많은 작은 연산 + 락/원자 업데이트
  - 파이썬 객체 접근 비용이 큼
→ 결국 핵심 루프는 C++로 가는 게 유리할 가능성이 높다.

(세부 기준은 `docs/CPU_PERF.md`)

