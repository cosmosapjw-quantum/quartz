//! MctsEngine (v0.4) — QUARTZ 통합

pub mod backup;
pub mod eval;
pub mod expand;
pub mod gvoc;
pub mod mod_types;
pub mod node;
pub mod parallel;
pub mod quartz;
pub mod rng;
pub mod root;
pub mod search;
pub mod select;
pub mod tt;

pub use mod_types::PwConfig;
pub use quartz::{QuartzConfig, QuartzController, QuartzStats, compute_quartz_stats, RunningMedian};

use std::sync::Arc;
use std::sync::atomic::Ordering;
use std::time::Instant;

use crate::game::{Evaluator, GameState};
use crate::mcts::backup::backprop;
use crate::mcts::expand::expand_and_evaluate;
use crate::mcts::gvoc::{GvocConfig, GvocState, ProposalMode, routing_mode};
use crate::mcts::node::{atomic_f64_load, MctsNode};
use crate::mcts::root::{
    compute_dirichlet_noise, select_move_with_temperature,
    visit_distribution, DirichletConfig,
};
use crate::mcts::search::{root_entropy, SearchController, SearchStats, StopReason};
use crate::mcts::select::select;
use crate::mcts::tt::TranspositionTable;

// ─────────────────────────────────────────────
// § MctsConfig
// ─────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct MctsConfig {
    pub c_puct:       f32,
    pub pw:           Option<PwConfig>,
    pub dirichlet:    Option<DirichletConfig>,
    pub temperature:  f32,
    pub max_depth:    usize,
    pub max_tt_size:  Option<usize>,
    /// QUARTZ EFT-PUCT + 적응적 정지
    pub quartz:       Option<QuartzConfig>,
    /// GVOC 동적 PW 스케줄러 (None = 비활성)
    pub gvoc:         Option<GvocConfig>,
    /// 재현성 시드 (None = 비결정적)
    pub seed:         Option<u64>,
    /// Virtual loss mode (Fixed=baseline, Adaptive=σ_Q-scaled, Disabled=no VL)
    pub vl_mode:      parallel::VlMode,
}

impl Default for MctsConfig {
    fn default() -> Self {
        MctsConfig {
            c_puct:       2.0,
            pw:           None,
            dirichlet:    None,
            temperature:  0.0,
            max_depth:    0,
            max_tt_size:  None,
            quartz:       None,
            gvoc:         None,
            seed:         None,
            vl_mode:      parallel::VlMode::Adaptive,
        }
    }
}

impl MctsConfig {
    pub fn evaluation(c_puct: f32) -> Self {
        MctsConfig { c_puct, ..Default::default() }
    }

    pub fn evaluation_with_pw(c_puct: f32, pw: PwConfig) -> Self {
        MctsConfig { c_puct, pw: Some(pw), max_depth: 25, ..Default::default() }
    }

    pub fn stress(c_puct: f32, pw: PwConfig, max_tt: usize) -> Self {
        MctsConfig {
            c_puct,
            pw:          Some(pw),
            max_depth:   25,
            max_tt_size: Some(max_tt),
            ..Default::default()
        }
    }

    /// QUARTZ 활성화
    pub fn with_quartz(mut self, qcfg: QuartzConfig) -> Self {
        self.quartz = Some(qcfg);
        self
    }

    /// GVOC 활성화
    pub fn with_gvoc(mut self, gcfg: GvocConfig) -> Self {
        self.gvoc = Some(gcfg);
        self
    }

    /// 재현성 시드 설정
    pub fn with_seed(mut self, seed: u64) -> Self {
        self.seed = Some(seed);
        self
    }
}

// ─────────────────────────────────────────────
// § MctsEngine
// ─────────────────────────────────────────────

pub struct MctsEngine<G: GameState> {
    pub root:       Arc<MctsNode<G::Move>>,
    root_state:     G,
    evaluator:      Arc<dyn Evaluator<G> + Send + Sync>,
    pub tt:         Arc<TranspositionTable<G::Move>>,
    pub config:     MctsConfig,
    root_noise:     Option<Vec<f32>>,
    /// 현재 QUARTZ 통계 (EFT-PUCT에 사용)
    pub(crate) quartz_cache:   std::sync::RwLock<Option<QuartzStats>>,
    /// Parallelism controller (adaptive VL, telemetry)
    pub par_ctrl: parallel::ParallelismController,
}

impl<G: GameState> MctsEngine<G> {
    pub fn new(
        root_state: G,
        evaluator:  Arc<dyn Evaluator<G> + Send + Sync>,
        config:     MctsConfig,
    ) -> Self {
        let tt   = Arc::new(TranspositionTable::new());
        let hash = root_state.hash();
        let tv   = if root_state.is_terminal() { Some(root_state.outcome()) } else { None };
        let root = tt.get_or_create(hash, tv);

        let mut engine = MctsEngine {
            root, root_state, evaluator, tt,
            par_ctrl: parallel::ParallelismController::new(config.vl_mode, 1),
            config,
            root_noise:   None,
            quartz_cache: std::sync::RwLock::new(None),
        };
        engine.expand_root();
        engine
    }

    fn expand_root(&mut self) {
        if !self.root.is_expanded() {
            expand_and_evaluate(
                &self.root, &self.root_state,
                self.evaluator.as_ref(), &self.tt,
                self.config.pw.as_ref(),
            );
        }
        if let Some(dir) = &self.config.dirichlet {
            let edges = self.root.edge_snapshot(self.root.materialized_count());
            if !edges.is_empty() {
                let priors: Vec<f32> = edges.iter().map(|e| e.p).collect();
                self.root_noise = Some(compute_dirichlet_noise(edges.len(), &priors, dir));
            }
        }
    }

    /// QUARTZ 통계 갱신 (QuartzController와 협력)
    /// QUARTZ 통계 갱신 (priors=None → 균등 prior 가정)
    pub fn refresh_quartz_stats(&self) {
        self.refresh_quartz_stats_with_priors(None);
    }

    pub fn refresh_quartz_stats_with_priors(&self, priors: Option<&[f32]>) {
        if self.config.quartz.is_some() {
            // QuartzController 없이 직접 캐시 갱신할 때의 임시 경로
            // run_quartz/run_gvoc 사용 시에는 ctrl.update_stats가 처리함
            // 여기서는 QuartzStats 타입 호환을 위한 최소 통계만 생성
            let n_mat = self.root.materialized_count();
            let edges = self.root.edge_snapshot(n_mat);
            let n_total = self.root.n_total.load(Ordering::Acquire);
            if !edges.is_empty() && n_total > 10 {
                // 임시 EMA (상태 없음 — run_quartz 경로 권장)
                let mut s0 = RunningMedian::new(0.05);
                let mut ce = RunningMedian::new(0.1);
                let qcfg   = self.config.quartz.as_ref().unwrap();
                let stats  = compute_quartz_stats(&self.root, priors, &mut s0, 0.0, 0, 0, qcfg);
                *self.quartz_cache.write().unwrap() = Some(stats);
            }
        }
    }

    pub fn current_quartz_stats(&self) -> Option<QuartzStats> {
        self.quartz_cache.read().unwrap().clone()
    }

    /// Update ParallelismController from QUARTZ stats + root visit entropy.
    /// One-way coupling: par_ctrl reads from QUARTZ, never writes.
    fn refresh_par_ctrl(&self) {
        // σ_Q from QUARTZ
        let sigma_q = self.quartz_cache.read().unwrap()
            .as_ref()
            .map(|s| s.hbar_eff * self.config.quartz.as_ref().map_or(0.3, |q| q.sigma_0))
            .unwrap_or(0.3);
        // Root visit entropy
        let edges = self.root.edge_snapshot(self.root.materialized_count());
        let total: f32 = edges.iter().map(|e| e.n.load(Ordering::Relaxed) as f32).sum();
        let root_entropy = if total > 1.0 {
            edges.iter()
                .map(|e| { let p = e.n.load(Ordering::Relaxed) as f32 / total;
                           if p > 1e-8 { -p * p.ln() } else { 0.0 } })
                .sum::<f32>()
        } else { 1.0 };
        self.par_ctrl.update_from_search(sigma_q, root_entropy);
    }

    pub fn iterate(&self) {
        // EFT-PUCT용 통계 스냅샷 (RwLock read — 빠름)
        let qstate: Option<(QuartzStats, QuartzConfig)> =
            if let Some(qcfg) = &self.config.quartz {
                self.quartz_cache.read().unwrap()
                    .as_ref()
                    .map(|s| (s.clone(), qcfg.clone()))
            } else { None };

        let sel = select(
            &self.root, &self.root_state,
            self.config.c_puct,
            self.root_noise.as_deref(),
            self.config.pw.as_ref(),
            self.config.max_depth,
            &self.tt,
            qstate.as_ref().map(|(s, c)| (s, c)),
            &self.par_ctrl,
        );

        let leaf_value = if self.config.max_tt_size
            .map_or(true, |cap| self.tt.size() < cap)
        {
            expand_and_evaluate(
                &sel.leaf, &sel.leaf_state,
                self.evaluator.as_ref(), &self.tt,
                self.config.pw.as_ref(),
            )
        } else {
            sel.leaf.terminal_value.unwrap_or(0.0)
        };

        backprop::<G>(&sel.path, leaf_value);
    }

    // ── 탐색 실행 ──────────────────────────────────────────────

    pub fn run(&self, controller: &mut dyn SearchController) -> SearchStats {
        controller.reset();
        let start  = Instant::now();
        let mut it = 0u32;
        let qcfg   = self.config.quartz.clone();

        loop {
            let rv = self.root.n_total.load(Ordering::Relaxed);
            let ms = start.elapsed().as_millis() as u64;
            if controller.should_stop(rv, ms) { break; }

            self.iterate();
            it += 1;

            // QUARTZ 통계 주기적 갱신
            // QuartzController를 직접 downcast할 수 없으므로,
            // MctsConfig.quartz가 있으면 engine 내부 캐시 갱신하고
            // controller가 QuartzController이면 자동으로 should_stop에서 확인.
            if let Some(ref qcfg) = qcfg {
                if it % qcfg.check_interval == 0 {
                    self.refresh_quartz_stats();
                    self.refresh_par_ctrl();
                }
            }
        }

        let ms = start.elapsed().as_millis() as u64;
        let rv = self.root.n_total.load(Ordering::Relaxed);
        SearchStats {
            iterations:  it,
            elapsed_ms:  ms,
            nps:         if ms > 0 { it as f64 / ms as f64 * 1000.0 } else { 0.0 },
            tt_hit_rate: self.tt.hit_rate(),
            tt_size:     self.tt.size(),
            root_visits: rv,
            stop_reason: controller.stop_reason(),
        }
    }

    /// QuartzController와 통합된 run — 통계 자동 갱신, 적응적 정지
    pub fn run_quartz(&self, ctrl: &mut QuartzController) -> SearchStats {
        ctrl.reset();
        let start    = Instant::now();
        let mut it   = 0u32;
        let mut iter_start = Instant::now();

        loop {
            let rv = self.root.n_total.load(Ordering::Relaxed);
            let ms = start.elapsed().as_millis() as u64;

            if it > 0 && it % ctrl.cfg.check_interval == 0 {
                // 실제 per-iter cost (ms) EMA 갱신 — CTM cost에 사용
                let iter_ms = iter_start.elapsed().as_secs_f32() * 1000.0
                    / ctrl.cfg.check_interval as f32;
                ctrl.record_iter_time_ms(iter_ms);
                iter_start = Instant::now();

                // elapsed 주입 — CTM urgency + NS annealing에 사용
                ctrl.update_elapsed(ms);
                { let _rp = self.root_priors(); ctrl.update_stats(&self.root, Some(&_rp)); }
                *self.quartz_cache.write().unwrap() = Some(ctrl.last_stats());
                self.refresh_par_ctrl();
            }

            if ctrl.should_stop(rv, ms) { break; }
            self.iterate();
            it += 1;
        }

        ctrl.update_elapsed(start.elapsed().as_millis() as u64);
        { let _rp = self.root_priors(); ctrl.update_stats(&self.root, Some(&_rp)); }
        *self.quartz_cache.write().unwrap() = Some(ctrl.last_stats());

        let ms = start.elapsed().as_millis() as u64;
        let rv = self.root.n_total.load(Ordering::Relaxed);
        SearchStats {
            iterations:  it,
            elapsed_ms:  ms,
            nps:         if ms > 0 { it as f64 / ms as f64 * 1000.0 } else { 0.0 },
            tt_hit_rate: self.tt.hit_rate(),
            tt_size:     self.tt.size(),
            root_visits: rv,
            stop_reason: ctrl.stop_reason(),
        }
    }

    /// GVOC + QUARTZ 완전 통합 run
    ///
    /// - GVOC: VOC 기반 PW 확장 폭 동적 조정
    /// - QUARTZ: σ_Q / P_flip / VOC 통계 + 적응적 정지
    /// - 재현성: config.seed 기반 결정론적 RNG
    pub fn run_gvoc(
        &self,
        ctrl:      &mut QuartzController,
        gvoc_cfg:  &GvocConfig,
    ) -> (SearchStats, GvocState) {
        ctrl.reset();
        let start    = Instant::now();
        let mut it   = 0u32;
        let n_cands  = self.root.candidate_count();
        let init_vis = match &self.config.pw {
            Some(pw) => pw.k(0).max(1).min(n_cands),
            None     => n_cands,
        };
        let qcfg = ctrl.cfg.clone();

        let mut gvoc = GvocState::new(gvoc_cfg.clone(), init_vis);

        loop {
            let rv = self.root.n_total.load(Ordering::Relaxed);
            let ms = start.elapsed().as_millis() as u64;

            // QUARTZ 수렴 체크
            if it > 0 && it % ctrl.cfg.check_interval == 0 {
                { let _rp = self.root_priors(); ctrl.update_stats(&self.root, Some(&_rp)); }
                *self.quartz_cache.write().unwrap() = Some(ctrl.last_stats());
                self.refresh_par_ctrl();
            }
            if ctrl.should_stop(rv, ms) { break; }

            // GVOC: VOC 기반 n_visible 동적 조정
            gvoc.update(&self.root, n_cands, &qcfg);

            // proposal mode 결정 (Inside / Outside)
            let _mode = if let Some(s) = self.current_quartz_stats() {
                routing_mode(&s, &qcfg)
            } else {
                ProposalMode::Inside
            };
            // Outside mode: WL bonus가 이미 QuartzController 통계에 포함됨
            // Inside mode: 표준 EFT-PUCT

            self.iterate();
            it += 1;
        }

        { let _rp = self.root_priors(); ctrl.update_stats(&self.root, Some(&_rp)); }
        *self.quartz_cache.write().unwrap() = Some(ctrl.last_stats());

        let ms = start.elapsed().as_millis() as u64;
        let rv = self.root.n_total.load(Ordering::Relaxed);
        let stats = SearchStats {
            iterations:  it,
            elapsed_ms:  ms,
            nps:         if ms > 0 { it as f64 / ms as f64 * 1000.0 } else { 0.0 },
            tt_hit_rate: self.tt.hit_rate(),
            tt_size:     self.tt.size(),
            root_visits: rv,
            stop_reason: ctrl.stop_reason(),
        };
        (stats, gvoc)
    }

    pub fn run_par(
        &self,
        controller: &dyn SearchController,
        n_threads:  usize,
    ) -> SearchStats {
        let start = Instant::now();

        rayon::scope(|s| {
            for tid in 0..n_threads {
                let qcfg_ref = &self.config.quartz;
                s.spawn(move |_| {
                    let mut local_it = 0u32;
                    loop {
                        let rv = self.root.n_total.load(Ordering::Relaxed);
                        let ms = start.elapsed().as_millis() as u64;
                        if controller.should_stop(rv, ms) { break; }
                        self.iterate();
                        local_it += 1;
                        if tid == 0 {
                            if let Some(ref qcfg) = qcfg_ref {
                                if local_it % qcfg.check_interval == 0 {
                                    self.refresh_quartz_stats();
                                    self.refresh_par_ctrl();
                                }
                            }
                        }
                    }
                });
            }
        });

        let ms = start.elapsed().as_millis() as u64;
        let rv = self.root.n_total.load(Ordering::Relaxed);
        SearchStats {
            iterations:  rv,
            elapsed_ms:  ms,
            nps:         if ms > 0 { rv as f64 / ms as f64 * 1000.0 } else { 0.0 },
            tt_hit_rate: self.tt.hit_rate(),
            tt_size:     self.tt.size(),
            root_visits: rv,
            stop_reason: controller.stop_reason(),
        }
    }

    // ── 결과 추출 ──────────────────────────────────────────────

    /// Extract edge priors from root node for QuartzStats computation.
    pub fn root_priors(&self) -> Vec<f32> {
        let n = self.root.materialized_count();
        let edges = self.root.edge_snapshot(n);
        edges.iter().map(|e| e.p).collect()
    }

    /// Advance root to the child matching `chosen_move`, reusing the subtree.
    /// Returns true if the child was found and promoted, false otherwise.
    /// After advance, call `expand_root()` if the new root isn't expanded.
    pub fn advance_root(&mut self, chosen_move: G::Move) -> bool
    where G::Move: PartialEq,
    {
        let n = self.root.materialized_count();
        let edges = self.root.edge_snapshot(n);
        for edge in &edges {
            if edge.mv == chosen_move {
                self.root = edge.child.clone();
                self.root_state = self.root_state.apply_move(chosen_move);
                self.root_noise = None;
                // Clear quartz cache for new root
                *self.quartz_cache.write().unwrap() = None;
                // Expand new root if not already expanded
                if self.root.materialized_count() == 0 && !self.root_state.is_terminal() {
                    self.expand_root();
                }
                return true;
            }
        }
        false
    }

    /// Get a reference to the current root state.
    pub fn root_state(&self) -> &G {
        &self.root_state
    }

    pub fn best_move(&self) -> Option<G::Move> {
        select_move_with_temperature(&self.root, self.config.temperature)
    }

    pub fn pi_target(&self, temperature: f32) -> Vec<(G::Move, f32)> {
        visit_distribution(&self.root, temperature)
    }

    pub fn root_entropy(&self) -> f32 {
        let edges  = self.root.edge_snapshot(self.root.materialized_count());
        let counts = edges.iter().map(|e| e.n.load(Ordering::Acquire)).collect::<Vec<_>>();
        root_entropy(&counts)
    }

    pub fn root_value(&self) -> f32 {
        let edges  = self.root.edge_snapshot(self.root.materialized_count());
        let total  = self.root.n_total.load(Ordering::Acquire);
        if total == 0 { return 0.0; }
        edges.iter()
            .map(|e| e.n.load(Ordering::Acquire) as f32 * e.q())
            .sum::<f32>() / total as f32
    }

    pub fn pw_stats(&self) -> (usize, usize) {
        let total  = self.root.candidate_count();
        let n_root = self.root.n_total.load(Ordering::Acquire);
        let open   = match &self.config.pw {
            Some(cfg) => cfg.k(n_root).max(1).min(total),
            None      => total,
        };
        (open, total)
    }

    pub fn print_stats(&self, label: &str) {
        let rv = self.root.n_total.load(Ordering::Acquire);
        let h  = self.root_entropy();
        let v  = self.root_value();
        let (pw_open, pw_total) = self.pw_stats();

        println!("\n[{}] visits={}, entropy={:.3}, value={:.3}, hash=0x{:016X}",
                 label, rv, h, v, self.root.hash);
        println!("TT(size={}, hit={:.1}%)  PW({}/{})  max_depth={}",
                 self.tt.size(), self.tt.hit_rate()*100.0, pw_open, pw_total,
                 self.config.max_depth);

        // QUARTZ 통계 출력
        if let Some(stats) = self.current_quartz_stats() {
            stats.print(label);
        }

        let n_show = self.root.materialized_count().min(pw_open);
        let edges  = self.root.edge_snapshot(n_show);
        if !edges.is_empty() {
            println!("{:<8} {:>7} {:>8} {:>8} {:>7}", "Move","N","W","Q","P(%)");
            println!("{}", "-".repeat(44));
            let mut data: Vec<_> = edges.iter()
                .map(|e| (e.mv, e.n.load(Ordering::Acquire),
                          atomic_f64_load(&e.w), e.q(), e.p))
                .collect();
            data.sort_by(|a,b| b.1.cmp(&a.1));
            for (mv, n, w, q, p) in data.iter().take(9) {
                println!("  {:?}  {:>7} {:>8.2} {:>8.3} {:>6.1}", mv, n, w, q, p*100.0);
            }
            if pw_open > 9 { println!("  ... ({} more open)", pw_open - 9); }
            if pw_total > pw_open { println!("  ... ({} not yet opened)", pw_total - pw_open); }
        }
    }
}

unsafe impl<G: GameState> Sync for MctsEngine<G> {}
