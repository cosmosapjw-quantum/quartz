# Gomocup Evaluation Notes (Gomoku)

## 1) 왜 Gomocup이 중요하냐
- 내부 self-play만으로는 “우리만의 편향”을 못 잡는다.
- 외부 토너먼트 매니저(Gomocup) 기반으로 돌리면
  - 프로토콜/시간/환경 제약을 강제할 수 있고
  - Elo 비교가 설득력 있어진다.

---

## 2) 실행 포맷(개요)
Gomocup 계열 매니저는 보통 “엔진 프로토콜”로 프로그램을 실행한다.
(정확한 커맨드/프로토콜은 Gomocup Manager/Piskvork 문서를 따른다)

필수:
- 제한 시간 준수(수당 5초 등)
- 정해진 규칙(rule) 처리
- 표준 입출력 기반 명령 처리

---

## 3) 실험 프로토콜(권장)
- baseline vs QUARTZ를 “같은 바이너리 + 플래그만 다르게” 실행:
  - `engine.exe --mode baseline`
  - `engine.exe --mode quartz`
- opening은 고정 세트 사용(색상 바꿔서 2판씩)
- 최소 200판 이상(신뢰구간 좁히기)

---

## 4) 로그/재현성
- Gomocup 경기 로그(raw) 저장
- 우리 엔진 내부 JSONL 로그도 같이 저장
- 결과 파싱 스크립트로 Elo 추정/CI 생성

---

## 5) 참고
- Gomocup 공식 사이트/매니저 다운로드/프로토콜 문서를 따를 것.
