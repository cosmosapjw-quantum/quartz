//! PUCT Selection (v0.7)
//! Standard PUCT + Fisher Metric PUCT (§4 Information Geometry)
//! + EFT-PUCT (§6.1.2 one-loop bonus + visit penalty)

use std::sync::Arc;
use std::sync::atomic::Ordering;

use crate::game::GameState;
use crate::mcts::expand::materialize_edges;
use crate::mcts::mod_types::PwConfig;
use crate::mcts::node::{MctsNode, PathEdge};
use crate::mcts::quartz::{
    eft_action_bonus, one_loop_visit_penalty, fisher_prior_weight,
    QuartzConfig, QuartzStats,
};
use crate::mcts::tt::TranspositionTable;

// ─────────────────────────────────────────────
// § PUCT Variants
// ─────────────────────────────────────────────

/// Standard AlphaZero PUCT (baseline)
#[inline]
pub fn puct_score(
    n_eff:        u32,
    q_eff:        f32,
    prior:        f32,
    noise_adj:    f32,
    n_parent_eff: u32,
    c_puct:       f32,
) -> f32 {
    let p       = (prior + noise_adj).max(0.0);
    let explore = c_puct * p * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32);
    q_eff + explore
}

/// (4) Fisher Metric PUCT — α = FISHER_ALPHA = 0.5 (fixed by natural gradient)
#[inline]
pub fn fisher_puct_score(
    n_eff:        u32,
    q_eff:        f32,
    prior:        f32,
    noise_adj:    f32,
    n_parent_eff: u32,
    c_puct:       f32,
    _alpha:       f32,  // ignored — always 0.5 (Fisher metric)
) -> f32 {
    let p      = (prior + noise_adj).max(0.0);
    let p_fish = fisher_prior_weight(p);   // √π
    let explore = c_puct * p_fish * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32);
    q_eff + explore
}

/// EFT-PUCT: Fisher PUCT + one-loop bonus + one-loop visit penalty
/// = (4) Fisher natural gradient + (1) QFT diagonal one-loop
#[inline]
pub fn eft_puct_score(
    n_eff:        u32,
    n_raw:        u32,
    q_eff:        f32,
    prior:        f32,
    noise_adj:    f32,
    n_parent_eff: u32,
    c_puct:       f32,
    stats:        &QuartzStats,
    _qcfg:        &QuartzConfig,  // reserved
) -> f32 {
    let base    = fisher_puct_score(n_eff, q_eff, prior, noise_adj,
                                    n_parent_eff, c_puct, crate::mcts::quartz::FISHER_ALPHA);
    let bonus   = eft_action_bonus(stats);
    // One-loop diagonal: -ħ_eff/N_a (EFT-PUCT penalty)
    let penalty = one_loop_visit_penalty(n_raw, stats.hbar_eff, 1.0, crate::mcts::quartz::HBAR_PENALTY_CAP);
    base + bonus + penalty
}

/// PR-1B: Ablation-aware PUCT — respects penalty_mode and prior refresh settings.
/// SelfAdaptive mode: state-derived with fixed constants. All inputs from search observables.
#[inline]
pub fn ablation_puct_score(
    n_eff:        u32,
    n_raw:        u32,
    o_a:          u32,
    q_eff:        f32,
    prior:        f32,
    noise_adj:    f32,
    n_parent_eff: u32,
    c_puct:       f32,
    stats:        &QuartzStats,
    qcfg:         &QuartzConfig,
) -> f32 {
    use crate::mcts::quartz::PenaltyMode;

    // ═══════════════════════════════════════════
    // SelfAdaptive: zero config reads for penalty + refresh
    // All derived from: sigma_q, surprise_kl, n_visible, root_visits
    // ═══════════════════════════════════════════
    if qcfg.penalty_mode == PenaltyMode::SelfAdaptive {
        let k = (stats.n_visible as f32).max(2.0);
        let n_total = (stats.root_visits as f32).max(1.0);
        let sigma_q = stats.sigma_q.max(0.001);

        // ── Penalty: ν = σ_Q  →  -σ_Q / M_a ──
        let penalty = if n_raw > 0 || o_a > 0 {
            let m_a = 1.0 + n_raw as f32 + o_a as f32;
            -sigma_q / m_a
        } else { 0.0 };

        // ── Dynamic prior refresh: per-action Bayesian weight ──
        // α_a = N_a / (N_a + K)  — no global ρ, no hardcoded constants
        //   N_a=0 → α=0 (pure original prior)
        //   N_a=K → α=0.5 (balanced blend)
        //   N_a>>K → α→1 (fully visit-based)
        // τ = ln(1 + N_total/K)  — self-normalizing temperature
        let effective_prior = if n_raw > 0 {
            let n_a = n_raw as f32;
            let alpha_a = n_a / (n_a + k);
            let n_avg = n_total / k;
            let tau = (1.0 + n_avg).ln().max(0.1);
            let log_p0 = prior.max(1e-8).ln();
            let log_visit = (1.0 + n_a).ln();
            let log_pt = (1.0 - alpha_a) * log_p0 + alpha_a * log_visit / tau;
            log_pt.exp().max(1e-8)
        } else {
            prior
        };

        let p = (effective_prior + noise_adj).max(0.0);
        let base = q_eff + c_puct * p * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32);
        return base + penalty;
    }

    // ═══════════════════════════════════════════
    // GatedRefresh v3: ExtQRef formula + P_flip gate
    // maturity gate 제거, fixed τ=0.5 (τ_auto의 σ_Q 피드백 회피)
    // ═══════════════════════════════════════════
    if qcfg.penalty_mode == PenaltyMode::GatedRefresh {
        let sigma_q = stats.sigma_q.max(0.001);

        // ── Penalty: EffV2 ──
        let penalty = crate::mcts::quartz::effective_penalty_v2(
            n_raw, o_a, qcfg.hbar_penalty_cap);

        // ── P_flip-reversed gate ──
        let flip_thresh = 0.159_f32;
        let rho_max = 0.3_f32;
        let rho_t = rho_max * (stats.p_flip / flip_thresh).min(1.0);

        // ── Q-based refresh — fixed τ, same as ExtQRef ──
        let tau = 0.5_f32;
        let effective_prior = if n_raw > 0 && rho_t > 1e-4 {
            let log_p0 = prior.max(1e-8).ln();
            let log_pt = (1.0 - rho_t) * log_p0 + rho_t * q_eff / tau;
            log_pt.exp().max(1e-8)
        } else {
            prior
        };

        let p = (effective_prior + noise_adj).max(0.0);
        let base = q_eff + c_puct * p
                 * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32);
        return base + penalty;
    }

    // ═══════════════════════════════════════════
    // Adaptive (H6): P_flip-mediated VF↔Q mixture + σ_Q-adaptive penalty
    //
    // P_flip high (uncertain) → Q-refresh corrects prior
    // P_flip low (converged) → VF-refresh concentrates search
    // penalty ν = max(cap, σ_Q) → captures SA's σ_Q amplification
    // ═══════════════════════════════════════════
    if qcfg.penalty_mode == PenaltyMode::PFlipMixture {
        let k = (stats.n_visible as f32).max(2.0);
        let n_total = (stats.root_visits as f32).max(1.0);
        let sigma_q = stats.sigma_q.max(0.001);

        // ── Penalty: ν = max(cap, σ_Q) ──
        let nu = qcfg.hbar_penalty_cap.max(sigma_q);
        let penalty = if n_raw > 0 || o_a > 0 {
            let m_a = 1.0 + n_raw as f32 + o_a as f32;
            -nu / m_a
        } else { 0.0 };

        // ── P_flip-mediated mixture ──
        let flip_thresh = 0.159_f32;
        let rho_max = 0.3_f32;
        let p_ratio = (stats.p_flip / flip_thresh).min(2.0); // cap at 2.0

        // Q-refresh: strong when P_flip high (uncertain)
        let rho_q = rho_max * p_ratio.min(1.0);
        // VF-refresh: strong when P_flip low (converged)
        let rho_vf = rho_max * (1.0 - p_ratio).max(0.0);

        let effective_prior = if n_raw > 0 && (rho_q + rho_vf) > 1e-4 {
            let log_p0 = prior.max(1e-8).ln();
            let tau_q = 0.5_f32;
            let q_signal = q_eff / tau_q;

            let n_a = n_raw as f32;
            let n_avg = n_total / k;
            let tau_vf = (1.0 + n_avg).ln().max(0.1);
            let vf_signal = (1.0 + n_a).ln() / tau_vf;

            let rho_total = rho_q + rho_vf;
            let log_pt = (1.0 - rho_total) * log_p0
                       + rho_q * q_signal
                       + rho_vf * vf_signal;
            log_pt.exp().max(1e-8)
        } else {
            prior
        };

        let p = (effective_prior + noise_adj).max(0.0);
        let base = q_eff + c_puct * p
                 * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32);
        return base + penalty;
    }

    // ═══════════════════════════════════════════
    // Non-SelfAdaptive: config-driven modes (backward compatible)
    // ═══════════════════════════════════════════

    // Dynamic prior refresh (manual/K-adaptive modes)
    let effective_prior = if qcfg.prior_refresh_rate > 1e-6 && n_raw > 0 {
        let manual_mode = qcfg.prior_refresh_temp > 0.01;
        let rho_effective = if manual_mode {
            qcfg.prior_refresh_rate
        } else {
            let k_ref = 10.0_f32;
            let k = (stats.n_visible as f32).max(2.0);
            qcfg.prior_refresh_rate * (k_ref / k).min(1.0)
        };
        if rho_effective > 1e-4 {
            if manual_mode {
                let tau = qcfg.prior_refresh_temp;
                let log_p0 = prior.max(1e-8).ln();
                let log_pt = (1.0 - rho_effective) * log_p0 + rho_effective * q_eff / tau.max(0.01);
                log_pt.exp().max(1e-8)
            } else {
                let log_p0 = prior.max(1e-8).ln();
                let log_visit = (1.0 + n_raw as f32).ln();
                let tau_visit = 2.0_f32;
                let log_pt = (1.0 - rho_effective) * log_p0 + rho_effective * log_visit / tau_visit;
                log_pt.exp().max(1e-8)
            }
        } else { prior }
    } else { prior };

    // Base PUCT
    let p = (effective_prior + noise_adj).max(0.0);
    let base = if qcfg.enable_fisher_puct {
        let p_fish = fisher_prior_weight(p);
        q_eff + c_puct * p_fish * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32)
    } else {
        q_eff + c_puct * p * (n_parent_eff as f32).sqrt() / (1.0 + n_eff as f32)
    };

    // Off-diagonal bonus
    let bonus = if qcfg.enable_one_loop { eft_action_bonus(stats) } else { 0.0 };

    // Penalty dispatch
    let penalty = match qcfg.penalty_mode {
        PenaltyMode::Legacy => {
            if qcfg.enable_one_loop {
                one_loop_visit_penalty(n_raw, stats.hbar_eff, 1.0, qcfg.hbar_penalty_cap)
            } else { 0.0 }
        }
        PenaltyMode::EffectiveV2 => {
            crate::mcts::quartz::effective_penalty_v2(n_raw, o_a, qcfg.hbar_penalty_cap)
        }
        PenaltyMode::None => 0.0,
        PenaltyMode::SelfAdaptive => unreachable!(), // handled above
        PenaltyMode::GatedRefresh => unreachable!(),  // handled above
        PenaltyMode::PFlipMixture => unreachable!(),      // handled above
    };

    base + bonus + penalty
}

// ─────────────────────────────────────────────
// § SelectResult
// ─────────────────────────────────────────────

pub struct SelectResult<G: GameState> {
    pub path:       Vec<PathEdge<G::Move>>,
    pub leaf:       Arc<MctsNode<G::Move>>,
    pub leaf_state: G,
}

// ─────────────────────────────────────────────
// § select
// ─────────────────────────────────────────────

pub fn select<G: GameState>(
    root:             &Arc<MctsNode<G::Move>>,
    root_state:       &G,
    c_puct:           f32,
    root_prior_noise: Option<&[f32]>,
    pw:               Option<&PwConfig>,
    max_depth:        usize,
    tt:               &TranspositionTable<G::Move>,
    // QUARTZ EFT-PUCT (None = standard PUCT)
    quartz:           Option<(&QuartzStats, &QuartzConfig)>,
    // Parallelism controller (1st-class runtime object)
    par_ctrl:         &super::parallel::ParallelismController,
) -> SelectResult<G> {
    let mut path      = Vec::new();
    let mut cur_node  = Arc::clone(root);
    let mut cur_state = root_state.clone();
    let mut depth     = 0usize;

    loop {
        if cur_node.terminal_value.is_some()
            || !cur_node.is_expanded()
            || (max_depth > 0 && depth >= max_depth)
        { break; }

        let n_candidates = cur_node.candidate_count();
        if n_candidates == 0 { break; }

        let n_total = cur_node.n_total.load(Ordering::Acquire);
        let n_visible = match pw {
            Some(cfg) => cfg.k(n_total).max(1).min(n_candidates),
            None      => n_candidates,
        };

        let n_mat = cur_node.materialized_count();
        if n_mat < n_visible {
            materialize_edges(&cur_node, &cur_state, n_visible, tt);
        }

        // [OPT] Hold Mutex guard directly instead of edge_snapshot (avoids N Arc clones)
        let guard = cur_node.edges.lock().unwrap();
        let n_edges = n_visible.min(guard.len());
        if n_edges == 0 { drop(guard); break; }
        let edges = &guard[..n_edges];

        let vl_sum: u32 = edges.iter()
            .map(|e| e.virtual_losses.load(Ordering::Relaxed).max(0) as u32)
            .sum();
        let n_parent_eff = n_total + vl_sum;

        let best_idx = edges.iter().enumerate()
            .max_by(|(i, a), (j, b)| {
                let ni = if depth == 0 {
                    root_prior_noise.and_then(|n| n.get(*i).copied()).unwrap_or(0.0)
                } else { 0.0 };
                let nj = if depth == 0 {
                    root_prior_noise.and_then(|n| n.get(*j).copied()).unwrap_or(0.0)
                } else { 0.0 };

                let n_raw_a = a.n.load(Ordering::Relaxed);
                let n_raw_b = b.n.load(Ordering::Relaxed);
                let o_a = a.virtual_losses.load(Ordering::Relaxed).max(0) as u32;
                let o_b = b.virtual_losses.load(Ordering::Relaxed).max(0) as u32;

                let sa = match quartz {
                    Some((stats, qcfg)) if depth == 0 => {
                        let base = ablation_puct_score(a.n_eff(), n_raw_a, o_a, a.q_eff(), a.p, ni,
                                       n_parent_eff, c_puct, stats, qcfg);
                        // G1: Paper B_1loop bonus (σ̂-aware exploration)
                        let b1 = if stats.lambda_1loop > 1e-6 {
                            crate::mcts::quartz::paper_b1loop_bonus(
                                a.edge_sigma().unwrap_or(0.0), stats.lambda_1loop)
                        } else { 0.0 };
                        base + b1
                    }
                    _ =>
                        puct_score(a.n_eff(), a.q_eff(), a.p, ni, n_parent_eff, c_puct),
                };
                let sb = match quartz {
                    Some((stats, qcfg)) if depth == 0 => {
                        let base = ablation_puct_score(b.n_eff(), n_raw_b, o_b, b.q_eff(), b.p, nj,
                                       n_parent_eff, c_puct, stats, qcfg);
                        let b1 = if stats.lambda_1loop > 1e-6 {
                            crate::mcts::quartz::paper_b1loop_bonus(
                                b.edge_sigma().unwrap_or(0.0), stats.lambda_1loop)
                        } else { 0.0 };
                        base + b1
                    }
                    _ =>
                        puct_score(b.n_eff(), b.q_eff(), b.p, nj, n_parent_eff, c_puct),
                };

                sa.partial_cmp(&sb).unwrap_or(std::cmp::Ordering::Equal).then(j.cmp(i))
            })
            .map(|(i, _)| i)
            .unwrap_or(0);

        // Parallelism telemetry: record pending count at this node
        let pending_at_node: u32 = edges.iter()
            .map(|e| e.virtual_losses.load(Ordering::Relaxed).max(0) as u32)
            .sum();
        par_ctrl.telemetry.record_select(pending_at_node);

        // Detect duplicate path: if selected edge already has pending VL
        if edges[best_idx].vl() > 0 {
            par_ctrl.telemetry.record_dup_leaf();
        }

        let vl_split = par_ctrl.vl_at_depth(depth as u32);
        edges[best_idx].apply_vl(vl_split.vvisit, vl_split.vvalue);
        par_ctrl.telemetry.record_vvalue(vl_split.vvalue);

        let best_mv   = edges[best_idx].mv;
        let next_node = Arc::clone(&edges[best_idx].child);
        let edge_arc  = Arc::clone(&edges[best_idx]);
        drop(guard); // release Mutex before apply_move

        cur_state = cur_state.apply_move(best_mv);
        path.push(PathEdge { parent: Arc::clone(&cur_node), edge_arc,
                              applied_vl: (vl_split.vvisit, vl_split.vvalue) });
        cur_node = next_node;
        depth   += 1;
    }

    SelectResult { path, leaf: cur_node, leaf_state: cur_state }
}
