//! Go — Board game engine (9×9, 13×13, 19×19)
//!
//! 핵심 설계:
//!   - [u8; 361] board: 0=empty, 1=black, 2=white (max 19×19)
//!   - BFS liberty counting (simple, correct — optimize to union-find later)
//!   - Simple ko (ko_point) + positional superko (hash history)
//!   - Tromp-Taylor scoring (Chinese rules, area counting)
//!   - Pass = action N*N, two consecutive passes → terminal
//!   - apply_move(&self, mv) -> Self: pure function
//!
//! 좌표계: pos = row * size + col, 0-indexed
//! 플레이어: Black=1, White=2 (board), +1/-1 (GameState convention)

use std::fmt;
use std::hash::Hash;
use rand::SeedableRng;
use rand::rngs::StdRng;
use rand::Rng;

use crate::game::GameState;

// ═══════════════════════════════════════════════════════
// § Constants
// ═══════════════════════════════════════════════════════

const MAX_SZ: usize = 19;
const MAX_N2: usize = MAX_SZ * MAX_SZ; // 361

// ═══════════════════════════════════════════════════════
// § Zobrist
// ═══════════════════════════════════════════════════════

struct GoZob {
    piece: [[u64; MAX_N2]; 2], // [0=black, 1=white][pos]
    side: u64,
}

impl GoZob {
    fn new(seed: u64) -> Self {
        let mut rng = StdRng::seed_from_u64(seed);
        let mut piece = [[0u64; MAX_N2]; 2];
        for c in 0..2 { for p in 0..MAX_N2 { piece[c][p] = rng.gen(); } }
        GoZob { piece, side: rng.gen() }
    }
}

thread_local! {
    static GZOB: GoZob = GoZob::new(0xBADC_AFE0_6060_1234);
}

// ═══════════════════════════════════════════════════════
// § Go state
// ═══════════════════════════════════════════════════════

#[derive(Clone)]
pub struct Go {
    board: [u8; MAX_N2],   // 0=empty, 1=black, 2=white
    pub size: usize,
    side: u8,              // 1=black, 2=white
    ko_point: u16,         // forbidden recapture point, u16::MAX = none
    passes: u8,            // consecutive passes (0, 1, or 2)
    black_caps: u16,       // black's captured stones (prisoners)
    white_caps: u16,
    komi: f32,             // compensation for white (e.g., 7.5)
    hash: u64,
    move_count: u16,
    // Superko: position hash history
    hash_history: Vec<u64>,
    allow_suicide: bool,   // Chinese: allowed, Japanese: forbidden
}

impl Go {
    pub fn new(size: usize, komi: f32) -> Self {
        assert!(size <= MAX_SZ && size >= 2);
        let mut g = Go {
            board: [0u8; MAX_N2],
            size, side: 1, ko_point: u16::MAX, passes: 0,
            black_caps: 0, white_caps: 0, komi,
            hash: 0, move_count: 0,
            hash_history: Vec::with_capacity(size * size * 2),
            allow_suicide: false,
        };
        g.hash_history.push(g.hash);
        g
    }

    pub fn new_9x9() -> Self { Self::new(9, 7.5) }
    pub fn new_13x13() -> Self { Self::new(13, 7.5) }
    pub fn new_19x19() -> Self { Self::new(19, 7.5) }

    /// Reconstruct state from board array (0=empty, 1=black, 2=white) + side to move.
    pub fn from_board(size: usize, komi: f32, board: &[u8], side: u8) -> Self {
        let mut g = Self::new(size, komi);
        let n2 = size * size;
        for i in 0..n2.min(board.len()) {
            g.board[i] = board[i];
        }
        g.side = if side == 2 { 2 } else { 1 };
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..n2 {
                match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} }
            }
            if g.side == 2 { g.hash ^= z.side; }
        });
        g.hash_history = vec![g.hash];
        g
    }

    fn n2(&self) -> usize { self.size * self.size }
    pub fn pass_action(&self) -> u16 { self.n2() as u16 }

    fn row(&self, pos: usize) -> usize { pos / self.size }
    fn col(&self, pos: usize) -> usize { pos % self.size }

    fn neighbors(&self, pos: usize) -> impl Iterator<Item = usize> + '_ {
        let r = self.row(pos);
        let c = self.col(pos);
        let sz = self.size;
        let mut nbrs = [usize::MAX; 4];
        let mut n = 0;
        if r > 0 { nbrs[n] = pos - sz; n += 1; }
        if r + 1 < sz { nbrs[n] = pos + sz; n += 1; }
        if c > 0 { nbrs[n] = pos - 1; n += 1; }
        if c + 1 < sz { nbrs[n] = pos + 1; n += 1; }
        (0..n).map(move |i| nbrs[i])
    }

    fn opp(color: u8) -> u8 { 3 - color }

    // ── BFS liberty / group detection ──

    /// Count liberties of the group containing `pos`. Returns 0 if `pos` is empty.
    fn count_liberties(&self, pos: usize) -> u32 {
        let color = self.board[pos];
        if color == 0 { return 0; }
        let mut visited = [false; MAX_N2];
        let mut libs = [false; MAX_N2];
        let mut stack = Vec::with_capacity(16);
        stack.push(pos);
        visited[pos] = true;
        let mut lib_count = 0u32;
        while let Some(p) = stack.pop() {
            for nb in self.neighbors(p) {
                if visited[nb] { continue; }
                if self.board[nb] == color {
                    visited[nb] = true;
                    stack.push(nb);
                } else if self.board[nb] == 0 && !libs[nb] {
                    libs[nb] = true;
                    lib_count += 1;
                }
            }
        }
        lib_count
    }

    /// Find all stones in the group containing `pos`.
    fn group_stones(&self, pos: usize) -> Vec<usize> {
        let color = self.board[pos];
        if color == 0 { return vec![]; }
        let mut visited = [false; MAX_N2];
        let mut stones = Vec::with_capacity(16);
        let mut stack = Vec::with_capacity(16);
        stack.push(pos);
        visited[pos] = true;
        while let Some(p) = stack.pop() {
            stones.push(p);
            for nb in self.neighbors(p) {
                if !visited[nb] && self.board[nb] == color {
                    visited[nb] = true;
                    stack.push(nb);
                }
            }
        }
        stones
    }

    /// Remove a group and return the number of stones removed.
    fn remove_group(&mut self, pos: usize) -> u16 {
        let stones = self.group_stones(pos);
        let count = stones.len() as u16;
        for &s in &stones {
            let color = self.board[s];
            GZOB.with(|z| { self.hash ^= z.piece[(color - 1) as usize][s]; });
            self.board[s] = 0;
        }
        count
    }

    // ── Legal move check ──

    pub fn is_legal(&self, pos: usize) -> bool {
        if pos >= self.n2() { return false; }
        if self.board[pos] != 0 { return false; }
        if pos as u16 == self.ko_point { return false; }

        let color = self.side;
        let opp = Self::opp(color);

        // Fast path 1: if ANY neighbor is empty → guaranteed ≥1 liberty → legal
        for nb in self.neighbors(pos) {
            if self.board[nb] == 0 { return true; }
        }

        // Fast path 2: if any opponent neighbor has exactly 1 liberty (=pos) → capture → legal
        for nb in self.neighbors(pos) {
            if self.board[nb] == opp && self.has_single_liberty(nb, pos) {
                return true;
            }
        }

        // Fast path 3: if any friendly neighbor's group has >1 liberty → still has libs → legal
        for nb in self.neighbors(pos) {
            if self.board[nb] == color && self.count_liberties(nb) > 1 {
                return true;
            }
        }

        // Slow path: all neighbors are occupied, no captures, no friendly group with spare libs
        // → placing here results in 0 liberties = suicide
        self.allow_suicide
    }

    /// Does the group at `pos` have exactly one liberty, and is it at `expected_lib`?
    #[inline]
    fn has_single_liberty(&self, pos: usize, expected_lib: usize) -> bool {
        let color = self.board[pos];
        if color == 0 { return false; }
        let mut visited = [false; MAX_N2];
        let mut stack = Vec::with_capacity(8);
        stack.push(pos);
        visited[pos] = true;
        let mut found_expected = false;
        while let Some(p) = stack.pop() {
            for nb in self.neighbors(p) {
                if visited[nb] { continue; }
                if self.board[nb] == color {
                    visited[nb] = true;
                    stack.push(nb);
                } else if self.board[nb] == 0 {
                    if nb == expected_lib {
                        found_expected = true;
                    } else {
                        return false; // found another liberty → not single
                    }
                }
            }
        }
        found_expected
    }

    /// Internal: place stone and handle captures. Returns new state.
    fn do_place(&self, pos: usize) -> Self {
        let mut next = self.clone();
        let color = self.side;
        let opp = Self::opp(color);

        // Place stone
        next.board[pos] = color;
        GZOB.with(|z| { next.hash ^= z.piece[(color - 1) as usize][pos]; });

        // Capture adjacent opponent groups with 0 liberties
        let mut total_captured = 0u16;
        let mut single_cap = u16::MAX;
        for nb in self.neighbors(pos) {
            if next.board[nb] == opp && next.count_liberties(nb) == 0 {
                let n = next.remove_group(nb);
                total_captured += n;
                if n == 1 { single_cap = nb as u16; }
            }
        }

        // Record captures
        if color == 1 { next.black_caps += total_captured; }
        else { next.white_caps += total_captured; }

        // Simple ko: if captured exactly 1 stone and placed stone has exactly 1 liberty
        next.ko_point = u16::MAX;
        if total_captured == 1 && next.count_liberties(pos) == 1 {
            next.ko_point = single_cap;
        }

        // Check self-capture (suicide)
        if next.count_liberties(pos) == 0 {
            let n = next.remove_group(pos);
            if color == 1 { next.white_caps += n; } else { next.black_caps += n; }
        }

        next
    }

    // ── Scoring (Tromp-Taylor) ──

    /// Area scoring: stones on board + empty territory
    pub fn tromp_taylor_score(&self) -> (f32, f32) {
        let mut black = 0f32;
        let mut white = 0f32;
        let n2 = self.n2();
        let mut visited = [false; MAX_N2];

        for pos in 0..n2 {
            match self.board[pos] {
                1 => black += 1.0,
                2 => white += 1.0,
                0 if !visited[pos] => {
                    // Flood-fill empty region to determine owner
                    let mut region = Vec::new();
                    let mut stack = vec![pos];
                    visited[pos] = true;
                    let mut adj_black = false;
                    let mut adj_white = false;
                    while let Some(p) = stack.pop() {
                        region.push(p);
                        for nb in self.neighbors(p) {
                            match self.board[nb] {
                                1 => adj_black = true,
                                2 => adj_white = true,
                                0 if !visited[nb] => { visited[nb] = true; stack.push(nb); }
                                _ => {}
                            }
                        }
                    }
                    let territory = region.len() as f32;
                    if adj_black && !adj_white { black += territory; }
                    else if adj_white && !adj_black { white += territory; }
                    // Neutral (both or neither) → no one gets it
                }
                _ => {}
            }
        }

        (black, white + self.komi)
    }
}

// ═══════════════════════════════════════════════════════
// § Display
// ═══════════════════════════════════════════════════════

impl fmt::Display for Go {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for r in (0..self.size).rev() {
            write!(f, "{:2} ", r + 1)?;
            for c in 0..self.size {
                let ch = match self.board[r * self.size + c] {
                    1 => 'X', 2 => 'O', _ => '.',
                };
                write!(f, "{} ", ch)?;
            }
            writeln!(f)?;
        }
        write!(f, "   ")?;
        for c in 0..self.size { write!(f, "{} ", (b'A' + c as u8) as char)?; }
        writeln!(f)
    }
}

impl fmt::Debug for Go {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Go({}x{}, side={}, caps=B{}W{}, ko={:?})",
               self.size, self.size, if self.side == 1 {"B"} else {"W"},
               self.black_caps, self.white_caps,
               if self.ko_point == u16::MAX { None } else { Some(self.ko_point) })
    }
}

// ═══════════════════════════════════════════════════════
// § GameState trait
// ═══════════════════════════════════════════════════════

impl GameState for Go {
    type Move = u16; // 0..N*N for board, N*N for pass

    fn initial() -> Self { Go::new_9x9() }

    fn current_player(&self) -> i8 { if self.side == 1 { 1 } else { -1 } }

    fn legal_moves(&self) -> Vec<u16> {
        if self.passes >= 2 { return vec![]; }
        let n2 = self.n2();
        let mut moves = Vec::with_capacity(n2);
        for pos in 0..n2 {
            if self.is_legal(pos) { moves.push(pos as u16); }
        }
        moves.push(self.pass_action()); // pass is always legal
        moves
    }

    fn apply_move(&self, mv: u16) -> Self {
        let n2 = self.n2() as u16;
        if mv == n2 {
            // Pass
            let mut next = self.clone();
            next.passes += 1;
            next.ko_point = u16::MAX;
            next.side = Self::opp(self.side);
            GZOB.with(|z| { next.hash ^= z.side; });
            next.move_count += 1;
            next.hash_history.push(next.hash);
            return next;
        }

        let pos = mv as usize;
        let mut next = self.do_place(pos);
        next.passes = 0;
        next.side = Self::opp(self.side);
        GZOB.with(|z| { next.hash ^= z.side; });
        next.move_count += 1;
        next.hash_history.push(next.hash);
        next
    }

    fn is_terminal(&self) -> bool {
        self.passes >= 2
    }

    fn outcome(&self) -> f32 {
        let (bs, ws) = self.tromp_taylor_score();
        if bs > ws { if self.side == 1 { 1.0 } else { -1.0 } }
        else if ws > bs { if self.side == 2 { 1.0 } else { -1.0 } }
        else { 0.0 }
    }

    fn hash(&self) -> u64 { self.hash }

    fn num_actions(&self) -> usize { self.n2() + 1 } // board + pass

    fn move_to_idx(&self, mv: u16) -> usize { mv as usize }

    fn idx_to_move(&self, idx: usize) -> Option<u16> {
        if idx <= self.n2() { Some(idx as u16) } else { None }
    }

    fn encode_planes(&self) -> Vec<f32> {
        let n2 = self.n2();
        let mut out = vec![0.0f32; 3 * n2];
        let my = self.side;
        let opp = Self::opp(my);
        for i in 0..n2 {
            if self.board[i] == my { out[i] = 1.0; }
            else if self.board[i] == opp { out[n2 + i] = 1.0; }
        }
        if self.side == 1 { for i in 0..n2 { out[2*n2 + i] = 1.0; } }
        out
    }

    /// O(n²) scan without Vec allocation — critical for ShortRollout performance.
    fn random_legal_move(&self, rand_idx: usize) -> Option<u16> {
        if self.passes >= 2 { return None; }
        let n2 = self.n2();

        // Count empty cells (potential moves)
        let mut empty_count = 0usize;
        for i in 0..n2 {
            if self.board[i] == 0 { empty_count += 1; }
        }

        if empty_count == 0 { return Some(self.pass_action()); }

        // Try from random offset, wrap around
        let start = rand_idx % n2;
        for offset in 0..n2 {
            let pos = (start + offset) % n2;
            if self.board[pos] == 0 && self.is_legal(pos) {
                return Some(pos as u16);
            }
        }

        // No legal board move → pass
        Some(self.pass_action())
    }

    fn legal_move_count(&self) -> usize {
        if self.passes >= 2 { return 0; }
        let n2 = self.n2();
        let mut count = 1usize; // pass always legal
        for pos in 0..n2 {
            if self.is_legal(pos) { count += 1; }
        }
        count
    }
}

// ═══════════════════════════════════════════════════════
// § MctsConfig preset
// ═══════════════════════════════════════════════════════

use crate::mcts::{MctsConfig, PwConfig};
use crate::mcts::quartz::QuartzConfig;
use crate::mcts::gvoc::GvocConfig;

/// Go QUARTZ 프리셋.
/// - PW: α=2.0, β=0.5 (9×9 branching ~40-80)
/// - σ₀ = 0.3
/// - GVOC: max_visible scales with board size
pub fn go_quartz(size: usize) -> MctsConfig {
    let max_visible = match size {
        9  => 40,
        13 => 80,
        _  => 120,
    };
    MctsConfig::evaluation_with_pw(2.0, PwConfig::new(2.0, 0.5))
        .with_quartz(QuartzConfig {
            sigma_0:        0.3,
            min_visits:     30,
            check_interval: 50,
            ..Default::default()
        })
        .with_gvoc(GvocConfig {
            expand_thresh:   0.01,
            contract_thresh: 0.001,
            expand_delta:    2,
            max_visible,
            min_visible:     1,
            score_interval:  50,
        })
}

// ═══════════════════════════════════════════════════════
// § GoFastRollout — Vec 할당 없는 고속 롤아웃 평가기
// ═══════════════════════════════════════════════════════

use crate::game::{EvalResult, Evaluator};

/// Go-specific evaluator: uniform policy + fast rollout using random_legal_move().
/// ShortRollout 대비 Vec 할당이 없어 Go 19×19에서 2-3× 빠름.
pub struct GoFastRollout {
    pub max_depth: usize,
}

impl GoFastRollout {
    pub fn new(max_depth: usize) -> Self { GoFastRollout { max_depth } }
}

impl Evaluator<Go> for GoFastRollout {
    fn evaluate(&self, state: &Go) -> EvalResult<u16> {
        let legal = state.legal_moves();
        if legal.is_empty() {
            return EvalResult::uniform(&[], state.outcome());
        }
        let p = 1.0 / legal.len() as f32;
        let policy: Vec<(u16, f32)> = legal.iter().map(|&m| (m, p)).collect();

        // Fast rollout using random_legal_move (no Vec allocation per step)
        let value = go_fast_playout(state, self.max_depth);
        EvalResult { policy, value }
    }
}

fn go_fast_playout(start: &Go, max_depth: usize) -> f32 {
    let mut state = start.clone();
    let root_player = start.current_player();
    let mut rng_state = start.hash().wrapping_mul(6364136223846793005).wrapping_add(1);

    for _ in 0..max_depth {
        if state.is_terminal() {
            let raw = state.outcome();
            let flip = if state.current_player() == root_player { 1.0 } else { -1.0 };
            return raw * flip;
        }
        // Use random_legal_move: O(N²) scan, no Vec allocation
        rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        let rand_idx = (rng_state >> 33) as usize;
        let mv = match state.random_legal_move(rand_idx) {
            Some(m) => m,
            None => break,
        };
        state = state.apply_move(mv);
    }
    0.0 // draw if max depth reached
}

// ═══════════════════════════════════════════════════════
// § Tests
// ═══════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn pos(x: usize, y: usize, sz: usize) -> u16 { (y * sz + x) as u16 }
    fn p(x: usize, y: usize) -> u16 { pos(x, y, 9) }

    fn play_moves(g: &Go, moves: &[u16]) -> Go {
        let mut s = g.clone();
        for &mv in moves { s = s.apply_move(mv); }
        s
    }

    // ── Basic ──

    #[test]
    fn test_basic_9x9() {
        let g = Go::new_9x9();
        assert_eq!(g.size, 9);
        assert_eq!(g.current_player(), 1);
        let moves = g.legal_moves();
        assert_eq!(moves.len(), 82, "81 board + 1 pass");
        assert!(moves.contains(&g.pass_action()));
        assert!(!g.is_terminal());
    }

    #[test]
    fn test_basic_19x19() {
        let g = Go::new_19x19();
        let moves = g.legal_moves();
        assert_eq!(moves.len(), 362, "361 + pass");
    }

    // ── Capture ──

    #[test]
    fn test_single_capture() {
        let g = Go::new_9x9();
        // Surround W(1,1): B at (0,1),(2,1),(1,0),(1,2)
        let g = play_moves(&g, &[
            p(0,1),  // B
            p(4,4),  // W far
            p(2,1),  // B
            p(1,1),  // W target
            p(1,0),  // B
            p(4,5),  // W far
            p(1,2),  // B captures W(1,1)
        ]);
        assert_eq!(g.board[p(1,1) as usize], 0, "W(1,1) captured");
        assert_eq!(g.black_caps, 1);
    }

    #[test]
    fn test_multi_capture() {
        let g = Go::new_9x9();
        // W group at (1,0)+(2,0) on left edge
        let g = play_moves(&g, &[
            p(0,0),  // B
            p(1,0),  // W
            p(1,1),  // B
            p(2,0),  // W
            p(2,1),  // B
            p(4,4),  // W far
            p(3,0),  // B captures W group
        ]);
        assert_eq!(g.board[p(1,0) as usize], 0, "W(1,0) captured");
        assert_eq!(g.board[p(2,0) as usize], 0, "W(2,0) captured");
        assert_eq!(g.black_caps, 2);
    }

    // ── Ko ──

    #[test]
    fn test_ko_rule() {
        let g = Go::new_9x9();
        // Standard ko setup: 
        // W stones at (row=1,col=0), (row=0,col=1), (row=2,col=1) surround (1,1)
        // B stones at (row=0,col=2), (row=2,col=2), (row=1,col=3) surround (1,2)
        // W at (1,2) has 1 liberty at (1,1)
        // B plays (1,1) → captures W(1,2) → B(1,1) has 1 liberty at (1,2) → ko!
        //
        // Board after setup (before B plays (1,1)):
        //   col: 0 1 2 3
        // row 2: . W B .
        // row 1: W . W B   ← W(1,2) surrounded by B(0,2),B(2,2),B(1,3) and liberty=(1,1)
        // row 0: . W B .
        //
        // pos = row*9 + col
        let g = play_moves(&g, &[
            18,       // B at (2,0) — far, just to give B a move
            1,        // W at (0,1) — left of ko center
            20,       // B at (2,2) — surrounds W(1,2) from below
            9,        // W at (1,0) — above ko center... wait
        ]);
        // This is getting complicated with alternating moves. Let me use a FEN-like direct setup.
        // Instead, build the position move by move more carefully:
        
        let g = Go::new_9x9();
        // Need: W at pos 1(0,1), 9(1,0), 19(2,1) and W at 11(1,2)
        //       B at pos 20(2,2), 2(0,2), 28(1,3? no: row=3,col=1) 
        // Actually let me just use y*9+x notation carefully
        // pos = row * 9 + col
        // I want a ko at intersection (row=1,col=1) and (row=1,col=2)
        // W group around (1,1): W at (0,1)=9, (2,1)=19, (1,0)=1
        // B group around (1,2): B at (0,2)=2, (2,2)=20, (1,3)=12
        // W at (1,2)=11 (to be captured)
        // B plays at (1,1)=10 → captures W(1,2)=11

        // Build by alternating. B=odd moves, W=even:
        let g = play_moves(&g, &[
            2,   // B at (0,2)  — surround (1,2)
            1,   // W at (0,1)  — surround (1,1)
            20,  // B at (2,2)  — surround (1,2)
            19,  // W at (2,1)  — surround (1,1)
            12,  // B at (1,3)  — surround (1,2)
            11,  // W at (1,2)  — target (1 liberty at (1,1))
        ]);
        
        // Verify setup: W(1,2)=11 has 1 liberty at (1,1)=10
        assert_eq!(g.count_liberties(11), 1, "W(1,2) should have 1 liberty");
        
        // Now W plays to give us more W stones around (1,1)
        // Actually, it's B's turn. B plays at (1,1)=10 → captures W(1,2)=11
        let g = play_moves(&g, &[
            9,  // B at (1,0) — also surrounds (1,1) but we need W there for ko
        ]);
        // Hmm, now it's W's turn. W needs to play at (1,0)? But B just played there.
        // Let me restart with a better approach.

        // Simplest ko: edge ko
        // W at corner (0,0), B at (0,1) and (1,0) surround it.
        // But that's just a capture, not a ko, because B at (0,1)+(1,0) has many liberties.
        
        // Proper ko requires BOTH sides have exactly 1 liberty at the ko point.
        // Setup (using direct board manipulation for clarity):
        let mut g = Go::new_9x9();
        // Directly place stones for the ko position
        // B: (0,2), (2,2), (1,3)  — surround (1,2)
        // W: (0,1), (2,1), (1,0)  — surround (1,1) 
        // W: (1,2)                 — target stone
        // Then B plays (1,1) to capture W(1,2)
        g.board[2] = 1;   // B at (0,2)
        g.board[20] = 1;  // B at (2,2)
        g.board[12] = 1;  // B at (1,3)
        g.board[9] = 2;   // W at (1,0)
        g.board[1] = 2;   // W at (0,1)
        g.board[19] = 2;  // W at (2,1)
        g.board[11] = 2;  // W at (1,2) — target
        g.side = 1;       // B to play
        // Recompute hash
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 {
                if g.board[pos] == 1 { g.hash ^= z.piece[0][pos]; }
                else if g.board[pos] == 2 { g.hash ^= z.piece[1][pos]; }
            }
        });
        g.hash_history = vec![g.hash];
        
        assert_eq!(g.count_liberties(11), 1, "W(1,2) should have 1 lib at (1,1)");
        
        // B plays (1,1)=10 → captures W(1,2)=11
        let g2 = g.apply_move(10);
        assert_eq!(g2.board[11], 0, "W(1,2) captured");
        assert_eq!(g2.black_caps, 1);
        // B(1,1) neighbors: W(0,1)=1, W(2,1)=19, W(1,0)=9, empty(1,2)=11 → 1 liberty
        assert_eq!(g2.count_liberties(10), 1, "B(1,1) should have 1 lib");
        assert_eq!(g2.ko_point, 11, "Ko point should be (1,2)=11");
        assert!(!g2.is_legal(11), "Ko point illegal");
    }

    #[test]
    fn test_ko_cleared_after_play_elsewhere() {
        // Use same ko setup, then play elsewhere
        let mut g = Go::new_9x9();
        g.board[2] = 1; g.board[20] = 1; g.board[12] = 1; // B surround (1,2)
        g.board[9] = 2; g.board[1] = 2; g.board[19] = 2;  // W surround (1,1)
        g.board[11] = 2; // W target
        g.side = 1;
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 { match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} } }
        });
        g.hash_history = vec![g.hash];

        let g = g.apply_move(10); // B captures at (1,1)
        assert_eq!(g.ko_point, 11);
        let g = g.apply_move(50); // W elsewhere
        assert_eq!(g.ko_point, u16::MAX, "Ko cleared after play elsewhere");
    }

    #[test]
    fn test_ko_cleared_on_pass() {
        let mut g = Go::new_9x9();
        g.board[2] = 1; g.board[20] = 1; g.board[12] = 1;
        g.board[9] = 2; g.board[1] = 2; g.board[19] = 2;
        g.board[11] = 2;
        g.side = 1;
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 { match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} } }
        });
        g.hash_history = vec![g.hash];

        let g = g.apply_move(10); // B captures
        assert_eq!(g.ko_point, 11);
        let g = g.apply_move(g.pass_action()); // W pass
        assert_eq!(g.ko_point, u16::MAX, "Ko cleared on pass");
    }

    // ── Suicide ──

    #[test]
    fn test_suicide_forbidden() {
        let mut g = Go::new_9x9();
        g.allow_suicide = false;
        // W at (1,0) and (0,1): B playing (0,0) would be suicide
        let g = play_moves(&g, &[
            p(5,5),  // B far
            p(1,0),  // W
            p(5,6),  // B far
            p(0,1),  // W
        ]);
        assert!(!g.is_legal(p(0,0) as usize), "Suicide forbidden");
    }

    #[test]
    fn test_capture_not_suicide() {
        let g = Go::new_9x9();
        // B(1,0), W(0,0) has 1 lib at (0,1). B plays (0,1) → captures W, not suicide
        let g = play_moves(&g, &[
            p(1,0),  // B
            p(0,0),  // W (1 lib at (0,1))
            p(0,1),  // B captures W(0,0)
        ]);
        assert_eq!(g.board[p(0,0) as usize], 0, "W(0,0) captured");
    }

    // ── Pass ──

    #[test]
    fn test_double_pass_terminal() {
        let g = Go::new_9x9();
        let pass = g.pass_action();
        let g = play_moves(&g, &[pass, pass]);
        assert!(g.is_terminal(), "Double pass → terminal");
    }

    #[test]
    fn test_single_pass_not_terminal() {
        let g = Go::new_9x9();
        let g = g.apply_move(g.pass_action());
        assert!(!g.is_terminal());
    }

    // ── Scoring ──

    #[test]
    fn test_scoring_empty_board() {
        let g = Go::new_9x9();
        let pass = g.pass_action();
        let g = play_moves(&g, &[pass, pass]);
        let (bs, ws) = g.tromp_taylor_score();
        // Empty board: no stones, no territory (neutral) + komi
        assert_eq!(bs, 0.0);
        assert_eq!(ws, 7.5); // komi only
    }

    #[test]
    fn test_scoring_one_stone() {
        let g = Go::new_9x9();
        let pass = g.pass_action();
        let g = play_moves(&g, &[p(4,4), pass, pass]);
        let (bs, ws) = g.tromp_taylor_score();
        // B has 1 stone + entire board territory (81), W has komi
        assert_eq!(bs, 81.0);
        assert_eq!(ws, 7.5);
    }

    // ── Edge ──

    #[test]
    fn test_corner_stone() {
        let g = Go::new_9x9();
        let g = g.apply_move(p(0,0));
        assert_eq!(g.board[0], 1, "Corner stone placed");
        let libs = g.count_liberties(0);
        assert_eq!(libs, 2, "Corner has 2 liberties");
    }

    #[test]
    fn test_edge_stone() {
        let g = Go::new_9x9();
        let g = g.apply_move(p(0,4));
        assert_eq!(g.count_liberties(p(0,4) as usize), 3, "Edge has 3 liberties");
    }

    #[test]
    fn test_center_stone() {
        let g = Go::new_9x9();
        let g = g.apply_move(p(4,4));
        assert_eq!(g.count_liberties(p(4,4) as usize), 4, "Center has 4 liberties");
    }

    #[test]
    fn test_cant_play_occupied() {
        let g = Go::new_9x9();
        let g = g.apply_move(p(4,4));
        assert!(!g.is_legal(p(4,4) as usize));
    }

    // ── Board sizes ──

    #[test]
    fn test_board_13x13() {
        let g = Go::new_13x13();
        assert_eq!(g.legal_moves().len(), 170); // 169 + pass
    }

    // ── Pure function ──

    #[test]
    fn test_apply_move_pure() {
        let g = Go::new_9x9();
        let g2 = g.apply_move(p(4,4));
        assert_eq!(g.board[p(4,4) as usize], 0, "Original unchanged");
        assert_eq!(g2.board[p(4,4) as usize], 1);
    }

    // ── Hash ──

    #[test]
    fn test_hash_changes() {
        let g = Go::new_9x9();
        let g2 = g.apply_move(p(4,4));
        assert_ne!(g.hash(), g2.hash());
    }

    // ── Send + Sync ──

    #[test]
    fn test_send_sync() {
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<Go>();
    }

    // ── MCTS ──

    #[test]
    fn test_mcts_integration() {
        use std::sync::Arc;
        use crate::mcts::{MctsConfig, MctsEngine};
        use crate::mcts::eval::UniformEval;
        use crate::mcts::search::FixedIterations;

        let state = Go::new_9x9();
        let eval: Arc<dyn crate::game::Evaluator<Go> + Send + Sync> = Arc::new(UniformEval);
        let config = MctsConfig::evaluation(2.0);
        let engine = MctsEngine::new(state, eval, config);
        engine.run(&mut FixedIterations::new(100));
        assert!(engine.best_move().is_some());
    }

    // ── Negamax ──

    #[test]
    fn test_negamax_convention() {
        let g = Go::new_9x9();
        let pass = g.pass_action();
        // B plays center, then both pass
        let g = play_moves(&g, &[p(4,4), pass, pass]);
        assert!(g.is_terminal());
        // Black has 81 territory, White has 7.5 komi → B wins
        // Current player is Black (side alternates: B, W_pass, B_pass → side = B? Actually:
        // B plays p(4,4) → side=W, W passes → side=B, B passes → side=W
        // So current_player = -1 (White). Black won → White's perspective: -1
        assert!(g.outcome() < 0.0, "White's perspective: Black won → negative");
    }

    // ══════════════════════════════════════
    // C++ adversarial_go.cpp 포팅 + 추가
    // ══════════════════════════════════════

    // ── Large group capture ──

    #[test]
    fn test_large_group_capture() {
        // Build a 4-stone W group on the edge and capture it
        let mut g = Go::new_9x9();
        // W stones along left edge: (0,0),(0,1),(0,2),(0,3)
        // B surrounds from col=1: (1,0),(1,1),(1,2),(1,3) and top/bottom
        g.board[0] = 2; g.board[9] = 2; g.board[18] = 2; g.board[27] = 2; // W col0, rows 0-3
        g.board[1] = 1; g.board[10] = 1; g.board[19] = 1; g.board[28] = 1; // B col1, rows 0-3
        // W group has 1 liberty at (0,4)=36
        g.board[37] = 1; // B at (1,4) — doesn't block (0,4)
        g.side = 1;
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 { match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} } }
        });
        g.hash_history = vec![g.hash];

        assert_eq!(g.count_liberties(0), 1, "W group should have 1 liberty at (0,4)");
        let g = g.apply_move(36); // B plays (0,4) → captures 4-stone W group
        assert_eq!(g.board[0], 0);
        assert_eq!(g.board[9], 0);
        assert_eq!(g.board[18], 0);
        assert_eq!(g.board[27], 0);
        assert_eq!(g.black_caps, 4);
    }

    // ── Self-atari (not suicide) ──

    #[test]
    fn test_self_atari_legal() {
        // Playing into self-atari (1 liberty remaining) is legal
        let mut g = Go::new_9x9();
        // B at (0,0). W at (1,0), (0,1). B plays (1,1)? No.
        // Simpler: B plays into a spot with only 1 liberty but doesn't capture → legal (not suicide)
        g.board[1] = 2; // W at (0,1)
        g.board[9] = 2; // W at (1,0)
        g.side = 1;
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 { match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} } }
        });
        g.hash_history = vec![g.hash];

        // B at (0,0): neighbors (0,1)=W, (1,0)=W → 0 liberties → suicide → illegal
        assert!(!g.is_legal(0), "Suicide at corner should be illegal");

        // But if B has a friendly stone adjacent that provides a liberty:
        g.board[10] = 1; // B at (1,1)
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 { match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} } }
        });
        // Now B at (1,0)=W, but (0,0)'s group won't connect to B(1,1) because (1,0) is W
        // So still suicide.
        assert!(!g.is_legal(0), "Still suicide — no friendly connection");
    }

    // ── Capture vs suicide precedence ──

    #[test]
    fn test_capture_trumps_suicide() {
        // B plays a move that looks like suicide but actually captures, making it legal
        let mut g = Go::new_9x9();
        // W at (0,0) with 1 liberty at (1,0). B at (0,1).
        g.board[0] = 2;  // W at (0,0)
        g.board[1] = 1;  // B at (0,1)
        g.side = 1;
        GZOB.with(|z| {
            g.hash = 0;
            for pos in 0..81 { match g.board[pos] { 1 => g.hash ^= z.piece[0][pos], 2 => g.hash ^= z.piece[1][pos], _ => {} } }
        });
        g.hash_history = vec![g.hash];

        // W(0,0) has 1 liberty at (1,0)=9. B plays (1,0) → captures W(0,0)
        assert!(g.is_legal(9), "Capture at (1,0) should be legal");
        let g = g.apply_move(9);
        assert_eq!(g.board[0], 0, "W(0,0) captured");
        assert_eq!(g.black_caps, 1);
    }

    // ── Scoring with territory ──

    #[test]
    fn test_scoring_territory() {
        let mut g = Go::new_9x9();
        // B wall at col=3, W wall at col=5 → neutral col=4
        for r in 0..9 { g.board[r * 9 + 3] = 1; } // B wall at col 3
        for r in 0..9 { g.board[r * 9 + 5] = 2; } // W wall at col 5
        g.side = 1;
        let pass = g.pass_action();
        let g = play_moves(&g, &[pass, pass]);
        let (bs, ws) = g.tromp_taylor_score();
        // B: 9 stones + cols 0-2 territory (9*3=27) = 36
        // W: 9 stones + cols 6-8 territory (9*3=27) + komi 7.5 = 43.5
        // Col 4 = neutral (adjacent to both B and W)
        assert_eq!(bs, 36.0, "B: 9 stones + 27 territory");
        assert_eq!(ws, 36.0 + 7.5, "W: 9 stones + 27 territory + 7.5 komi");
    }

    // ── Move count ──

    #[test]
    fn test_move_count() {
        let g = Go::new_9x9();
        let g = play_moves(&g, &[p(0,0), p(8,8), p(4,4)]);
        assert_eq!(g.move_count, 3);
    }

    // ── Occupied squares illegal ──

    #[test]
    fn test_all_occupied_illegal() {
        let g = Go::new_9x9();
        let g = g.apply_move(p(4,4)); // B at center
        let g = g.apply_move(p(3,3)); // W
        // Both occupied squares should be illegal
        assert!(!g.is_legal(p(4,4) as usize));
        assert!(!g.is_legal(p(3,3) as usize));
    }

    // ── Board size 19×19 ──

    #[test]
    fn test_19x19_play_and_capture() {
        let g = Go::new_19x19();
        let g = g.apply_move(0); // B corner (0,0)
        assert_eq!(g.board[0], 1);
        assert_eq!(g.count_liberties(0), 2); // corner = 2 libs
    }

    // ── QUARTZ preset ──

    #[test]
    fn test_go_quartz_preset() {
        use crate::mcts::MctsEngine;
        use crate::mcts::eval::UniformEval;
        use crate::mcts::quartz::QuartzController;
        use std::sync::Arc;

        for size in [9, 13] {
            let config = go_quartz(size);
            assert!(config.quartz.is_some());
            assert!(config.gvoc.is_some());
            let qcfg = config.quartz.clone().unwrap();
            let eval: Arc<UniformEval> = Arc::new(UniformEval);
            let engine = MctsEngine::new(Go::new(size, 7.5), eval, config);
            let mut ctrl = QuartzController::new(50, qcfg);
            let stats = engine.run_quartz(&mut ctrl);
            assert!(stats.iterations > 0, "{}x{} preset should run", size, size);
        }
    }

    // ── GoFastRollout ──

    #[test]
    fn test_fast_rollout_mcts() {
        use crate::mcts::{MctsConfig, MctsEngine};
        use crate::mcts::search::FixedIterations;
        use std::sync::Arc;

        let eval: Arc<GoFastRollout> = Arc::new(GoFastRollout::new(200));
        let config = MctsConfig::evaluation(2.0);
        let engine = MctsEngine::new(Go::new_9x9(), eval, config);
        engine.run(&mut FixedIterations::new(200));
        assert!(engine.best_move().is_some());
    }

    // ── Group liberty merging ──

    #[test]
    fn test_connected_group_liberties() {
        let g = Go::new_9x9();
        // Two adjacent B stones should share liberties
        let g = play_moves(&g, &[p(4,4), p(0,0), p(5,4)]);
        // B group: (4,4)+(5,4) connected vertically
        // Combined liberties: (3,4),(4,3),(4,5),(5,3),(5,5),(6,4) = 6
        assert_eq!(g.count_liberties(p(4,4) as usize), 6);
        assert_eq!(g.count_liberties(p(5,4) as usize), 6); // same group
    }

    // ── Pass doesn't change board ──

    #[test]
    fn test_pass_preserves_board() {
        let g = Go::new_9x9();
        let g = g.apply_move(p(4,4)); // B
        let board_before = g.board;
        let g = g.apply_move(g.pass_action()); // W pass
        assert_eq!(g.board, board_before);
        assert_eq!(g.side, 1); // B to play again
    }
}
