# specs/085-distillation.md

## Purpose
Teacher → Student distillation 계약을 정의한다.  
목표는 “GPU에서 강한 teacher를 만든 다음, CPU-only student로 옮겨도 Elo/품질이 유지되는가”를 측정 가능하게 만드는 것.

---

## Entities
- teacher model: 고정된 가중치(훈련 중 업데이트하지 않음)
- student model: 배포/평가 대상(경량, CPU latency 목표 포함)

---

## Inputs
- replay dataset(records): `specs/040-selfplay.md`
  - 최소: `state`, `pi_target`, `z`, `meta`
  - distill 권장: `teacher_policy`(또는 logits), `teacher_value` 포함

---

## Outputs
- student checkpoint
- exported student model(ONNX/TS)
- distillation metrics log

---

## Distillation Loss (normative)
### Policy
- 기본: `KL( soft_teacher || soft_student )`
  - temperature(T)를 쓰면 softmax(logits / T)
- teacher target이 없을 때 fallback:
  - `KL( pi_target || student_pred )` (즉, 표준 AlphaZero 학습으로 처리)

### Value
- 기본(teacher value가 있으면):
  - `MSE(v_student, v_teacher)`
- fallback:
  - `MSE(v_student, z)`

### Regularization
- L2 weight decay (필수)
- (선택) entropy regularization

---

## CPU Constraints (Student)
student는 export(ONNX) 후 CPU inference에서 다음을 만족해야 한다.
- stage별 latency 목표(p50/p95) 만족
- 수치적 안정성(NaN/inf 없음)
- 불법 수 마스킹이 정상 동작(legal_mask 또는 MCTS 마스크)

정확한 목표 값은 `specs/090-curriculum.md`에 정의한다.

---

## Invariants
- distillation 중에는 teacher 가중치가 바뀌면 안 된다.
- 같은 입력에서 teacher/student 출력 shape은 action encoding 계약을 만족해야 한다.
- distillation이 켜져도 `pi_target` 기반의 baseline 비교 실험(QUARTZ vs baseline)은 영향받지 않아야 한다.

---

## Failure Modes
- teacher/student action encoding 불일치(특히 체스)
- temperature/soft target 설정 오류로 학습이 collapse
- student가 너무 작아서 정책이 과도하게 평평해짐(탐색이 비효율)

---

## Acceptance Tests
- 작은 샘플(예: 1k step)로 distill 1 epoch가 NaN 없이 끝난다.
- export된 student 모델이 CPU에서 forward 가능하다.
- teacher 고정이 실제로 보장된다(체크섬/해시 또는 grad 차단).
