# Logging & Metrics (QUARTZ)

목표: “성능이 좋아졌다/나빠졌다”를 감으로 말하지 않고, 로그 한 장으로 결정할 수 있게 한다.  
추가 목표: 커리큘럼 stage gate(통과/실패)를 자동으로 판정할 수 있을 만큼의 정보가 로그에 있어야 한다.

---

## 0) 공통 메타(모든 이벤트에 포함 권장)
- `timestamp`
- `git_sha`
- `stage_id` (예: ttt, gomoku9, gomoku13, ...)
- `engine_mode` (baseline/quartz)
- `model_id` (teacher/student 체크포인트 해시)
- `config_hash`
- `seed`

---

## 1) 런타임(대국) 메트릭
### 1.1 시간/성능
- `move_time_ms`: 이번 수에 실제로 쓴 시간(ms)
- `move_time_budget_ms`: 목표 예산(ms)
- `difficulty_bucket`: easy / avg / hard  
  - bucket 판정 규칙(예: root entropy 임계값)은 config로 고정하고 로그에 기록
- `nps`: nodes/sec (selection+backup 포함)
- `evals_per_sec`: NN inference/sec
- `eval_batch_size_mean`: 평균 배치 크기
- `threads`: 사용 스레드 수
- `stop_reason`: time_budget / cap_reached / converged / controller_abort 등

### 1.2 트리 구조
- `root_N`: 루트 방문수
- `root_branching`: 확장된 자식 수
- `avg_depth`, `max_depth`
- `pw_frontier_size`: widening frontier(있다면)

### 1.3 TT
- `tt_hits`, `tt_misses`
- `tt_hit_rate`
- `tt_collisions`
- `tt_size`
- `tt_lock_wait_ms`(가능하면): 락 경합 진단

### 1.4 정책/불확실성(진단)
- `root_entropy`: H(π_root)
- `root_top1`, `root_top2`, `root_topk_mass`
- `root_value`, `root_value_std`(가능하면)

---

## 2) 학습 메트릭 (Teacher / Student)
### 2.1 공통
- `policy_loss`
- `value_loss`
- `entropy_reg`(쓰면)
- `l2_norm`
- `lr`
- `steps/sec`

### 2.2 self-play 생성
- `selfplay_games/sec`
- `avg_game_len`
- `resign_rate`(쓰면)
- `buffer_size`
- `samples/sec`(train loader)

### 2.3 distillation(teacher→student)
- `distill_policy_kl`
- `distill_value_mse`
- `student_latency_ms_p50/p95` (ONNX smoke 또는 microbench)
- `student_throughput_eval_per_sec`

---

## 3) 평가(Elo)
### 3.1 최소 로그
- 매 게임: winner, color, opening_id, seed, move_times summary
- 매 매치: 승/패/무, 평균 시간, confidence interval

### 3.2 Elo 추정(권장)
- 로지스틱 모델:
  - P(win) = sigmoid((Elo_A - Elo_B)/400 * ln 10)
- 또는 BayesElo(외부 툴)

### 3.3 Stage Gate 판정에 필요한 요약값
- time distribution:
  - p50/mean/p95/p99(move_time_ms)
  - bucket별 mean(move_time_ms)
- Elo delta:
  - baseline 대비 ΔElo, CI
- 안정성:
  - crash_count, timeout_count, illegal_move_count

---

## 4) 로그 포맷(권장)
- JSONL: 1 line = 1 event
  - `event_type`: move/train/eval/game_end/distill/stage_gate
- 큰 배열(π 등)은 별도 binary로 저장하거나 top-k만 남긴다.
