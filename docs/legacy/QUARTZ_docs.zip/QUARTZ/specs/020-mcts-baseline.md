# specs/020-mcts-baseline.md

## Purpose
공정 비교를 위한 baseline AlphaZero-style MCTS를 정의한다.

## Inputs
- `root_state: State`
- `nn: PolicyValueNet`
- `time_budget_ms: int`
- `threads: int`
- `tt: TranspositionTable(shared)`

## Output
- `best_move: Move`
- plus diagnostics(stats/log events)

## Algorithm (normative)
- Selection: PUCT
- Expansion: leaf에서 NN 평가 1회 → prior/value로 자식 생성
- Backup: negamax value backup
- Root: 학습 시 Dirichlet noise + temperature

## Required Features (Fairness)
- shared TT
- tree parallel + virtual loss
- batch inference server(가능하면)

## Invariants
- visit count는 음수가 될 수 없다.
- terminal node는 확장하지 않는다.
- backprop 값의 부호는 플레이어 전환에 따라 일관되게 뒤집힌다.

## Failure Modes
- race로 N/W가 깨짐(음수/NaN)
- TT collision으로 잘못된 node 재사용
- deadlock

## Acceptance Tests
- TicTacToe에서 충분한 시간(예: 1s) 주면 최적 수를 고른다.
- 동일 seed + deterministic 모드에서 root 방문분포가 재현된다(허용 오차 명시).
- 멀티스레드에서 10^6 simulation 스트레스 시 크래시/데드락이 없다.
