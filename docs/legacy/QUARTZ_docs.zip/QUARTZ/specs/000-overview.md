# specs/000-overview.md

## Purpose
이 디렉토리는 QUARTZ의 spec-driven development를 위한 “계약 문서” 모음이다.  
구현은 반드시 해당 spec을 만족해야 하며, spec 변경 없이 의미 있는 동작 변경을 하면 안 된다.

## Spec 목록
- 010-game-api.md
- 020-mcts-baseline.md
- 030-nn-model.md
- 040-selfplay.md
- 050-training.md
- 060-eval.md
- 070-reproducibility.md
- 080-performance.md
- 085-distillation.md
- 090-curriculum.md

## 규칙
- PR은 반드시 “관련 spec 링크”를 포함한다.
- spec이 없는 신규 모듈은 병합하지 않는다.
- 커리큘럼(stage gate) 관련 변경은 `090-curriculum.md`와 함께 업데이트한다.
