# specs/030-nn-model.md

## Purpose
정책+가치 NN의 입/출력 계약을 정의한다. (구조는 바뀔 수 있어도 계약은 유지)  
추가로, 커리큘럼(9×9→13×13→15×15) 확장을 위해 “보드 크기 변화”를 다루는 최소 원칙을 포함한다.

---

## Inputs
- `x: Tensor[batch, channels, H, W]`  
  - H,W는 게임/보드 크기(예: 9/13/15/8/19)
- (권장) `legal_mask: Tensor[batch, A]` (optional)  
  - 불법 수 마스킹용(없으면 MCTS가 마스크 처리)

## Outputs
- `policy_logits: Tensor[batch, A]`
- `value: Tensor[batch, 1]`  in [-1, +1]

여기서 A는 “게임이 정의한 행동 공간”이다.
- 격자형 게임(오목/바둑 등): 보통 `A = H*W (+ pass 옵션)`  
- 체스: move encoding에 따라 A가 더 크며, `legal_mask`로 필터링한다.

---

## Requirements
- policy+value를 1회 forward로 계산한다.
- CPU inference path가 존재해야 한다(ONNX/TS 등).
- (권장) policy head는 **fully-convolutional**로 설계한다.
  - 목적: 9×9에서 학습한 표현을 13×13/15×15로 전이(fine-tune)할 때 재사용성 확보

## Invariants
- value 범위 clamp 또는 tanh.
- illegal moves 마스킹은 MCTS 쪽에서 처리하되, NN도 가능하면 `legal_mask` 입력을 받아 마스크 후 logits를 내보낼 수 있다.
- 동일 입력/동일 가중치/동일 seed에서 forward는 결정론적이어야 한다(허용 오차는 runtime에 따라 명시).

---

## Architecture Profiles (권장 프리셋)
이 프로젝트는 “teacher(강함/빠른 부팅) → student(CPU-only)” 전략을 기본으로 둔다.

### Teacher (GPU 우선)
- **Teacher-S**: ResNet 10 blocks × 128 channels + SE + (가벼운) gpool
- **Teacher-M**: ResNet 15 × 192 + SE + gpool
- **Teacher-L**: ResNet 20 × 256 + SE + gpool

### Student (CPU-only 배포)
- **Student-S**: ResNet 6 × 96 (또는 8 × 96) + 최소 gpool  
  - ONNXRuntime(oneDNN) 기준 latency 목표를 맞추기 쉬운 크기
- **Student-XS(옵션)**: depthwise-separable(conv) 기반 경량 모델(quant-ready)

> 주의: 커리큘럼 초반엔 Teacher-S/M만으로도 충분할 때가 많다.  
> “교사가 너무 크면” self-play throughput이 줄어 오히려 학습이 느려질 수 있다.

---

## Board-size Scaling Options (9→13→15)
### Option A (기본): Fully-Conv + Transfer
- 같은 구조를 유지하고, 작은 보드 체크포인트에서 큰 보드로 fine-tune한다.

### Option B (권장 강화): 좌표/경계 feature 추가
- x/y 좌표 plane, edge distance plane, 보드 크기 meta 등을 input channel로 추가해
  “크기가 달라져도 같은 패턴”을 학습하기 쉽게 만든다.

### Option C (실험): 작은 GNN head
- 앞단에 매우 작은 message passing(2~4 step)을 둬 size-invariant inductive bias를 준다.
- 장점: 스케일 변화에 둔감해질 가능성
- 단점: CPU inference에서 느려질 수 있으므로 teacher에서 먼저 검증 후 student로 이식

---

## Export Profiles (CPU runtime)
- 기본: stage별로 **고정 H,W** 모델을 export(ONNX)한다. (가장 안정적)
- 실험: dynamic H,W ONNX export(가능하면).  
  - 이 경우 runtime/최적화가 까다로울 수 있어 stage gate에는 “실험 기능”으로만 포함한다.

---

## Acceptance Tests
- encode→forward가 shape error 없이 돌아간다.
- (옵션 A/B) H,W가 다른 입력(예: 9,13,15)에 대해 forward가 동작한다(teacher 학습 시).
- export(onnx/ts) 후 CPU에서 동일 입력에 대해 수치 오차 범위 내로 일치한다.
- student 모델은 CPU microbench에서 latency(p50/p95)가 stage gate 목표를 만족한다(목표는 `specs/090-curriculum.md`).
