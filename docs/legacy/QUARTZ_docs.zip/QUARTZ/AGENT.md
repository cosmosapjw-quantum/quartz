# AGENT.md (LLM Coding Agent Playbook)

이 문서는 “LLM 코딩 에이전트”가 QUARTZ 리포에 PR을 넣을 때 지켜야 하는 규칙이다.  
(사람 1명 + 에이전트 여러 명이 동시에 손대도 망하지 않게 만드는 게 목적)

---

## 0) 가장 중요한 원칙 5개
1. **Baseline을 먼저**: QUARTZ 모듈(동적 truncation)은 baseline이 검증된 다음에 켠다.
2. **공정 비교 계약 위반 금지**: baseline과 QUARTZ의 차이는 “모듈 ON/OFF”만이어야 한다.
3. **성능 변경 PR은 로그/지표 업데이트를 포함**: nps, eval/sec, time histogram 없으면 성능 PR로 취급 안 함.
4. **락/스레드 관련 수정은 반드시 스트레스 테스트 추가**: race/데드락은 한 번 터지면 끝이다.
5. **새 하이퍼파라미터 추가는 ‘자동화 or 제거’가 기본**: 의미/스케일/튜닝 경로가 문서화되지 않으면 거절.

---

## 1) 작업 단위(권장)
- “Spec 1개 → 구현 → 테스트 → 로그 지표 1개”
- 거대한 PR 금지. 300~800줄 수준을 넘기면 잘게 쪼개.

---

## 2) 코드 스타일/구조 합의
- Python: type hints 필수, dataclass 적극 사용
- C++: 핵심 루프(선택/백업/TT) 쪽은 C++로 이관 가능성 항상 고려
- 경계: Python은 오케스트레이션/학습/데이터, C++은 엔진/핫루프/TT

---

## 3) 성능/병렬화 규칙
- tree parallel 기본: **shared TT + virtual loss + atomic counters**
- 공유 자료구조는 “잠금 범위 최소화” + “읽기 최적화”
- 측정 없이 최적화 금지. (프로파일 결과를 PR에 첨부)

---

## 4) 테스트 규칙(최소)
- `tests/test_engine_api.py`: 엔진 wrapper 불변조건
- `tests/test_mcts_invariants.py`: 방문수/백업/terminal 처리
- `tests/test_tt_thread_safety.py`: 멀티스레드 스트레스
- `tests/test_reproducibility.py`: seed 고정 시 재현성

---

## 5) 로그/지표(필수)
- move time: mean/p50/p90/p99
- nps(nodes/sec), eval/sec
- TT hit rate, collision rate
- average branching factor, expansions
- training: policy loss, value loss, entropy, Elo trend

(정의는 `docs/LOGGING_METRICS.md`)

---

## 6) “금지된 변경” 목록
- baseline과 QUARTZ의 엔진/NN 구조를 다르게 바꾸는 것
- 평가 시 opening/randomness를 다르게 주는 것
- time budget을 슬쩍 바꾸는 것
- TT 키/충돌 정책을 몰래 바꾸는 것(비교 무의미해짐)

---

## 7) PR 템플릿(에이전트가 반드시 채울 것)
- 변경 목적:
- 변경 범위(파일/모듈):
- spec 참조: (예: specs/020-mcts-baseline.md)
- 테스트:
- 성능 전/후:
- 리스크:
- 롤백 플랜:
