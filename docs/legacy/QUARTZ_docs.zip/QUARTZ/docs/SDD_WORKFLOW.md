# Spec-Driven Development Workflow (QUARTZ)

## 목적
이 프로젝트는 “연구 아이디어”가 많고, 성능/공정성/재현성이 중요하다.  
그래서 코드는 “대충 구현하고 나중에 고치기” 방식으로 가면 결국 무너진다.

SDD는 아래를 강제한다:
- 컴포넌트 계약(API/불변조건/테스트)을 먼저 쓴다
- 구현은 그 계약을 만족시키는 방향으로만 한다
- 변경은 spec 업데이트와 함께 한다

---

## 개발 루프(권장)
1) Spec 작성/수정
2) 테스트 작성(최소: 불변조건 + 실패 케이스)
3) 구현
4) 프로파일/로그 확인
5) 문서 업데이트(설계/파이프라인)

---

## Spec 템플릿(요약)
각 spec 문서는 최소한 아래를 포함한다.

- Purpose (왜 존재?)
- Inputs/Outputs (형식, 단위, shape)
- Invariants (항상 참이어야 하는 것)
- Failure modes (어떻게 망가질 수 있나)
- Concurrency (thread-safety 요구)
- Acceptance tests (통과 기준)

---

## Baseline vs QUARTZ 변경 규칙
- baseline spec은 “고정”이다.
- QUARTZ spec은 baseline 위에 “hook”으로 추가한다.
- baseline의 결과가 바뀌면(같은 seed에서 분포가 달라지는 수준) 반드시 이유를 명시해야 한다.

