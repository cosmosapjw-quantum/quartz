# QUARTZ PRD (Product Requirements Document)
작성일: 2026-01-28

## 0. 한 줄 요약
QUARTZ는 “최종 배포는 CPU-only”를 전제로, **공정한 AlphaZero-style baseline(MCTS+정책/가치 NN)** 을 먼저 만들고, 그 위에 **동적/적응형 탐색 시간 재배치(QUARTZ SearchController)** 를 플러그인처럼 얹어 “같은 평균 시간 예산에서 더 높은 Elo”를 노리는 게임-불문(board-game-agnostic) AI 프로젝트다.

> 핵심: “추가 계산”이 아니라 “계산 재배치”로 이겨야 한다.  
> 쉬운 수는 0.5초 내, 평균은 5초 내, 정말 어려운 수만 15초 내(최대 30초 cap)로 분포를 만들고,
> 같은 평균 예산에서 Elo가 오르는지 본다.

---

## 1. 배경 / 문제정의
AlphaZero류는 강력하지만, 실전(특히 소비자용 CPU)에서는 다음이 병목이다.

- MCTS가 “고정된 시뮬레이션 수/시간”으로 돈다 → 쉬운 수에서도 불필요하게 오래 계산하거나, 어려운 수에서 부족하게 계산한다.
- GPU-의존적 추론 경로(자주 CPU↔GPU 왕복) → 데스크탑/노트북/서버 환경 다양성에서 손해.
- game-agnostic을 목표로 하면, 특정 게임 최적화 코드(수기 휴리스틱)에 기대기 어렵다.

따라서 QUARTZ는 **동일한 평균 시간 예산(기본값: 5초/수)에서, “난이도에 따라 계산을 재분배”** 하는 방향을 제품 요구로 둔다.

---

## 2. 목표(Goals)

### 2.1 1차 목표(필수): 공정한 baseline 구축 + QUARTZ ON/OFF Elo 차이 검증
- 동일 엔진/동일 NN 구조/동일 TT/동일 병렬화 조건에서
  - Baseline(naive fixed-budget PUCT MCTS) vs QUARTZ(적응형 compute scheduling ON)
  - **Elo 상승**을 정량 확인.

### 2.2 2차 목표(필수): CPU-only 런타임 + “안정적인 시간 분포”
- 소비자용 CPU(AVX2 가정, Intel/AMD 무관)에서
  - 쉬운 수: **p50 ≤ 0.5초**
  - 평균: **mean ≤ 5초**
  - 어려운 수: **(난이도 상위 구간의) mean ≤ 15초**
  - 최악: **p99 ≤ 30초**(cap)
- “안정성”의 의미:
  - 타임아웃/크래시 0
  - p99 스파이크(예: 5초 예산에서 60초 튐) 없도록 제어

### 2.3 3차 목표: 단계별 커리큘럼(스펙 기반) 확장
- 커리큘럼(순차 진행, stage gate 통과 후 다음으로):
  1) TicTacToe
  2) Gomoku 9×9
  3) Gomoku 13×13
  4) Gomoku 15×15
  5) Renju 15×15
  6) Chess / Chess960 (아마추어 수준 “가능성 실험”)
  7) Go 9×9
  8) Go 19×19 (아마추어 수준 “가능성 실험”)

> Stage gate(승격 조건)는 `specs/090-curriculum.md`에 고정한다.  
> “그럴듯해 보인다”는 감상으로 다음 단계로 넘어가지 않는다.

### 2.4 4차 목표(선택): 교사(Teacher) → 학생(Student) distillation로 CPU-only 품질 상승
- 학습 단계에서는 GPU(단일 3090 포함)로 “더 강한 교사 정책/가치”를 만들고,
- 배포 단계에서는 CPU-only 학생 모델(경량)을 distill/추가학습해서
  - CPU-only에서도 Elo가 유지/상승하는지 검증한다.

> Distillation 계약은 `specs/085-distillation.md`로 고정한다.

---

## 3. 비목표(Non-Goals, 지금은 안 함)
- hidden-information / stochastic / multi-player(>2) 게임.
- MuZero처럼 dynamics를 학습하는 world-model(규칙이 완전한 보드게임에서는 우선순위 낮음).
- “인간식 도메인 휴리스틱”(오목 위협공간 탐색 등) 직접 내장. (나중에 ablation으로 검토는 가능)
- v0에서 “19×19 바둑 CPU-only 강한 엔진” 달성(장기 과제)

---

## 4. 사용자/사용 시나리오
### 4.1 연구자 모드(너)
- Linux에서 self-play + 학습(로컬 1GPU 또는 외부 GPU) + 로컬 CPU 평가.
- 모듈을 켰다/껐다 하는 ablation으로 “진짜 기여” 확인.
- 성능 병목을 프로파일링해서 Python→C++ 이행 기준을 만든다.
- 커리큘럼 stage gate를 통과할 때만 다음 게임/보드 크기로 확장한다.

### 4.2 외부 검증
- Gomoku/Renju: Gomocup Manager 기반 토너먼트로 Elo/승률 외부 검증(가능하면).

---

## 5. 핵심 요구사항(Functional)
### 5.1 Game API (game-agnostic)
- `legal_moves(s)`, `apply_move(s,a)`, `is_terminal(s)`, `outcome(s)`
- TT용 `hash(s)` + 대칭(canonicalization) 지원
- (선택) 대칭 변환 목록 반환(학습 데이터 증강)

### 5.2 Baseline MCTS (공정 비교용)
- PUCT selection
- Dirichlet noise(학습 시 루트)
- Transposition Table(공유)
- Tree parallelization(가상 손실/원자적 카운트)
- NN inference batching(가능한 한 CPU에서 벡터화)
- **시간 분배는 baseline/QUARTZ 동일한 “budget policy”를 공유**하고,
  QUARTZ는 “budget을 어디에 더 쓸지”만 바꾼다(계약).

### 5.3 Training loop
- self-play 데이터 생성 → 리플레이 버퍼 → 학습 → 모델 export
- 정책+가치 네트워크 1회 추론으로 `(π, v)` 생성
- (선택) teacher 정책/가치를 저장하고 student로 distill

### 5.4 Evaluation
- 내부: arena match(200~1000판), 고정 opening set, 색상 스왑
- 외부: Gomocup(가능하면)
- Elo + 신뢰구간(CI) 산출

---

## 6. 핵심 요구사항(Non-Functional)
- 재현성: seed 고정, deterministic 모드 제공(속도는 느려져도 됨)
- 성능: nps(nodes/sec), eval/sec, move-time histogram 로깅
- 이식성: Linux 개발, Windows 실행(또는 Wine) 고려
- 관측가능성: “왜 이 수에 시간을 썼는지” 설명 가능한 로그(계층적)
- 확장성: 보드 크기 변경(9→13→15) 시 “완전 재학습”만이 답이 되지 않게,
  (a) 완전 컨브 정책 head / (b) 좌표·보드크기 feature / (c) 선택적 GNN head 등을 실험 옵션으로 둔다.

---

## 7. 성공 지표(Success Metrics)
- **Elo**: baseline 대비 +X(초기 목표: +50 Elo, 단계별로 상향)
- **시간 분포**: (쉬운/평균/어려운) 분포가 실제로 생기고 안정적으로 유지
- **효율**: 동일 평균 예산에서 baseline보다 더 높은 승률(또는 Elo)
- **안정성**: 크래시 0, TT/병렬화 race condition 0
- **CPU-only 현실성**: 쉬운 게임(TicTacToe~Gomoku 9×9)에서는
  “CPU-only로도 학습된 정책이 크게 답답하지 않은 속도”를 만족

---

## 8. 공정 비교 원칙(Baseline Fairness Contract)
QUARTZ 모듈의 “추가 계산”이 아니라 “계산 재배치”가 이득인지 보려면,
baseline도 아래를 동일하게 갖춰야 한다:

- 동일한 TT(충돌 정책 포함)
- 동일한 tree parallel 정책(virtual loss 등)
- 동일한 NN(구조/가중치/추론 엔진)
- 동일한 time budget policy(쉬움/평균/어려움 분포 정책)
- 동일한 opening/randomness(학습/평가 프로토콜)

(상세는 `docs/BASELINE_FAIRNESS.md`)

---

## 9. 리스크 / 완화
- (R1) 오목/렌주는 선후수/오프닝 편향이 큼 → opening set, 색상 스왑, 규칙(renju)로 완화
- (R2) CPU에서 NN 추론이 병목 → ONNXRuntime/oneDNN, batch inference, (추후) int8/quant
- (R3) 파이썬 멀티스레드/락 오버헤드 → 프로세스 병렬 + C++ 핫루프 이관
- (R4) “모듈이 복잡하지만 이득이 없다” → stage gate, ablation, 실패 기준을 빨리 통과/컷
- (R5) 보드 크기 확장 시 매번 재학습 비용 폭발 → transfer, fully-conv head, (선택) small GNN head로 실험

---

## 10. 마일스톤(커리큘럼 기반)
- M0: Game API + TicTacToe acceptance test(최적 수) + seed 재현성
- M1: Gomoku 9×9 baseline end-to-end + CPU-only 평가 + Elo 산출 자동화
- M2: Gomoku 13×13/15×15 확장(재학습/전이 전략 비교)
- M3: Renju 15×15(룰/오프닝) + 공정 비교
- M4: Chess/Chess960 “가능성 실험”(아마추어 수준 도달 여부)
- M5: Go 9×9 → Go 19×19 “가능성 실험”
