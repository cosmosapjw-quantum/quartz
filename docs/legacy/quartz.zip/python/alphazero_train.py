#!/usr/bin/env python3
"""
QUARTZ AlphaZero Training Pipeline — End-to-End
================================================
Actual working self-play → replay → train → checkpoint loop.

Usage:
  python3 alphazero_train.py --game gomoku15 --iterations 50
  python3 alphazero_train.py --game gomoku7 --iterations 10 --device cpu
  python3 alphazero_train.py --serve --game gomoku15 --model alphazero_gomoku15/best.pt

Requirements: torch, numpy, tqdm
GPU:          pip install torch --index-url https://download.pytorch.org/whl/rocm6.2
              export HSA_OVERRIDE_GFX_VERSION=10.3.0
"""
import os, sys, json, select, time, argparse, subprocess, random, math, signal, threading, logging
import numpy as np
from dataclasses import dataclass
from pathlib import Path
from collections import deque

# Game-agnostic encoder system
try:
    from quartz.encoders import get_encoder, GameEncoder
except ImportError:
    # Fallback: encoders.py in same directory
    try:
        from encoders import get_encoder, GameEncoder
    except ImportError:
        get_encoder = None


def encode_board(cfg, board_flat, player):
    """Game-agnostic board encoding using registered encoder."""
    enc_obj = cfg.get('_encoder')
    if enc_obj is not None:
        return enc_obj.encode(board_flat, player)
    # Legacy fallback: 3-plane encoding
    bs = cfg['board']; n2 = bs * bs
    enc = np.zeros((cfg['ch'], bs, bs), dtype=np.float32)
    for i in range(n2):
        r, c = i // bs, i % bs
        if board_flat[i] == player: enc[0, r, c] = 1.0
        elif board_flat[i] != 0: enc[1, r, c] = 1.0
    if cfg['ch'] >= 3 and player == 1: enc[2] = 1.0
    return enc


def decode_board(cfg, enc, player):
    """Reconstruct flat board from encoded tensor."""
    enc_obj = cfg.get('_encoder')
    if enc_obj is not None:
        return enc_obj.decode(enc, player)
    # Legacy fallback
    bs = cfg['board']; board = np.zeros(bs * bs, dtype=np.int8)
    for r in range(bs):
        for c in range(bs):
            if enc[0, r, c] > 0.5: board[r * bs + c] = player
            elif enc[1, r, c] > 0.5: board[r * bs + c] = -player
    return board

try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False
    class tqdm:
        """Fallback when tqdm not installed."""
        def __init__(self, iterable=None, total=None, desc="", leave=True, **kw):
            self.iterable = iterable; self.total = total; self.desc = desc; self.n = 0
        def __iter__(self):
            for x in self.iterable: yield x; self.n += 1
        def __enter__(self): return self
        def __exit__(self, *a): pass
        def update(self, n=1): self.n += n
        def set_postfix_str(self, s): pass
        def set_postfix(self, **kw): pass
        def close(self): pass

import torch
import torch.nn as nn
import torch.nn.functional as F

# ═══════════════════════════════════════════
# § Game Configs
# ═══════════════════════════════════════════

GAME_CONFIGS = {
    "gomoku7":  dict(board=7,  ch=3, actions=49,  win=4, filters=64,  blocks=4, vh=64,  iters=200, games=200, temp_th=8,  dir_a=0.5,  buf=200_000,  steps=100, batch=256, penalty_mode="GatedRefresh", hbar_penalty_cap=0.3, c_puct=2.0),
    "gomoku15": dict(board=15, ch=3, actions=225, win=5, filters=128, blocks=8, vh=256, iters=400, games=100, temp_th=15, dir_a=0.15, buf=500_000,  steps=200, batch=512, penalty_mode="GatedRefresh", hbar_penalty_cap=0.3, c_puct=2.0),
    "go9":      dict(board=9,  ch=17,actions=82,  win=0, filters=128, blocks=10,vh=256, iters=600, games=60,  temp_th=12, dir_a=0.3,  buf=1_000_000,steps=300, batch=512, penalty_mode="GatedRefresh", hbar_penalty_cap=0.3, c_puct=2.5),
    "chess":    dict(board=8,  ch=16, actions=4672,win=0, filters=128, blocks=10,vh=256, iters=800, games=40,  temp_th=15, dir_a=0.3,  buf=1_000_000,steps=400, batch=256, penalty_mode="GatedRefresh", hbar_penalty_cap=0.3, c_puct=2.5),
}

# ═══════════════════════════════════════════
# § NN Architecture
# ═══════════════════════════════════════════

class SEBlock(nn.Module):
    def __init__(self, ch, r=4):
        super().__init__()
        self.fc = nn.Sequential(nn.Linear(ch, ch//r), nn.ReLU(), nn.Linear(ch//r, ch), nn.Sigmoid())
    def forward(self, x):
        w = x.mean(dim=(2,3))
        return x * self.fc(w).unsqueeze(-1).unsqueeze(-1)

class ResBlock(nn.Module):
    def __init__(self, ch, se=False):
        super().__init__()
        self.net = nn.Sequential(
            nn.BatchNorm2d(ch), nn.ReLU(), nn.Conv2d(ch,ch,3,padding=1,bias=False),
            nn.BatchNorm2d(ch), nn.ReLU(), nn.Conv2d(ch,ch,3,padding=1,bias=False))
        self.se = SEBlock(ch) if se else None
    def forward(self, x):
        out = self.net(x)
        if self.se: out = self.se(out)
        return x + out

class AlphaZeroNet(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        ch, bs = cfg['filters'], cfg['board']
        n2 = bs * bs
        self.input_conv = nn.Sequential(nn.Conv2d(cfg['ch'],ch,3,padding=1,bias=False), nn.BatchNorm2d(ch), nn.ReLU())
        blocks = [ResBlock(ch, se=(i >= cfg['blocks']-2)) for i in range(cfg['blocks'])]
        self.tower = nn.Sequential(*blocks)
        self.p_head = nn.Sequential(nn.Conv2d(ch,32,1,bias=False), nn.BatchNorm2d(32), nn.ReLU(),
                                    nn.Conv2d(32,4,1,bias=False), nn.BatchNorm2d(4), nn.ReLU())
        self.p_fc = nn.Linear(4*n2, cfg['actions'])
        self.v_head = nn.Sequential(nn.Conv2d(ch,32,1,bias=False), nn.BatchNorm2d(32), nn.ReLU())
        self.v_fc = nn.Sequential(nn.Linear(32, cfg['vh']), nn.ReLU(), nn.Linear(cfg['vh'], 1), nn.Tanh())

    def forward(self, x):
        h = self.tower(self.input_conv(x))
        p = self.p_head(h).reshape(h.size(0),-1)
        p = self.p_fc(p)
        v = self.v_head(h).mean(dim=(2,3))
        v = self.v_fc(v).squeeze(-1)
        return p, v

# ═══════════════════════════════════════════
# § Replay Buffer
# ═══════════════════════════════════════════

class ReplayBuffer:
    def __init__(self, capacity):
        self.buf = deque(maxlen=capacity)
        self._lock = threading.Lock()

    def add(self, state, policy, value):
        with self._lock:
            self.buf.append((state, policy, value))

    def add_game(self, states, policies, outcome):
        """Add full game: assign value by alternating signs from outcome."""
        with self._lock:
            for i, (s, p) in enumerate(zip(states, policies)):
                steps_from_end = len(states) - 1 - i
                val = outcome * ((-1) ** steps_from_end)
                self.buf.append((s, p, val))

    def sample(self, n):
        with self._lock:
            indices = random.sample(range(len(self.buf)), min(n, len(self.buf)))
            batch = [self.buf[i] for i in indices]
        states = torch.stack([torch.tensor(b[0]) for b in batch])
        policies = torch.stack([torch.tensor(b[1]) for b in batch])
        values = torch.tensor([b[2] for b in batch], dtype=torch.float32)
        return states, policies, values

    def __len__(self):
        return len(self.buf)

    def save(self, path):
        data = list(self.buf)
        np.savez_compressed(path,
            states=np.array([d[0] for d in data]),
            policies=np.array([d[1] for d in data]),
            values=np.array([d[2] for d in data], dtype=np.float32))

    def load(self, path):
        if not os.path.exists(path): return 0
        d = np.load(path)
        n = len(d['states'])
        for i in range(n):
            self.buf.append((d['states'][i], d['policies'][i], float(d['values'][i])))
        return n

# ═══════════════════════════════════════════
# § TreeMCTS (arena evaluation only — not used for training)
# ═══════════════════════════════════════════

class MCTSNode:
    """Array-based MCTS node — children stored as parallel numpy arrays.
    
    Optimization: vectorized PUCT selection via numpy instead of Python for-loop.
    Vectorized PUCT provides significant speedup over per-child-object iteration.
    """
    __slots__ = ['move', 'child_moves', 'child_n', 'child_w', 'child_prior',
                 'child_nodes', 'n_children', 'is_expanded', 'total_n']

    def __init__(self, parent=None, move=None, prior=0.0):
        self.move = move if move is not None else -1
        self.child_moves = None
        self.child_n = None
        self.child_w = None
        self.child_prior = None
        self.child_nodes = None  # dict: child_idx → MCTSNode
        self.n_children = 0
        self.is_expanded = False
        self.total_n = 0

    def expand(self, legal_moves, priors):
        k = len(legal_moves)
        self.child_moves = np.array(legal_moves, dtype=np.int32)
        self.child_n = np.zeros(k, dtype=np.int32)
        self.child_w = np.zeros(k, dtype=np.float32)
        p = np.array([priors[m] if m < len(priors) else 1.0/max(k,1)
                       for m in legal_moves], dtype=np.float32)
        ps = p.sum()
        if ps > 0: p /= ps
        self.child_prior = p
        self.child_nodes = {}
        self.n_children = k
        self.is_expanded = True
        self.total_n = 0

    def select_child_vectorized(self, c_puct):
        """Vectorized PUCT: one numpy op instead of per-child Python loop."""
        n = self.child_n
        unvisited = (n == 0)
        if unvisited.any():
            scores = np.where(unvisited,
                              1e6 + self.child_prior * 1000 + np.random.random(self.n_children) * 0.01,
                              -1e9)
            return int(np.argmax(scores))
        q = self.child_w / np.maximum(n.astype(np.float32), 1)
        sqrt_total = math.sqrt(self.total_n + 1)
        u = c_puct * self.child_prior * sqrt_total / (1 + n.astype(np.float32))
        return int(np.argmax(q + u))

    def backup_child(self, ci, value):
        self.child_n[ci] += 1
        self.child_w[ci] += value
        self.total_n += 1

    @property
    def n(self):
        return self.total_n

    @property
    def w(self):
        return float(self.child_w.sum()) if self.child_w is not None else 0.0

    @property
    def children(self):
        """Compatibility: iterate child nodes (for arena/eval code)."""
        if self.child_nodes is None: return []
        return list(self.child_nodes.values())


# ──── LEGACY: Arena evaluation helper only (not used in training) ────
class TreeMCTS:

    """Optimized tree MCTS with array-based nodes and vectorized PUCT.
    
    select → expand → evaluate → backup.
    Children stored as numpy arrays per node; PUCT computed in one numpy op.
    
    Accuracy enhancements (speed-neutral, −10% overhead):
    - Heuristic prior at root: threat/adjacency patterns for gomoku/go (1 call only)
    - Fast leaf value: O(4) line check from last move (not full-board scan)
    - FPU reduction: parent_value - offset for unvisited children
    
    Accuracy enhancements improve forced-move detection and H2H win rate vs uniform baseline.
    """
    FPU_OFFSET = 0.25
    FPU_PRIOR_WEIGHT = 3.0

    def __init__(self, cfg, model=None, device='cpu'):
        self.cfg = cfg
        self.model = model
        self.device = device
        self.n_actions = cfg['actions']
        self.board_size = cfg['board']
        self.penalty_mode = cfg.get('penalty_mode', 'GatedRefresh')
        self.c_puct = cfg.get('c_puct', 2.0)
        self._win_len = cfg.get('win', 0)
        self._encoder = cfg.get('_encoder')
        self._has_heuristic = hasattr(self._encoder, 'heuristic_prior') if self._encoder else False

    def _gomoku_heuristic_prior(self, board, player):
        """Delegate to encoder's heuristic_prior (game-agnostic)."""
        if self._encoder is not None:
            return self._encoder.heuristic_prior(board, player)
        n2 = self.board_size ** 2
        legal = np.zeros(self.n_actions, dtype=np.float32)
        for i in range(min(n2, self.n_actions)):
            if board[i] == 0: legal[i] = 1.0
        s = legal.sum()
        return legal / s if s > 0 else np.ones(self.n_actions, dtype=np.float32) / self.n_actions

    def _fast_leaf_value(self, board, last_move, player_who_moved):
        """Delegate to encoder's fast_leaf_value (game-agnostic)."""
        if self._encoder is not None:
            return self._encoder.fast_leaf_value(board, last_move, player_who_moved)
        return 0.0

    def _apply_move_board(self, board, player, action):
        new_board = board.copy()
        new_board[action] = player
        won = False
        wl = self.cfg.get('win', 0)
        if wl > 0:
            bs = self.board_size
            r0, c0 = action // bs, action % bs
            for dr, dc in ((0,1),(1,0),(1,1),(1,-1)):
                cnt = 1
                for sign in (1,-1):
                    nr, nc = r0+sign*dr, c0+sign*dc
                    while 0<=nr<bs and 0<=nc<bs and new_board[nr*bs+nc]==player:
                        cnt += 1; nr += sign*dr; nc += sign*dc
                if cnt >= wl: won = True; break
        return new_board, -player, won

    def _encode(self, board, player):
        return encode_board(self.cfg, board, player)

    def _evaluate_leaf(self, board, player):
        if self.model is not None:
            enc = self._encode(board, player)
            with torch.no_grad():
                x = torch.tensor(enc, dtype=torch.float32).unsqueeze(0).to(self.device)
                logits, val = self.model(x)
                probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
                return probs, val.item()
        else:
            probs = np.ones(self.n_actions, dtype=np.float32)
            n2 = self.board_size ** 2
            for i in range(min(n2, self.n_actions)):
                if board[i] != 0: probs[i] = 0
            s = probs.sum()
            if s > 0: probs /= s
            return probs, 0.0

    def search(self, board_enc, player, legal_mask, n_iters):
        """Run tree MCTS (used by arena evaluation).
        
        """
        board = decode_board(self.cfg, board_enc, player)

        bs = self.board_size
        legal_indices = [i for i in range(min(self.n_actions, bs*bs)) if board[i] == 0]
        if not legal_indices:
            return np.zeros(self.n_actions, dtype=np.float32)

        # Root prior
        if self.model is not None:
            priors, root_val = self._evaluate_leaf(board, player)
        elif self._has_heuristic:
            priors = self._gomoku_heuristic_prior(board, player)
            root_val = 0.0
        else:
            priors, root_val = self._evaluate_leaf(board, player)

        root = MCTSNode()
        root.expand(legal_indices, priors)

        state = _SearchState(root=root, board=board, player=player, root_val=root_val, cfg=self)

        for it in range(n_iters):
            leaf = state.select_to_leaf()
            if leaf.is_terminal:
                state.backup(leaf, leaf.terminal_value)
            elif self.model is not None:
                priors, val = self._evaluate_leaf(leaf.board, leaf.player)
                state.expand_and_backup(leaf, priors, val)
            else:
                child_uniform = np.ones(self.n_actions, dtype=np.float32) / max(self.n_actions, 1)
                val = self._fast_leaf_value(leaf.board, leaf.last_move, -leaf.player)
                state.expand_and_backup(leaf, child_uniform, val)

        return state.extract_policy(self.n_actions)

@dataclass
class _LeafInfo:
    """Information about a leaf node reached during selection."""
    node: MCTSNode
    ci: int                    # child index in parent
    path: list                 # [(node, ci), ...]
    board: np.ndarray          # board state at leaf
    player: int                # player to move at leaf
    last_move: int             # last move that led here
    is_terminal: bool = False  # game over?
    terminal_value: float = 0.0


class _SearchState:
    """Mutable search state for one MCTS tree. Supports split select/expand/backup."""
    
    def __init__(self, root, board, player, root_val, cfg):
        self.root = root
        self.board = board
        self.player = player
        self.root_val = root_val
        self.cfg = cfg
        self._wl = cfg._win_len
        self._bs = cfg.board_size
        self._c_puct = cfg.c_puct
        self._penalty = cfg.penalty_mode
        self._fpu_off = cfg.FPU_OFFSET
        self._fpu_pw = cfg.FPU_PRIOR_WEIGHT

    def select_to_leaf(self):
        """SELECT phase: traverse tree to an unexpanded leaf. Returns _LeafInfo."""
        node = self.root
        cur_board = self.board.copy()
        cur_player = self.player
        path = []
        parent_value = self.root_val
        last_move = -1
        bs = self._bs; wl = self._wl; c_puct = self._c_puct
        ci = -1

        while node.is_expanded and node.n_children > 0:
            cp = c_puct
            if node is self.root and self._penalty == "GatedRefresh":
                cp = c_puct * 0.85
            elif node is self.root and self._penalty == "SelfAdaptive":
                cp = c_puct * 0.80

            n = node.child_n; p = node.child_prior
            unvisited = (n == 0)
            if unvisited.any():
                fpu_scores = parent_value - self._fpu_off + p * self._fpu_pw
                scores = np.where(unvisited,
                                  fpu_scores + np.random.random(node.n_children) * 0.001,
                                  -1e9)
                ci = int(np.argmax(scores))
            else:
                q = node.child_w / np.maximum(n.astype(np.float32), 1)
                sqrt_total = math.sqrt(node.total_n + 1)
                u = cp * p * sqrt_total / (1 + n.astype(np.float32))
                ci = int(np.argmax(q + u))
                parent_value = float(q[ci])

            path.append((node, ci))
            move = int(node.child_moves[ci])
            cur_board[move] = cur_player
            last_move = move

            # Win check
            won = False
            if wl > 0:
                r0, c0 = move // bs, move % bs
                for dr, dc in ((0,1),(1,0),(1,1),(1,-1)):
                    cnt = 1
                    for sign in (1,-1):
                        nr, nc = r0+sign*dr, c0+sign*dc
                        while 0<=nr<bs and 0<=nc<bs and cur_board[nr*bs+nc]==cur_player:
                            cnt += 1; nr += sign*dr; nc += sign*dc
                    if cnt >= wl: won = True; break
                if won:
                    return _LeafInfo(node=node, ci=ci, path=path, board=cur_board,
                                    player=cur_player, last_move=last_move,
                                    is_terminal=True, terminal_value=-1.0)

            cur_player = -cur_player
            if ci in node.child_nodes:
                node = node.child_nodes[ci]
            else:
                break

        return _LeafInfo(node=node, ci=ci, path=path, board=cur_board,
                         player=cur_player, last_move=last_move)

    def expand_and_backup(self, leaf, priors, leaf_val):
        """EXPAND leaf with priors, then BACKUP value through path."""
        bs = self._bs; na = self.cfg.n_actions
        child_legal = [i for i in range(min(na, bs*bs)) if leaf.board[i] == 0]
        if child_legal:
            new_node = MCTSNode()
            new_node.expand(child_legal, priors)
            leaf.node.child_nodes[leaf.ci] = new_node
            value = -leaf_val
        else:
            value = 0.0
        self._do_backup(leaf.path, value)

    def backup(self, leaf, value):
        """BACKUP a terminal value through the path."""
        self._do_backup(leaf.path, value)

    def _do_backup(self, path, value):
        for nd, ci in reversed(path):
            nd.backup_child(ci, value)
            value = -value

    def extract_policy(self, n_actions):
        visits = np.zeros(n_actions, dtype=np.float32)
        for i in range(self.root.n_children):
            if self.root.child_moves[i] < n_actions:
                visits[self.root.child_moves[i]] = self.root.child_n[i]
        total = visits.sum()
        if total > 0: visits /= total
        return visits


# ═══════════════════════════════════════════
# § Rust Server Self-Play
# ═══════════════════════════════════════════

def selfplay_rust(cfg, n_games, rust_binary="./target/release/mcts_demo"):
    """Run self-play via persistent Rust MCTS server (single process, multiple requests)."""
    game_map = {"gomoku7":"gomoku7", "gomoku15":"gomoku15_std", "go9":"go9", "chess":"chess"}
    rust_game = game_map.get(cfg['_name'], "gomoku15_std")

    all_trajectories = []
    remaining = n_games

    try:
        # Start persistent Rust server process
        proc = subprocess.Popen(
            [rust_binary, "--server"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=0)
    except FileNotFoundError:
        print(f"  [WARN] Rust binary not found: {rust_binary}", file=sys.stderr)
        return [], n_games

    with tqdm(total=n_games, desc="Self-play (Rust)", leave=False) as pbar:
        while remaining > 0:
            batch = min(remaining, 5)
            req = json.dumps({"cmd":"selfplay", "game":rust_game,
                              "iters":cfg['iters'], "n_games":batch,
                              "temp_threshold":cfg['temp_th'],
                              "penalty_mode":cfg.get('penalty_mode','GatedRefresh'),
                              "hbar_penalty_cap":cfg.get('hbar_penalty_cap',0.3),
                              "c_puct":cfg.get('c_puct',0.0)})
            try:
                proc.stdin.write(req + "\n")
                proc.stdin.flush()
                line = proc.stdout.readline().strip()
                if line:
                    games = json.loads(line)
                    for g in games:
                        all_trajectories.append(g)
                        pbar.update(1)
                    remaining -= batch
                else:
                    print(f"  [WARN] Rust server returned empty, falling back", file=sys.stderr)
                    break
            except (json.JSONDecodeError, BrokenPipeError, OSError) as e:
                print(f"  [WARN] Rust server error ({e}), falling back", file=sys.stderr)
                break

    # Gracefully terminate server
    try:
        proc.stdin.write('{"cmd":"quit"}\n')
        proc.stdin.flush()
        proc.wait(timeout=5)
    except Exception:
        proc.kill()

    return all_trajectories, remaining


# ═══════════════════════════════════════════
# § NN-Backed Rust Search Client (search_nn protocol)
# ═══════════════════════════════════════════

class NNSearchClient:
    """Drives bidirectional NN eval protocol with Rust MCTS server.
    
    Protocol:
      Python → Rust: {"cmd":"search_nn", "board":[...], "player":1, "iters":200, ...}
      Rust → Python: {"eval_req":{"features":[...],"action_mask":[...],"num_actions":N}}
      Python → Rust: {"eval_resp":{"policy":[...],"value":V}}
      Rust → Python: {"result":{"best_move":42,"policy":[...],...}}
    
    This gives Rust's fast MCTS with Python's NN evaluation.
    """
    def __init__(self, model, cfg, device, rust_binary="./target/release/mcts_demo"):
        self.model = model
        self.cfg = cfg
        self.device = device
        self.proc = None
        self.rust_binary = rust_binary

    def start(self):
        self.proc = subprocess.Popen(
            [self.rust_binary, "--server"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=0)

    def stop(self):
        if self.proc:
            try:
                self.proc.stdin.write('{"cmd":"quit"}\n')
                self.proc.stdin.flush()
                self.proc.wait(timeout=5)
            except Exception: self.proc.kill()
            self.proc = None

    def search_move(self, board_flat, player, penalty_mode="GatedRefresh", fen=None):
        """Send position to Rust, handle eval callbacks, get result.
        
        For chess: pass fen="..." (Rust expects FEN, not flat board).
        For other games: pass board_flat=[...] (flat int array).
        """
        if not self.proc: self.start()
        game_map = {"gomoku7":"gomoku7","gomoku15":"gomoku15_std","go9":"go9","chess":"chess"}
        game_name = game_map.get(self.cfg['_name'], "gomoku15_std")

        req_dict = {
            "cmd": "search_nn",
            "game": game_name,
            "player": int(player),
            "iters": self.cfg['iters'],
            "penalty_mode": penalty_mode,
        }
        # Chess uses FEN; other games use flat board array
        if game_name == "chess" and fen:
            req_dict["fen"] = fen
        else:
            req_dict["board"] = board_flat.tolist() if hasattr(board_flat, 'tolist') else list(board_flat)

        req = json.dumps(req_dict, separators=(',',':'))
        self.proc.stdin.write(req + "\n")
        self.proc.stdin.flush()

        # Handle bidirectional eval exchanges with select() for reliability
        while True:
            ready, _, _ = select.select([self.proc.stdout], [], [], 10.0)
            if not ready: break
            line = self.proc.stdout.readline().strip()
            if not line: break

            if '"eval_req"' in line:
                resp = self._eval_nn(line)
                self.proc.stdin.write(json.dumps(resp, separators=(',',':')) + "\n")
                self.proc.stdin.flush()
            elif '"result"' in line:
                return json.loads(line).get("result", {})
            else:
                try: return json.loads(line)
                except (json.JSONDecodeError, ValueError): break
        return {}

    def _eval_nn(self, req_line):
        """Process eval request from Rust, return NN policy+value."""
        try:
            req = json.loads(req_line)["eval_req"]
            features = req.get("features", [])
            n_act = req.get("num_actions", self.cfg['actions'])
            ch, bs = self.cfg['ch'], self.cfg['board']
            expected = ch * bs * bs

            if len(features) == expected and self.model is not None:
                x = torch.tensor(features, dtype=torch.float32).reshape(1,ch,bs,bs).to(self.device)
                with torch.no_grad():
                    logits, val = self.model(x)
                    probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
                return {"eval_resp": {"policy": probs.tolist(), "value": float(val.item())}}
        except Exception as e:
            import sys; print(f'[WARN] NN eval failed: {e}', file=sys.stderr)
        # Fallback uniform
        return {"eval_resp": {"policy": [1.0/max(1,self.cfg['actions'])]*self.cfg['actions'], "value": 0.0}}


# ═══════════════════════════════════════════
# § Actor/Learner Separation: Background Self-Play Worker
# ═══════════════════════════════════════════

# ═══════════════════════════════════════════
# § Rust NN-Backed Self-Play
# ═══════════════════════════════════════════

def selfplay_rust_nn(cfg, model, device, n_games, rust_binary="./target/release/mcts_demo"):
    """Self-play using Rust MCTS engine with Python NN evaluation.
    
    This is the GOLD STANDARD self-play path:
    - Rust does tree search (PUCT + QUARTZ controller + TT + virtual loss)
    - Python provides NN policy+value via bidirectional search_nn protocol
    - Full Rust search semantics, not the simplified Python TreeMCTS
    
    Flow per move:
      Python → Rust: {"cmd":"search_nn", "board":[...], "player":1, ...}
      Rust ↔ Python: multiple eval_req/eval_resp exchanges during MCTS
      Rust → Python: {"result":{"best_move":42, "policy":[...], ...}}
    """
    board_size = cfg['board']
    n2 = board_size ** 2
    n_actions = cfg['actions']
    win_len = cfg['win']
    penalty_mode = cfg.get('penalty_mode', 'GatedRefresh')
    iters = cfg['iters']
    is_chess = cfg.get('_name') == 'chess'

    client = NNSearchClient(model, cfg, device, rust_binary)
    try:
        client.start()
    except FileNotFoundError:
        print(f"  [WARN] Rust binary not found: {rust_binary}", file=sys.stderr)
        return [], [], [], n_games

    all_states, all_policies, all_outcomes = [], [], []

    def _fen_to_board(fen):
        """Parse FEN piece placement → flat 64-element array for encoding."""
        board = np.zeros(64, dtype=np.int8)
        piece_map = {'P':1,'N':2,'B':3,'R':4,'Q':5,'K':6,
                     'p':-1,'n':-2,'b':-3,'r':-4,'q':-5,'k':-6}
        parts = fen.split()
        rank = 7; file = 0
        for ch in parts[0]:
            if ch == '/': rank -= 1; file = 0
            elif ch.isdigit(): file += int(ch)
            elif ch in piece_map:
                board[rank*8+file] = piece_map[ch]; file += 1
        return board

    with tqdm(total=n_games, desc="Self-play (Rust+NN)", leave=False) as pbar:
        for game_idx in range(n_games):
            game_states, game_policies = [], []
            move_count = 0
            won = False
            max_moves = 500 if is_chess else n2

            if is_chess:
                current_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
                player = 1
                chess_outcome = 0.0  # updated on terminal detection
            else:
                board = np.zeros(n2, dtype=np.int8)
                player = 1

            while move_count < max_moves:
                # Encode state for training data
                if is_chess:
                    chess_board = _fen_to_board(current_fen)
                    enc = encode_board(cfg, chess_board, player)
                else:
                    enc = encode_board(cfg, np.array(board, dtype=np.int8), player)

                # Call Rust MCTS with NN evaluation
                if is_chess:
                    result = client.search_move(None, player, penalty_mode, fen=current_fen)
                else:
                    result = client.search_move(board, player, penalty_mode)
                if not result or 'error' in result:
                    break

                # Extract policy
                policy = np.zeros(n_actions, dtype=np.float32)
                pol_entries = result.get('policy', [])
                if not pol_entries:
                    # Terminal: no legal moves. For chess: checkmate or stalemate.
                    # Rust value from this position = -1 if checkmate (side to move lost),
                    # 0 if stalemate. Use it as outcome FROM FIRST PLAYER'S PERSPECTIVE.
                    if is_chess:
                        terminal_value = result.get('value', 0.0)
                        # terminal_value is from current player's perspective
                        # Convert to first player (white=1) perspective
                        chess_outcome = terminal_value * player  # player=1(white)/-1(black)
                    break
                for entry in pol_entries:
                    if isinstance(entry, str) and ':' in entry:
                        idx, val = entry.split(':')
                        idx = int(idx)
                        if idx < n_actions: policy[idx] = float(val)

                game_states.append(enc.copy())
                game_policies.append(policy.copy())

                if is_chess:
                    # Chess: Rust returns result_fen after applying best_move
                    new_fen = result.get('result_fen', '')
                    if not new_fen or new_fen == current_fen:
                        break  # game over
                    current_fen = new_fen
                    move_count += 1
                    player = -player
                    # Check for terminal (simple: halfmove clock >= 100)
                    parts = current_fen.split()
                    if len(parts) >= 5 and int(parts[4]) >= 100:
                        break
                else:
                    # Board games: select move + apply + check win
                    legal = [i for i in range(n2) if board[i] == 0]
                    if not legal: break

                    if move_count < cfg['temp_th']:
                        lp = np.array([policy[a] for a in legal])
                        if lp.sum() > 1e-8:
                            lp /= lp.sum()
                            chosen = np.random.choice(legal, p=lp)
                        else:
                            chosen = random.choice(legal)
                    else:
                        chosen = max(legal, key=lambda a: policy[a] if a < n_actions else 0)

                    board[chosen] = player
                    move_count += 1

                    if win_len > 0:
                        r0, c0 = chosen // board_size, chosen % board_size
                        for dr, dc in [(0,1),(1,0),(1,1),(1,-1)]:
                            cnt = 1
                            for sign in [1,-1]:
                                nr, nc = r0+sign*dr, c0+sign*dc
                                while 0<=nr<board_size and 0<=nc<board_size and board[nr*board_size+nc]==player:
                                    cnt += 1; nr += sign*dr; nc += sign*dc
                            if cnt >= win_len: won = True; break
                        if won: break

                    if not [i for i in range(n2) if board[i] == 0]:
                        break
                    player = -player

            # Record game
            if is_chess:
                outcome = chess_outcome
            else:
                winner = player if won else 0
                outcome = float(winner)
            all_states.append(game_states)
            all_policies.append(game_policies)
            all_outcomes.append(outcome)
            pbar.update(1)
            pbar.set_postfix_str(f"moves={move_count}")

    client.stop()
    return all_states, all_policies, all_outcomes, 0


class SelfPlayWorker:
    """Background actor: Rust MCTS + batched NN eval (Tier 2).
    
    Uses frozen model snapshot for NN evaluation via search_nn IPC.
    Produces full Tier 2 training data (TT+VL+PW+QUARTZ search quality).
    
    Backpressure: pauses when replay buffer is >80% full.
    """
    BACKPRESSURE_RATIO = 0.8
    BACKPRESSURE_SLEEP = 0.5

    def __init__(self, cfg, model, device, replay, rust_binary):
        self.cfg = cfg; self.device = device
        self.replay = replay; self.rust_binary = rust_binary
        self._stop = threading.Event()
        self._thread = None
        self.games_generated = 0
        self.positions_generated = 0
        self._prev_count = 0
        self._cycles = 0
        self._total_time = 0.0
        self._backpressure_waits = 0
        import copy
        self._model = copy.deepcopy(model) if model is not None else None
        if self._model is not None:
            self._model.eval()

    def update_model(self, model):
        """Refresh frozen model snapshot from training model."""
        import copy
        self._model = copy.deepcopy(model)
        if self._model is not None:
            self._model.eval()

    def start(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread: self._thread.join(timeout=10)

    def telemetry(self):
        return {
            "games": self.games_generated,
            "positions": self.positions_generated,
            "cycles": self._cycles,
            "avg_cycle_s": round(self._total_time / max(self._cycles, 1), 3),
            "backpressure_waits": self._backpressure_waits,
            "path": "rust+nn",
        }

    def _run(self):
        while not self._stop.is_set():
            try:
                if hasattr(self.replay.buf, 'maxlen') and self.replay.buf.maxlen:
                    fill = len(self.replay) / self.replay.buf.maxlen
                    if fill > self.BACKPRESSURE_RATIO:
                        self._backpressure_waits += 1
                        time.sleep(self.BACKPRESSURE_SLEEP)
                        continue

                t0 = time.time()
                batch_games = max(1, min(self.cfg['games'] // 5, 10))
                states, policies, outcomes, _ = selfplay_rust_nn_batched(
                    self.cfg, self._model, self.device, batch_games,
                    self.rust_binary, parallel=2)
                n_new = 0
                for gs, gp, out in zip(states, policies, outcomes):
                    self.replay.add_game(gs, gp, out)
                    n_new += len(gs)
                self.games_generated += batch_games
                self.positions_generated += n_new
                self._cycles += 1
                self._total_time += time.time() - t0
            except Exception as e:
                logger = logging.getLogger(__name__)
                logger.warning(f"SelfPlayWorker error: {e}")
                time.sleep(1)


# ═══════════════════════════════════════════
# § Replay Metrics: Diversity + Freshness
# ═══════════════════════════════════════════

class ReplayMetrics:
    """Track replay buffer health metrics (Doc 22 P2).
    
    - freshness: fraction of buffer replaced this iteration
    - policy_entropy: average entropy of policy targets (diversity proxy)
    """
    @staticmethod
    def freshness(n_new, replay_size):
        return n_new / max(replay_size, 1)

    @staticmethod
    def policy_entropy(replay, sample_n=100):
        """Average entropy of policy targets in a sample."""
        if len(replay) < sample_n: return 0.0
        indices = random.sample(range(len(replay)), sample_n)
        total_ent = 0.0
        for i in indices:
            _, pol, _ = replay.buf[i]
            p = np.array(pol, dtype=np.float32)
            p = p[p > 1e-8]
            if len(p) > 0:
                total_ent += -np.sum(p * np.log(p))
        return total_ent / sample_n

    @staticmethod
    def value_std(replay, sample_n=100):
        """Std of value targets (diversity proxy)."""
        if len(replay) < sample_n: return 0.0
        indices = random.sample(range(len(replay)), sample_n)
        vals = [replay.buf[i][2] for i in indices]
        return float(np.std(vals))


def train_epoch(model, optimizer, replay, cfg, device, n_steps, backend=None):
    """Train for n_steps. Uses backend.train_step if available (JAX JIT)."""
    total_loss, total_pl, total_vl = 0.0, 0.0, 0.0

    with tqdm(range(n_steps), desc="  Training", leave=False) as pbar:
        for step in pbar:
            states_t, policies_t, values_t = replay.sample(cfg['batch'])

            if backend is not None:
                # Backend path (JAX JIT or PyTorch via unified API)
                loss, pl, vl = backend.train_step(
                    states_t.numpy(), policies_t.numpy(), values_t.numpy())
            else:
                # Legacy PyTorch direct path
                model.train()
                states_t = states_t.to(device)
                policies_t = policies_t.to(device)
                values_t = values_t.to(device)
                logits, pred_v = model(states_t)
                log_probs = F.log_softmax(logits, dim=-1)
                pl = -(policies_t * log_probs).sum(dim=-1).mean()
                vl = F.mse_loss(pred_v, values_t)
                loss_t = pl + vl
                optimizer.zero_grad()
                loss_t.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                loss, pl, vl = loss_t.item(), pl.item(), vl.item()

            total_loss += loss; total_pl += pl; total_vl += vl
            pbar.set_postfix(loss=f"{loss:.3f}", p=f"{pl:.3f}", v=f"{vl:.3f}")

    n = max(n_steps, 1)
    return total_loss/n, total_pl/n, total_vl/n

# ═══════════════════════════════════════════
# § Early Stopping
# ═══════════════════════════════════════════

class EarlyStopping:
    """Stop training when loss stops improving."""
    def __init__(self, patience=10, min_delta=0.001):
        self.patience = patience
        self.min_delta = min_delta
        self.best_loss = float('inf')
        self.counter = 0
        self.should_stop = False

    def step(self, loss):
        if loss < self.best_loss - self.min_delta:
            self.best_loss = loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True
        return self.should_stop

# ═══════════════════════════════════════════
# § Eval Server (for Rust MCTS PythonIpcEval)
# ═══════════════════════════════════════════

def serve(model, cfg, device):
    model.eval()
    print(f"alphazero_server ready ({cfg['_name']})", file=sys.stderr, flush=True)
    for line in sys.stdin:
        line = line.strip()
        if not line: continue
        try:
            req = json.loads(line)
            if req.get("cmd") == "quit": break
            features = req.get("features", [])
            action_mask = req.get("action_mask", [])
            n_act = req.get("num_actions", cfg['actions'])
            expected = cfg['ch'] * cfg['board'] * cfg['board']
            if len(features) == expected:
                x = torch.tensor(features, dtype=torch.float32).reshape(1, cfg['ch'], cfg['board'], cfg['board']).to(device)
            else:
                x = torch.zeros(1, cfg['ch'], cfg['board'], cfg['board'], device=device)
            with torch.no_grad():
                logits, val = model(x)
                probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
            masked = np.zeros(n_act, dtype=np.float32)
            for i in range(min(len(action_mask), n_act)):
                if action_mask[i]: masked[i] = probs[i] if i < len(probs) else 0.0
            s = masked.sum()
            if s > 1e-8: masked /= s
            print(json.dumps({"status":"ok", "policy":masked.tolist(), "value":float(val.item())}), flush=True)
        except Exception as e:
            print(json.dumps({"status":"error", "policy":[], "value":0.0}), flush=True)

# ═══════════════════════════════════════════
# § Main
# ═══════════════════════════════════════════

# ═══════════════════════════════════════════
# § Arena: Head-to-Head Model Comparison
# ═══════════════════════════════════════════

def arena_compare(model_a_path, model_b_path, cfg, device, n_games=50):
    """Play N games with SPRT early termination.
    
    SPRT: Sequential Probability Ratio Test
    H0: win_rate = 0.5 (equal strength)
    H1: win_rate = 0.55 (A is significantly stronger)
    α=β=0.05 → boundaries: lower=-2.944, upper=2.944
    """
    model_a = AlphaZeroNet(cfg).to(device)
    model_b = AlphaZeroNet(cfg).to(device)
    model_a.load_state_dict(torch.load(model_a_path, map_location=device, weights_only=True))
    model_b.load_state_dict(torch.load(model_b_path, map_location=device, weights_only=True))
    model_a.eval(); model_b.eval()

    wins_a, wins_b, draws = 0, 0, 0
    mcts_a = TreeMCTS(cfg, model_a, device)
    mcts_b = TreeMCTS(cfg, model_b, device)

    # SPRT parameters
    p0, p1 = 0.5, 0.55
    alpha, beta = 0.05, 0.05
    lower_bound = math.log(beta / (1 - alpha))      # ≈ -2.944
    upper_bound = math.log((1 - beta) / alpha)       # ≈ 2.944
    sprt_decided = False
    sprt_result = None

    with tqdm(total=n_games, desc="Arena", leave=False) as pbar:
        for game_idx in range(n_games):
            # Alternate colors
            if game_idx % 2 == 0:
                first, second = mcts_a, mcts_b
                first_is_a = True
            else:
                first, second = mcts_b, mcts_a
                first_is_a = False

            board = np.zeros(cfg['board']**2, dtype=np.int8)
            player = 1
            n2 = cfg['board']**2
            winner = 0

            for move_n in range(n2):
                legal_mask = np.array([1.0 if board[i]==0 else 0.0
                                       for i in range(min(n2, cfg['actions']))])
                if cfg['actions'] > n2:
                    legal_mask = np.concatenate([legal_mask, np.zeros(cfg['actions']-n2)])
                legal = [i for i in range(n2) if board[i]==0]
                if not legal: break

                encoded = np.zeros((cfg['ch'], cfg['board'], cfg['board']), dtype=np.float32)
                for i in range(n2):
                    r, c = i // cfg['board'], i % cfg['board']
                    if board[i] == player: encoded[0,r,c] = 1.0
                    elif board[i] != 0:   encoded[1,r,c] = 1.0
                if cfg['ch'] >= 3 and player == 1: encoded[2] = 1.0

                mcts = first if player == 1 else second
                policy = mcts.search(encoded, player, legal_mask, cfg['iters'] // 4)
                chosen = max(legal, key=lambda i: policy[i] if i < len(policy) else 0)
                board[chosen] = player

                # Check win
                if cfg['win'] > 0:
                    r0, c0 = chosen // cfg['board'], chosen % cfg['board']
                    for dr, dc in [(0,1),(1,0),(1,1),(1,-1)]:
                        cnt = 1
                        for sign in [1,-1]:
                            nr, nc = r0+sign*dr, c0+sign*dc
                            while 0<=nr<cfg['board'] and 0<=nc<cfg['board'] and board[nr*cfg['board']+nc]==player:
                                cnt += 1; nr += sign*dr; nc += sign*dc
                        if cnt >= cfg['win']:
                            winner = player; break
                    if winner: break
                player = -player

            if winner == 1:
                if first_is_a: wins_a += 1
                else: wins_b += 1
            elif winner == -1:
                if first_is_a: wins_b += 1
                else: wins_a += 1
            else:
                draws += 1
            pbar.update(1)
            pbar.set_postfix_str(f"A:{wins_a} B:{wins_b} D:{draws}")

            # SPRT check after each decisive game
            decisive = wins_a + wins_b
            if decisive > 0 and not sprt_decided:
                w = wins_a
                n_dec = decisive
                # Log-likelihood ratio
                llr = w * math.log(p1/p0) + (n_dec - w) * math.log((1-p1)/(1-p0))
                if llr >= upper_bound:
                    sprt_decided = True
                    sprt_result = "H1_accept"  # A is stronger
                    pbar.set_postfix_str(f"SPRT: A wins (LLR={llr:.2f})")
                    break
                elif llr <= lower_bound:
                    sprt_decided = True
                    sprt_result = "H0_accept"  # no significant difference
                    pbar.set_postfix_str(f"SPRT: equal (LLR={llr:.2f})")
                    break

    total = wins_a + wins_b + draws
    wr = wins_a / max(total, 1)
    # Wilson score CI
    z = 1.96
    n = max(total, 1)
    p_hat = wr
    ci_lo = (p_hat + z*z/(2*n) - z*math.sqrt((p_hat*(1-p_hat)+z*z/(4*n))/n)) / (1+z*z/n)
    ci_hi = (p_hat + z*z/(2*n) + z*math.sqrt((p_hat*(1-p_hat)+z*z/(4*n))/n)) / (1+z*z/n)
    sprt_str = sprt_result or "inconclusive"
    return wins_a, wins_b, draws, wr, (ci_lo, ci_hi), sprt_str


# ═══════════════════════════════════════════
# § Rust NN-Backed Arena
# ═══════════════════════════════════════════

def arena_rust_nn(model_a_path, model_b_path, cfg, device, n_games=50,
                  rust_binary="./target/release/mcts_demo", strict=True):
    """Head-to-head using Rust MCTS with NN evaluation.
    
    Unlike arena_compare (Python TreeMCTS), this uses the full Rust search stack:
    TT, virtual loss, progressive widening, full QUARTZ controller.
    
    Args:
        strict: If True (default), raise error when Rust binary missing.
                If False, fall back to Python arena (NOT benchmark-grade).
    
    Each model gets its own NNSearchClient → separate Rust server process.
    """
    is_chess = cfg.get('_name') == 'chess'

    model_a = AlphaZeroNet(cfg).to(device)
    model_b = AlphaZeroNet(cfg).to(device)
    model_a.load_state_dict(torch.load(model_a_path, map_location=device, weights_only=True))
    model_b.load_state_dict(torch.load(model_b_path, map_location=device, weights_only=True))
    model_a.eval(); model_b.eval()

    client_a = NNSearchClient(model_a, cfg, device, rust_binary)
    client_b = NNSearchClient(model_b, cfg, device, rust_binary)
    try:
        client_a.start(); client_b.start()
    except FileNotFoundError:
        if strict:
            raise RuntimeError(
                f"Arena (strict mode): Rust binary not found at {rust_binary}. "
                f"Run: cargo build --release. "
                f"Use strict=False for Python TreeMCTS fallback (NOT benchmark-grade).")
        print(f"  [WARN] Rust binary not found, falling back to Python arena (NOT benchmark-grade)")
        return arena_compare(model_a_path, model_b_path, cfg, device, n_games)

    board_size = cfg['board']
    n2 = board_size ** 2
    n_actions = cfg['actions']
    win_len = cfg['win']
    penalty_mode = cfg.get('penalty_mode', 'GatedRefresh')

    wins_a, wins_b, draws = 0, 0, 0

    # SPRT parameters
    p0, p1 = 0.5, 0.55
    alpha, beta = 0.05, 0.05
    lower_bound = math.log(beta / (1 - alpha))
    upper_bound = math.log((1 - beta) / alpha)
    sprt_decided = False
    sprt_result = None

    with tqdm(total=n_games, desc="Arena (Rust+NN)", leave=False) as pbar:
        for game_idx in range(n_games):
            if game_idx % 2 == 0:
                first_client, second_client = client_a, client_b
                first_is_a = True
            else:
                first_client, second_client = client_b, client_a
                first_is_a = False

            board = np.zeros(n2, dtype=np.int8) if not is_chess else None
            player = 1
            winner = 0
            current_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" if is_chess else None
            max_moves = 500 if is_chess else n2

            for move_n in range(max_moves):
                client = first_client if player == 1 else second_client

                if is_chess:
                    result = client.search_move(None, player, penalty_mode, fen=current_fen)
                else:
                    result = client.search_move(board, player, penalty_mode)
                if not result or 'error' in result:
                    break

                pol_entries = result.get('policy', [])
                if not pol_entries:
                    break  # terminal

                if is_chess:
                    new_fen = result.get('result_fen', '')
                    if not new_fen or new_fen == current_fen:
                        break
                    current_fen = new_fen
                    player = -player
                    # Detect draw by 50-move rule
                    parts = current_fen.split()
                    if len(parts) >= 5 and int(parts[4]) >= 100:
                        break
                else:
                    best = result.get('best_move', -1)
                    legal = [i for i in range(n2) if board[i] == 0]
                    if best < 0 or best >= n2 or board[best] != 0:
                        if legal: best = random.choice(legal)
                        else: break

                    board[best] = player

                    if win_len > 0:
                        r0, c0 = best // board_size, best % board_size
                        for dr, dc in [(0,1),(1,0),(1,1),(1,-1)]:
                            cnt = 1
                            for sign in [1,-1]:
                                nr, nc = r0+sign*dr, c0+sign*dc
                                while 0<=nr<board_size and 0<=nc<board_size and board[nr*board_size+nc]==player:
                                    cnt += 1; nr += sign*dr; nc += sign*dc
                            if cnt >= win_len: winner = player; break
                        if winner: break

                    if not [i for i in range(n2) if board[i] == 0]:
                        break
                    player = -player

            if winner == 1:
                if first_is_a: wins_a += 1
                else: wins_b += 1
            elif winner == -1:
                if first_is_a: wins_b += 1
                else: wins_a += 1
            else:
                draws += 1

            pbar.update(1)
            pbar.set_postfix_str(f"A:{wins_a} B:{wins_b} D:{draws}")

            # SPRT
            decisive = wins_a + wins_b
            if decisive > 0 and not sprt_decided:
                llr = wins_a * math.log(p1/p0) + (decisive - wins_a) * math.log((1-p1)/(1-p0))
                if llr >= upper_bound:
                    sprt_decided = True; sprt_result = "H1_accept"; break
                elif llr <= lower_bound:
                    sprt_decided = True; sprt_result = "H0_accept"; break

    client_a.stop(); client_b.stop()

    total = wins_a + wins_b + draws
    wr = wins_a / max(total, 1)
    z = 1.96; n = max(total, 1); p_hat = wr
    ci_lo = (p_hat + z*z/(2*n) - z*math.sqrt((p_hat*(1-p_hat)+z*z/(4*n))/n)) / (1+z*z/n)
    ci_hi = (p_hat + z*z/(2*n) + z*math.sqrt((p_hat*(1-p_hat)+z*z/(4*n))/n)) / (1+z*z/n)
    sprt_str = sprt_result or "inconclusive"
    return wins_a, wins_b, draws, wr, (ci_lo, ci_hi), sprt_str


# ═══════════════════════════════════════════
# § Glicko-2 Rating System + 3-Agent Arena
# ═══════════════════════════════════════════

class Glicko2Rating:
    """Glicko-2 rating for a single player."""
    def __init__(self, mu=1500.0, phi=350.0, sigma=0.06):
        self.mu = mu        # rating
        self.phi = phi      # rating deviation (uncertainty)
        self.sigma = sigma  # volatility

    def to_dict(self):
        return {"mu": self.mu, "phi": self.phi, "sigma": self.sigma}

    @staticmethod
    def from_dict(d):
        return Glicko2Rating(d["mu"], d["phi"], d["sigma"])


class Glicko2System:
    """Glicko-2 rating system with deflation protection.
    
    Deflation protection: anchor agent (random rollout) is pinned at 1000.
    After each rating period, all ratings are shifted so anchor stays at 1000.
    This prevents rating deflation as models improve.
    """
    TAU = 0.5  # system volatility constant

    def __init__(self, path=None):
        self.ratings = {}  # name → Glicko2Rating
        self.path = path
        if path and os.path.exists(path):
            self.load(path)

    def ensure(self, name, mu=1500.0, phi=350.0):
        if name not in self.ratings:
            self.ratings[name] = Glicko2Rating(mu, phi)
        return self.ratings[name]

    def _g(self, phi):
        return 1.0 / math.sqrt(1.0 + 3.0 * phi**2 / (math.pi**2))

    def _E(self, mu, muj, phij):
        return 1.0 / (1.0 + math.exp(-self._g(phij) * (mu - muj)))

    def update(self, name, opponents_results):
        """Update rating after a rating period.
        
        opponents_results: list of (opponent_name, score) where score in {0, 0.5, 1}
        """
        r = self.ensure(name)
        if not opponents_results:
            # No games: increase uncertainty
            r.phi = min(350.0, math.sqrt(r.phi**2 + r.sigma**2))
            return

        # Convert to Glicko-2 scale
        mu = (r.mu - 1500.0) / 173.7178
        phi = r.phi / 173.7178

        # Compute v (estimated variance)
        v_inv = 0.0
        delta_sum = 0.0
        for opp_name, score in opponents_results:
            opp = self.ensure(opp_name)
            muj = (opp.mu - 1500.0) / 173.7178
            phij = opp.phi / 173.7178
            g_val = self._g(phij)
            E_val = self._E(mu, muj, phij)
            v_inv += g_val**2 * E_val * (1 - E_val)
            delta_sum += g_val * (score - E_val)

        if v_inv < 1e-12:
            return
        v = 1.0 / v_inv
        delta = v * delta_sum

        # Update volatility (simplified Illinois algorithm)
        a = math.log(r.sigma**2)
        tau2 = self.TAU**2
        phi2 = phi**2

        def f(x):
            ex = math.exp(x)
            d2 = delta**2
            num1 = ex * (d2 - phi2 - v - ex)
            den1 = 2.0 * (phi2 + v + ex)**2
            return num1 / den1 - (x - a) / tau2

        # Bisection
        A = a
        if delta**2 > phi2 + v:
            B = math.log(delta**2 - phi2 - v)
        else:
            k = 1
            while f(a - k * self.TAU) < 0:
                k += 1
                if k > 100: break
            B = a - k * self.TAU

        for _ in range(50):
            C = (A + B) / 2.0
            if abs(B - A) < 1e-6:
                break
            if f(C) * f(A) < 0:
                B = C
            else:
                A = C

        sigma_new = math.exp(C / 2.0)
        phi_star = math.sqrt(phi2 + sigma_new**2)
        phi_new = 1.0 / math.sqrt(1.0 / phi_star**2 + 1.0 / v)
        mu_new = mu + phi_new**2 * delta_sum

        r.mu = mu_new * 173.7178 + 1500.0
        r.phi = phi_new * 173.7178
        r.sigma = sigma_new

    def deflation_adjust(self, anchor_name="random_rollout", anchor_target=1000.0):
        """Pin anchor agent at target rating → prevents deflation."""
        if anchor_name not in self.ratings:
            return
        drift = self.ratings[anchor_name].mu - anchor_target
        if abs(drift) > 1.0:
            for r in self.ratings.values():
                r.mu -= drift

    def leaderboard(self):
        return sorted(self.ratings.items(), key=lambda x: -x[1].mu)

    def save(self, path=None):
        p = path or self.path
        if p:
            with open(p, 'w') as f:
                json.dump({k: v.to_dict() for k, v in self.ratings.items()}, f, indent=2)

    def load(self, path=None):
        p = path or self.path
        if p and os.path.exists(p):
            with open(p) as f:
                data = json.load(f)
            self.ratings = {k: Glicko2Rating.from_dict(v) for k, v in data.items()}


class RandomRolloutAgent:
    """Anchor agent: plays random legal moves. Fixed strength baseline."""
    def choose_move(self, board, player, board_size):
        n2 = board_size ** 2
        legal = [i for i in range(n2) if board[i] == 0]
        return random.choice(legal) if legal else -1


def arena_3agent(model_current_path, model_best_path, cfg, device,
                 games_per_pair=20, rust_binary="./target/release/mcts_demo",
                 use_rust_nn=False, rating_path=None):
    """3-agent round-robin arena with Glicko-2 ratings.
    
    Agents:
      1. random_rollout — anchor (pinned at 1000 Glicko)
      2. current — model being trained
      3. best — highest-rated checkpoint so far
    
    Each pair plays games_per_pair games (alternating colors).
    After all games, Glicko-2 ratings are updated with deflation correction.
    
    Returns: (ratings_dict, current_promoted: bool)
    """
    glicko = Glicko2System(rating_path)
    glicko.ensure("random_rollout", mu=1000.0, phi=100.0)
    glicko.ensure("current", mu=1500.0, phi=200.0)
    glicko.ensure("best", mu=1500.0, phi=200.0)

    board_size = cfg['board']
    n2 = board_size ** 2
    win_len = cfg['win']
    rand_agent = RandomRolloutAgent()

    def play_game(agent_a_fn, agent_b_fn, swap=False):
        """Play one game. Returns (score_a, score_b)."""
        board = np.zeros(n2, dtype=np.int8)
        player = 1
        for move_n in range(n2):
            fn = agent_a_fn if (player == 1) != swap else agent_b_fn
            move = fn(board, player)
            if move < 0 or move >= n2 or board[move] != 0:
                return (0.0, 1.0) if ((player == 1) != swap) else (1.0, 0.0)
            board[move] = player
            if win_len > 0:
                r0, c0 = move // board_size, move % board_size
                for dr, dc in [(0,1),(1,0),(1,1),(1,-1)]:
                    cnt = 1
                    for sign in [1,-1]:
                        nr, nc = r0+sign*dr, c0+sign*dc
                        while 0<=nr<board_size and 0<=nc<board_size and board[nr*board_size+nc]==player:
                            cnt += 1; nr += sign*dr; nc += sign*dc
                    if cnt >= win_len:
                        if (player == 1) != swap: return (1.0, 0.0)
                        else: return (0.0, 1.0)
            if not [i for i in range(n2) if board[i] == 0]:
                return (0.5, 0.5)
            player = -player
        return (0.5, 0.5)

    # Load models
    model_curr = AlphaZeroNet(cfg).to(device)
    model_curr.load_state_dict(torch.load(model_current_path, map_location=device, weights_only=True))
    model_curr.eval()

    if model_best_path and os.path.exists(model_best_path):
        model_best = AlphaZeroNet(cfg).to(device)
        model_best.load_state_dict(torch.load(model_best_path, map_location=device, weights_only=True))
        model_best.eval()
    else:
        model_best = model_curr

    # Create search functions
    mcts_curr = TreeMCTS(cfg, model_curr, device)
    mcts_best = TreeMCTS(cfg, model_best, device)
    iters = cfg['iters'] // 4

    def nn_move(mcts, board, player):
        enc = encode_board(cfg, np.array(board, dtype=np.int8) if not isinstance(board, np.ndarray) else board, player)
        legal_mask = np.array([1.0 if board[i]==0 else 0.0 for i in range(min(n2, cfg['actions']))])
        if cfg['actions'] > n2: legal_mask = np.concatenate([legal_mask, np.zeros(cfg['actions']-n2)])
        pol = mcts.search(enc, player, legal_mask, iters)
        legal = [i for i in range(n2) if board[i] == 0]
        if not legal: return -1
        return max(legal, key=lambda a: pol[a] if a < len(pol) else 0)

    curr_fn = lambda b, p: nn_move(mcts_curr, b, p)
    best_fn = lambda b, p: nn_move(mcts_best, b, p)
    rand_fn = lambda b, p: rand_agent.choose_move(b, p, board_size)

    # Round-robin: 3 pairs
    pairs = [
        ("current", "random_rollout", curr_fn, rand_fn),
        ("best", "random_rollout", best_fn, rand_fn),
        ("current", "best", curr_fn, best_fn),
    ]

    results = {name: [] for name in ["current", "best", "random_rollout"]}

    print("  3-Agent Round-Robin Arena:")
    for name_a, name_b, fn_a, fn_b in pairs:
        wa, wb, d = 0, 0, 0
        for gi in range(games_per_pair):
            swap = gi % 2 == 1
            sa, sb = play_game(fn_a, fn_b, swap)
            if sa > sb: wa += 1
            elif sb > sa: wb += 1
            else: d += 1
            results[name_a].append((name_b, sa))
            results[name_b].append((name_a, sb))
        print(f"    {name_a} vs {name_b}: {wa}-{wb}-{d}")

    # Glicko-2 update
    for name, opp_results in results.items():
        glicko.update(name, opp_results)

    # Deflation correction: pin random_rollout at 1000
    glicko.deflation_adjust("random_rollout", 1000.0)
    glicko.save()

    print("  Ratings (Glicko-2, deflation-adjusted):")
    for name, r in glicko.leaderboard():
        print(f"    {name:20s}  {r.mu:7.1f} ± {r.phi:.1f}")

    # Promotion: current > best?
    curr_r = glicko.ratings.get("current", Glicko2Rating())
    best_r = glicko.ratings.get("best", Glicko2Rating())
    promoted = curr_r.mu > best_r.mu + 30  # require 30-point margin
    if promoted:
        print(f"  → PROMOTED: current ({curr_r.mu:.0f}) > best ({best_r.mu:.0f})")
    else:
        print(f"  → NOT promoted: current ({curr_r.mu:.0f}) vs best ({best_r.mu:.0f})")

    return {k: v.to_dict() for k, v in glicko.ratings.items()}, promoted


# ═══════════════════════════════════════════
# § Batched Rust NN Self-Play (N-game parallel)
# ═══════════════════════════════════════════

def selfplay_rust_nn_batched(cfg, model, device, n_games, rust_binary="./target/release/mcts_demo",
                              parallel=4):
    """Run N games in parallel via Rust MCTS + batched NN eval.

    Launches `parallel` Rust server processes. Collects eval_reqs
    from all servers, batches into 1 GPU forward pass, distributes
    responses back. Supports all games including chess (FEN tracking).
    """
    board_size = cfg['board']
    n2 = board_size ** 2
    n_actions = cfg['actions']
    win_len = cfg['win']
    penalty_mode = cfg.get('penalty_mode', 'GatedRefresh')
    iters = cfg['iters']
    is_chess = cfg.get('_name') == 'chess'
    game_map = {"gomoku7":"gomoku7","gomoku15":"gomoku15_std","go9":"go9","chess":"chess"}
    rust_game = game_map.get(cfg['_name'], "gomoku15_std")

    def _fen_to_board(fen):
        board = np.zeros(64, dtype=np.int8)
        piece_map = {'P':1,'N':2,'B':3,'R':4,'Q':5,'K':6,
                     'p':-1,'n':-2,'b':-3,'r':-4,'q':-5,'k':-6}
        rank = 7; file = 0
        for ch in fen.split()[0]:
            if ch == '/': rank -= 1; file = 0
            elif ch.isdigit(): file += int(ch)
            elif ch in piece_map: board[rank*8+file] = piece_map[ch]; file += 1
        return board

    all_states, all_policies, all_outcomes, all_traces = [], [], [], []
    games_done = 0
    max_moves = 500 if is_chess else n2 + 5
    start_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    with tqdm(total=n_games, desc="Self-play (Rust+NN batched)", leave=False) as pbar:
        while games_done < n_games:
            batch_n = min(parallel, n_games - games_done)

            procs = []
            game_data = []
            for _ in range(batch_n):
                p = subprocess.Popen(
                    [rust_binary, '--server'],
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, bufsize=0)
                procs.append(p)
                gd = {
                    'player': 1, 'moves': 0,
                    'states': [], 'policies': [],
                    'finished': False, 'winner': 0,
                    'trace': [],  # per-move controller metadata
                }
                if is_chess:
                    gd['fen'] = start_fen
                else:
                    gd['board'] = [0] * n2
                game_data.append(gd)

            time.sleep(0.1)

            for step in range(max_moves):
                active = [i for i in range(batch_n) if not game_data[i]['finished']]
                if not active: break

                # Send search_nn to all active games
                for gi in active:
                    gd = game_data[gi]
                    if is_chess:
                        req = json.dumps({'cmd':'search_nn','game':'chess',
                                          'iters':iters,'fen':gd['fen'],
                                          'penalty_mode':penalty_mode},
                                         separators=(',',':'))
                    else:
                        req = json.dumps({'cmd':'search_nn','game':rust_game,
                                          'iters':iters,'player':gd['player'],
                                          'board':gd['board'],'penalty_mode':penalty_mode},
                                         separators=(',',':'))
                    procs[gi].stdin.write(req + '\n')
                    procs[gi].stdin.flush()

                # Collect eval_reqs, batch, distribute
                pending = set(active)
                safety = 0
                while pending and safety < 2000:
                    safety += 1
                    batch_reqs = []

                    for gi in list(pending):
                        ready, _, _ = select.select([procs[gi].stdout], [], [], 0.05)
                        if not ready: continue
                        line = procs[gi].stdout.readline().strip()
                        if not line:
                            game_data[gi]['finished'] = True
                            pending.discard(gi); continue

                        if '"eval_req"' in line:
                            batch_reqs.append((gi, json.loads(line)['eval_req']))
                        elif '"result"' in line:
                            result = json.loads(line).get('result', {})
                            gd = game_data[gi]

                            pol_entries = result.get('policy', [])
                            if not pol_entries:
                                # Terminal — checkmate/stalemate
                                if is_chess:
                                    gd['winner'] = result.get('value', 0.0) * gd['player']
                                gd['finished'] = True
                                pending.discard(gi); continue

                            policy = np.zeros(n_actions, dtype=np.float32)
                            for entry in pol_entries:
                                if isinstance(entry, str) and ':' in entry:
                                    idx, val = entry.split(':')
                                    if int(idx) < n_actions: policy[int(idx)] = float(val)

                            # Encode + record
                            if is_chess:
                                enc = encode_board(cfg, _fen_to_board(gd['fen']), gd['player'])
                            else:
                                enc = encode_board(cfg, np.array(gd['board'], dtype=np.int8), gd['player'])
                            gd['states'].append(enc.copy())
                            gd['policies'].append(policy.copy())
                            gd['trace'].append({
                                'p_flip': result.get('p_flip', 0.0),
                                'value': result.get('value', 0.0),
                                'sigma_q': result.get('sigma_q', 0.0),
                                'stop_reason': result.get('stop_reason', ''),
                                'hbar_eff': result.get('hbar_eff', 0.0),
                                'iterations': result.get('iterations', 0),
                            })

                            if is_chess:
                                new_fen = result.get('result_fen', '')
                                if not new_fen or new_fen == gd['fen']:
                                    gd['finished'] = True
                                else:
                                    gd['fen'] = new_fen
                                    gd['moves'] += 1
                                    gd['player'] = -gd['player']
                                    parts = new_fen.split()
                                    if len(parts) >= 5 and int(parts[4]) >= 100:
                                        gd['finished'] = True
                            else:
                                best = result.get('best_move', -1)
                                legal = [j for j in range(n2) if gd['board'][j] == 0]
                                if best < 0 or best >= n2 or gd['board'][best] != 0:
                                    best = random.choice(legal) if legal else 0
                                gd['board'][best] = gd['player']
                                gd['moves'] += 1
                                won = False
                                if win_len > 0:
                                    r0, c0 = best//board_size, best%board_size
                                    for dr, dc in [(0,1),(1,0),(1,1),(1,-1)]:
                                        cnt = 1
                                        for sign in [1,-1]:
                                            nr, nc = r0+sign*dr, c0+sign*dc
                                            while 0<=nr<board_size and 0<=nc<board_size and gd['board'][nr*board_size+nc]==gd['player']:
                                                cnt += 1; nr += sign*dr; nc += sign*dc
                                        if cnt >= win_len: won = True; break
                                if won:
                                    gd['finished'] = True; gd['winner'] = gd['player']
                                elif not [j for j in range(n2) if gd['board'][j] == 0]:
                                    gd['finished'] = True
                                else:
                                    gd['player'] = -gd['player']
                            pending.discard(gi)

                    # BATCH NN EVAL
                    if batch_reqs and model is not None:
                        batch_features = []
                        for gi, er in batch_reqs:
                            feats = er.get('features', [])
                            na = er.get('num_actions', n_actions)
                            ch_cfg, bs = cfg['ch'], board_size
                            if len(feats) == ch_cfg * bs * bs:
                                x = np.array(feats, dtype=np.float32).reshape(ch_cfg, bs, bs)
                            else:
                                x = np.zeros((ch_cfg, bs, bs), dtype=np.float32)
                            batch_features.append(x)

                        with torch.no_grad():
                            x_batch = torch.tensor(np.array(batch_features), dtype=torch.float32).to(device)
                            logits_batch, vals_batch = model(x_batch)
                            probs_batch = F.softmax(logits_batch, dim=-1).cpu().numpy()
                            vals_np = vals_batch.cpu().numpy()

                        for bi, (gi, er) in enumerate(batch_reqs):
                            na = er.get('num_actions', n_actions)
                            pol = probs_batch[bi][:na].tolist()
                            val = float(vals_np[bi])
                            resp = json.dumps({'eval_resp': {'policy': pol, 'value': val}},
                                              separators=(',',':'))
                            procs[gi].stdin.write(resp + '\n')
                            procs[gi].stdin.flush()
                    elif batch_reqs:
                        for gi, er in batch_reqs:
                            na = er.get('num_actions', n_actions)
                            resp = json.dumps({'eval_resp':{'policy':[1.0/na]*na,'value':0.0}},
                                              separators=(',',':'))
                            procs[gi].stdin.write(resp + '\n')
                            procs[gi].stdin.flush()

            for gi in range(batch_n):
                gd = game_data[gi]
                all_states.append(gd['states'])
                all_policies.append(gd['policies'])
                all_outcomes.append(float(gd.get('winner', 0)))
                all_traces.append(gd.get('trace', []))
                pbar.update(1)

            for p in procs:
                try:
                    p.stdin.write('{"cmd":"quit"}\n')
                    p.stdin.flush()
                    p.wait(timeout=3)
                except Exception:
                    p.kill()

            games_done += batch_n

    return all_states, all_policies, all_outcomes, all_traces


# ═══════════════════════════════════════════
# § Evaluation Integration (Glicko-2 + PromotionGate)
# ═══════════════════════════════════════════

try:
    from calibration_eval import (
        TrainingEvaluator, EvalConfig, PromotionVerdict,
        RatingLadder, PromotionGate, ChampionTracker,
        RandomEngine as EvalRandomEngine, MatchRunner, tally_match,
        GameAdapter, Engine as EvalEngine,
    )
    HAS_EVAL_SYSTEM = True
except ImportError:
    HAS_EVAL_SYSTEM = False

class TreeMCTSEngine:
    """Wraps TreeMCTS to conform to calibration_eval.Engine protocol."""
    def __init__(self, engine_name, cfg, model, device):
        self._name = engine_name
        self._mcts = TreeMCTS(cfg, model, device)
        self._cfg = cfg
    def select_move(self, state):
        board_enc = state._encode()
        # GomokuGameAdapter.current_player() returns 0/1 (for calibration_eval protocol)
        # TreeMCTS.search() expects 1/-1 (for board encoding)
        raw_player = state.current_player()  # 0 = black, 1 = white
        player = 1 if raw_player == 0 else -1  # convert to 1/-1
        n2 = state._bs ** 2
        legal_mask = np.array([1.0 if state._board[i]==0 else 0.0 for i in range(min(n2, self._cfg['actions']))])
        if self._cfg['actions'] > n2:
            legal_mask = np.concatenate([legal_mask, np.zeros(self._cfg['actions']-n2)])
        policy = self._mcts.search(board_enc, player, legal_mask, self._cfg['iters']//4)
        legal = state.legal_moves()
        if legal:
            chosen = max(legal, key=lambda a: policy[a] if a < len(policy) else 0)
        else:
            chosen = 0
        return chosen, {"time_used_ms": 0, "simulations": self._cfg['iters']//4}
    def reset(self): pass
    def name(self): return self._name


class RustNNEvaluatorEngine:
    """Evaluator engine using full Rust MCTS + NN for promotion evaluation.
    
    Uses the same Rust search stack as training self-play (TT+VL+PW+QUARTZ),
    ensuring evaluation semantics match training semantics.
    """
    def __init__(self, engine_name, cfg, model, device,
                 rust_binary="./target/release/mcts_demo"):
        self._name = engine_name
        self._cfg = cfg
        self._model = model
        self._device = device
        self._rust_binary = rust_binary
        self._client = None

    def _ensure_client(self):
        if self._client is None:
            self._client = NNSearchClient(self._model, self._cfg, self._device, self._rust_binary)
            self._client.start()

    def select_move(self, state):
        self._ensure_client()
        raw_player = state.current_player()
        player = 1 if raw_player == 0 else -1
        board_signed = [0 if x == 0 else (1 if x == 1 else -1) for x in state._board]
        penalty_mode = self._cfg.get('penalty_mode', 'GatedRefresh')
        result = self._client.search_move(board_signed, player, penalty_mode)
        if not result or 'error' in result:
            # Fallback to random legal move
            legal = state.legal_moves()
            return (legal[0] if legal else 0), {"time_used_ms": 0, "simulations": 0}
        pol_entries = result.get('policy', [])
        policy = np.zeros(self._cfg['actions'], dtype=np.float32)
        for entry in pol_entries:
            if isinstance(entry, str) and ':' in entry:
                idx, val = entry.split(':')
                if int(idx) < self._cfg['actions']:
                    policy[int(idx)] = float(val)
        legal = state.legal_moves()
        if legal:
            chosen = max(legal, key=lambda a: policy[a] if a < len(policy) else 0)
        else:
            chosen = 0
        return chosen, {
            "time_used_ms": 0,
            "simulations": self._cfg.get('iters', 200),
            "p_flip": result.get('p_flip', 0),
            "engine": "rust_nn",
        }

    def reset(self):
        if self._client:
            self._client.stop()
            self._client = None

    def name(self): return self._name

    def __del__(self):
        self.reset()

class GomokuGameAdapter:
    """Wraps flat board array to conform to calibration_eval.GameAdapter protocol."""
    def __init__(self, board_size=7, win_len=4, encoder=None):
        self._bs = board_size; self._wl = win_len
        self._board = [0] * (board_size * board_size)
        self._player = 1  # 1 = black (first), -1 = white
        self._terminal = False; self._outcome = None
        self._encoder = encoder
        self._ch = encoder.n_channels if encoder else 3
    def clone(self):
        g = GomokuGameAdapter(self._bs, self._wl, self._encoder)
        g._board = self._board[:]; g._player = self._player
        g._terminal = self._terminal; g._outcome = self._outcome
        return g
    def apply_move(self, action):
        self._board[action] = self._player
        # Check win
        r0, c0 = action // self._bs, action % self._bs
        for dr, dc in [(0,1),(1,0),(1,1),(1,-1)]:
            cnt = 1
            for sign in [1,-1]:
                nr, nc = r0+sign*dr, c0+sign*dc
                while 0<=nr<self._bs and 0<=nc<self._bs and self._board[nr*self._bs+nc]==self._player:
                    cnt += 1; nr += sign*dr; nc += sign*dc
            if cnt >= self._wl:
                self._terminal = True
                self._outcome = 1.0 if self._player == 1 else -1.0
                self._player = -self._player
                return
        if not any(b == 0 for b in self._board):
            self._terminal = True; self._outcome = 0.0
        self._player = -self._player
    def is_terminal(self): return self._terminal
    def outcome_for_black(self): return self._outcome
    def current_player(self): return 0 if self._player == 1 else 1
    def legal_moves(self):
        if self._terminal: return []
        return [i for i in range(len(self._board)) if self._board[i] == 0]
    def _encode(self):
        """Encode using game-agnostic encoder if available."""
        if self._encoder is not None:
            return self._encoder.encode(np.array(self._board, dtype=np.int8), self._player)
        # Fallback: 3-plane encoding
        enc = np.zeros((self._ch, self._bs, self._bs), dtype=np.float32)
        for i in range(self._bs * self._bs):
            r, c = i // self._bs, i % self._bs
            if self._board[i] == self._player: enc[0,r,c] = 1.0
            elif self._board[i] != 0: enc[1,r,c] = 1.0
        if self._ch >= 3 and self._player == 1: enc[2] = 1.0
        return enc


def main():
    parser = argparse.ArgumentParser(description="QUARTZ AlphaZero Training")
    parser.add_argument("--game", choices=list(GAME_CONFIGS.keys()), default="gomoku15")
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--serve", action="store_true")
    parser.add_argument("--arena", nargs=2, metavar=("MODEL_A","MODEL_B"),
                        help="Compare two models head-to-head (e.g. --arena best_a.pt best_b.pt)")
    parser.add_argument("--arena-games", type=int, default=50)
    parser.add_argument("--arena-3agent", nargs=2, metavar=("CURRENT","BEST"),
                        help="3-agent arena: current model, best model, + random anchor")
    parser.add_argument("--concurrent", action="store_true",
                        help="Run self-play in background thread while training")
    parser.add_argument("--backend", choices=["auto","jax","torch"], default="auto",
                        help="ML backend: auto (best available), jax (JIT), torch")
    parser.add_argument("--rust-nn", action="store_true", default=True,
                        help=argparse.SUPPRESS)
    parser.add_argument("--model", default=None)
    parser.add_argument("--output", default=None)
    parser.add_argument("--config", default=None)
    parser.add_argument("--patience", type=int, default=15, help="Early stopping patience")
    parser.add_argument("--rust-binary", default="./target/release/mcts_demo")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    parser.add_argument("--eval-interval", type=int, default=10,
                        help="Run Glicko-2 evaluation every N iterations")
    parser.add_argument("--eval-games", type=int, default=20,
                        help="Number of games per evaluation")
    args = parser.parse_args()

    # Fix 9: Reproducibility
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    cfg = dict(GAME_CONFIGS[args.game])
    cfg['_name'] = args.game

    # Attach game-agnostic encoder
    if get_encoder is not None:
        try:
            cfg['_encoder'] = get_encoder(args.game)
            print(f"  Encoder: {type(cfg['_encoder']).__name__} ({cfg['_encoder'].n_channels}ch, {cfg['_encoder'].n_actions} actions)")
        except KeyError:
            cfg['_encoder'] = None
    else:
        cfg['_encoder'] = None

    # Load config overrides
    if args.config and os.path.exists(args.config):
        with open(args.config) as f:
            overrides = json.load(f)
            cfg.update({k:v for k,v in overrides.items() if k in cfg})

    base_dir = args.output or f"alphazero_{args.game}"
    Path(base_dir).mkdir(parents=True, exist_ok=True)
    model_path = args.model or f"{base_dir}/best.pt"
    replay_path = f"{base_dir}/replay.npz"
    log_path = f"{base_dir}/train_log.jsonl"

    # Device
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    # Model + Backend
    backend = None
    model = AlphaZeroNet(cfg).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    optimizer = None

    if not args.serve and not args.arena:
        # Try unified backend for training (JAX JIT if available)
        try:
            import sys as _sys
            _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from backend import create_backend
            backend = create_backend(cfg, device=str(device), preference=args.backend)
            backend.load(model_path)
            n_params_str = f"{n_params:,}"
            print(f"  Using {backend.name.upper()} backend ({n_params_str} params)")
        except Exception as e:
            print(f"  Backend init failed ({e}), using direct PyTorch")
            backend = None

    if backend is None:
        if os.path.exists(model_path):
            model.load_state_dict(torch.load(model_path, map_location=device, weights_only=True))
            print(f"Loaded model: {model_path}")
        optimizer = torch.optim.SGD(model.parameters(), lr=0.02, momentum=0.9, weight_decay=1e-4)

    if args.serve:
        serve(model, cfg, device)
        return

    if args.arena_3agent:
        rating_path = os.path.join(base_dir, "glicko2_ratings.json")
        ratings, promoted = arena_3agent(
            args.arena_3agent[0], args.arena_3agent[1], cfg, device,
            games_per_pair=args.arena_games // 3, rust_binary=args.rust_binary,
            use_rust_nn=args.rust_nn, rating_path=rating_path)
        return

    if args.arena:
        if args.rust_nn:
            print("  Arena mode: Rust MCTS + NN (full search stack)")
            wa, wb, d, wr, ci, sprt = arena_rust_nn(
                args.arena[0], args.arena[1], cfg, device, args.arena_games, args.rust_binary)
        else:
            print("  Arena mode: Python TreeMCTS")
            wa, wb, d, wr, ci, sprt = arena_compare(
                args.arena[0], args.arena[1], cfg, device, args.arena_games)
        print(f"Arena: A={wa} B={wb} D={d} | WinRate_A={wr:.3f} 95%CI=[{ci[0]:.3f},{ci[1]:.3f}] SPRT={sprt}")
        if sprt == "H1_accept": print("  → SPRT: Model A is significantly stronger (p<0.05)")
        elif sprt == "H0_accept": print("  → SPRT: No significant difference (p<0.05)")
        else: print(f"  → SPRT: Inconclusive after {args.arena_games} games")
        return

    if args.arena_3agent:
        from rating import RatingStore, round_robin_arena, Rating, ANCHOR_MU
        print(f"  3-Agent Arena: random + current + best")
        current_path, best_path = args.arena_3agent
        model_cur = AlphaZeroNet(cfg).to(device)
        model_cur.load_state_dict(torch.load(current_path, map_location=device, weights_only=True))
        model_cur.eval()
        model_best = AlphaZeroNet(cfg).to(device)
        model_best.load_state_dict(torch.load(best_path, map_location=device, weights_only=True))
        model_best.eval()

        mcts_random = TreeMCTS(cfg, model=None, device=device)
        mcts_cur = TreeMCTS(cfg, model=model_cur, device=device)
        mcts_best = TreeMCTS(cfg, model=model_best, device=device)

        def make_play_fn(board_size, n_actions, win_len, iters):
            def play(agent_a, agent_b, n_games):
                wa, wb, d = 0, 0, 0
                for gi in range(n_games):
                    first, second = (agent_a, agent_b) if gi%2==0 else (agent_b, agent_a)
                    first_is_a = (gi % 2 == 0)
                    board = np.zeros(board_size**2, dtype=np.int8)
                    player = 1; winner = 0
                    for _ in range(board_size**2):
                        enc = np.zeros((cfg['ch'], board_size, board_size), dtype=np.float32)
                        for i in range(board_size**2):
                            r,c = i//board_size, i%board_size
                            if board[i]==player: enc[0,r,c]=1.0
                            elif board[i]!=0: enc[1,r,c]=1.0
                        if cfg['ch']>=3 and player==1: enc[2]=1.0
                        legal_mask = np.array([1.0 if board[i]==0 else 0.0 for i in range(min(board_size**2,n_actions))])
                        if n_actions > board_size**2: legal_mask = np.concatenate([legal_mask, np.zeros(n_actions-board_size**2)])
                        mcts = first if player==1 else second
                        pol = mcts.search(enc, player, legal_mask, iters//4)
                        legal = [i for i in range(board_size**2) if board[i]==0]
                        if not legal: break
                        chosen = max(legal, key=lambda a: pol[a] if a<n_actions else 0)
                        board[chosen] = player
                        if win_len > 0:
                            r0,c0 = chosen//board_size, chosen%board_size
                            for dr,dc in [(0,1),(1,0),(1,1),(1,-1)]:
                                cnt=1
                                for sign in [1,-1]:
                                    nr,nc=r0+sign*dr,c0+sign*dc
                                    while 0<=nr<board_size and 0<=nc<board_size and board[nr*board_size+nc]==player:
                                        cnt+=1;nr+=sign*dr;nc+=sign*dc
                                if cnt>=win_len: winner=player;break
                            if winner: break
                        player = -player
                    if winner==1:
                        if first_is_a: wa+=1
                        else: wb+=1
                    elif winner==-1:
                        if first_is_a: wb+=1
                        else: wa+=1
                    else: d+=1
                return wa, wb, d
            return play

        agents = {"random": mcts_random, "current": mcts_cur, "best": mcts_best}
        play_fn = make_play_fn(cfg['board'], cfg['actions'], cfg['win'], cfg['iters'])
        store_path = os.path.join(base_dir, "ratings.json")
        store = RatingStore(store_path)
        store.set("random", Rating(mu=ANCHOR_MU, phi=100.0, sigma=0.06))

        ratings = round_robin_arena(agents, play_fn, args.arena_games // 3, store)
        print(store.summary())
        print(f"\n  Ratings saved to {store_path}")
        return

    print(f"Game: {args.game} ({cfg['board']}×{cfg['board']})")
    print(f"Model: {n_params:,} params, {cfg['filters']}f×{cfg['blocks']}b")
    print(f"Backend: {backend.name if backend else 'PyTorch (direct)'}")
    print(f"Device: {device}")
    print(f"Output: {base_dir}")

    # Replay buffer
    replay = ReplayBuffer(cfg['buf'])
    if args.resume:
        n = replay.load(replay_path)
        if n: print(f"Loaded {n} positions from replay")
    stopper = EarlyStopping(patience=args.patience)
    log_f = open(log_path, "a")

    # ── Evaluation system (Glicko-2 + PromotionGate) ──
    training_evaluator = None
    best_model_path = os.path.join(base_dir, "best.pt")
    if HAS_EVAL_SYSTEM:
        eval_cfg = EvalConfig(
            num_games=args.eval_games,
            promotion_threshold=0.55,
            confidence=0.95,
            sanity_check_interval=5,
            ladder_path=os.path.join(base_dir, "glicko2_ladder.json"),
            log_path=os.path.join(base_dir, "eval_matches.jsonl"),
            champion_path=os.path.join(base_dir, "champion.json"),
            seed=args.seed,
        )
        game_factories = {
            "gomoku7": lambda: GomokuGameAdapter(7, 4, cfg.get('_encoder')),
            "gomoku15": lambda: GomokuGameAdapter(15, 5, cfg.get('_encoder')),
        }
        game_factory = game_factories.get(args.game)
        if game_factory:
            training_evaluator = TrainingEvaluator(config=eval_cfg)
            # Save initial model as best
            if backend: backend.save(best_model_path)
            elif model: torch.save(model.state_dict(), best_model_path)
            print(f"  Eval system: Glicko-2 + PromotionGate (every {args.eval_interval} iters, {args.eval_games} games)")
        else:
            print(f"  Eval system: not available for {args.game} (gomoku7/gomoku15 only)")

    # Check Rust binary
    rust_ok = os.path.exists(args.rust_binary)
    if not rust_ok:
        print(f"WARNING: Rust binary not found at {args.rust_binary}")
        print(f"  Training requires Rust. Run: cargo build --release")

    print(f"\n{'='*60}")
    print(f"  Training: {args.iterations} iterations, {cfg['games']} games/iter")
    if args.concurrent: print(f"  Mode: CONCURRENT (background self-play)")
    print(f"{'='*60}\n")

    # Start background self-play worker if concurrent
    bg_worker = None
    if args.concurrent:
        if not rust_ok:
            print("ERROR: --concurrent requires Rust binary. Run: cargo build --release")
            sys.exit(1)
        bg_worker = SelfPlayWorker(cfg, model, device, replay, args.rust_binary)
        bg_worker.start()
        print("  [BG] Self-play worker started (Rust+NN)")
        # Wait for initial replay fill
        while len(replay) < cfg['batch'] and not stopper.should_stop:
            time.sleep(0.5)
            print(f"\r  [BG] Filling replay: {len(replay)}/{cfg['batch']}...", end="", flush=True)
        print()

    for iteration in range(args.iterations):
        t0 = time.time()
        # LR schedule
        progress = iteration / max(args.iterations, 1)
        lr = 0.0002 + 0.5 * (0.02 - 0.0002) * (1 + math.cos(math.pi * progress))
        if optimizer:
            for pg in optimizer.param_groups: pg['lr'] = lr
        if backend: backend.set_lr(lr)

        # ── Self-play (Rust+NN: sole training engine) ──
        n_new = 0
        if args.concurrent:
            prev_bg = getattr(bg_worker, "_prev_count", 0); n_new = bg_worker.positions_generated - prev_bg; bg_worker._prev_count = bg_worker.positions_generated
        elif rust_ok:
            # Rust MCTS (TT+VL+PW+QUARTZ) + batched Python NN evaluation
            states, policies, outcomes, traces = selfplay_rust_nn_batched(
                cfg, model, device, cfg['games'], args.rust_binary, parallel=4)
            for gs, gp, out in zip(states, policies, outcomes):
                replay.add_game(gs, gp, out)
                n_new += len(gs)
            # Aggregate controller trace for logging
            all_pflips = [t.get('p_flip',0) for tr in traces for t in tr if t]
            avg_pflip = sum(all_pflips)/max(len(all_pflips),1) if all_pflips else 0
        else:
            print("ERROR: Rust binary required for training. Run: cargo build --release")
            print(f"  Expected: {args.rust_binary}")
            sys.exit(1)

        # ── Training ──
        if len(replay) >= cfg['batch']:
            avg_loss, avg_pl, avg_vl = train_epoch(model, optimizer, replay, cfg, device, cfg['steps'], backend=backend)
            elapsed = time.time() - t0

            entry = {"iter": iteration+1, "loss": round(avg_loss,4),
                     "p_loss": round(avg_pl,4), "v_loss": round(avg_vl,4),
                     "lr": round(lr,6), "replay": len(replay), "new_pos": n_new,
                     "time_s": round(elapsed,1),
                     "pos_per_s": round(n_new / max(elapsed, 0.1), 1),
                     "games_done": cfg["games"],
                     "avg_pflip": round(avg_pflip, 4) if "avg_pflip" in dir() else 0,
                     "replay_freshness": round(ReplayMetrics.freshness(n_new, len(replay)), 4),
                     "policy_entropy": round(ReplayMetrics.policy_entropy(replay), 3),
                     "value_std": round(ReplayMetrics.value_std(replay), 4)}
            log_f.write(json.dumps(entry) + "\n"); log_f.flush()

            print(f"[{iteration+1:>3}/{args.iterations}] loss={avg_loss:.4f} (p={avg_pl:.4f} v={avg_vl:.4f}) "
                  f"lr={lr:.5f} replay={len(replay)} +{n_new} {elapsed:.1f}s")

            # Early stopping
            if stopper.step(avg_loss):
                print(f"\n  Early stopping at iter {iteration+1} (patience={args.patience})")
                break
        else:
            elapsed = time.time() - t0
            print(f"[{iteration+1:>3}/{args.iterations}] filling replay: {len(replay)}/{cfg['batch']} +{n_new} {elapsed:.1f}s")

        # ── Checkpoint ──
        if (iteration + 1) % 5 == 0:
            if backend: backend.save(model_path)
            else: torch.save(model.state_dict(), model_path)
            replay.save(replay_path)
            print(f"  Checkpoint: {model_path} (replay={len(replay)})")
            # Refresh background worker's model snapshot
            if bg_worker: bg_worker.update_model(model)

        # ── Evaluation (Glicko-2 + Promotion) ──
        if training_evaluator and (iteration + 1) % args.eval_interval == 0 and game_factory:
            print(f"  Evaluating gen_{iteration+1} vs champion...")
            # Create engines using same Rust+NN stack as training
            if rust_ok:
                cand_eng = RustNNEvaluatorEngine(
                    f"gen_{iteration+1}", cfg, model, device, args.rust_binary)
            else:
                print("  [WARN] Rust binary not found, using TreeMCTS for evaluation (NOT benchmark-grade)")
                cand_eng = TreeMCTSEngine(f"gen_{iteration+1}", cfg, model, device)
            # Create champion engine from best model
            best_model_copy = AlphaZeroNet(cfg).to(device)
            if os.path.exists(best_model_path):
                best_model_copy.load_state_dict(
                    torch.load(best_model_path, map_location=device, weights_only=True))
            best_model_copy.eval()
            if rust_ok:
                champ_eng = RustNNEvaluatorEngine(
                    "champion", cfg, best_model_copy, device, args.rust_binary)
            else:
                champ_eng = TreeMCTSEngine("champion", cfg, best_model_copy, device)
            # Run evaluation
            eval_result = training_evaluator.evaluate_checkpoint(
                candidate=cand_eng, champion=champ_eng, game_factory=game_factory,
                candidate_id=f"gen_{iteration+1}", generation=iteration+1)
            # Log result
            v = eval_result.promotion.get("verdict", "?")
            sr = eval_result.tally.get("score_rate", 0) if eval_result.tally else 0
            elo_d = eval_result.elo.get("delta", 0) if eval_result.elo else 0
            pub = eval_result.published.get("candidate_abs", "?") if eval_result.published else "?"
            print(f"  Eval: {v} | sr={sr:.3f} | ΔElo={elo_d:+.0f} | AbsElo={pub}")
            # If promoted, update best model
            if v == "promote":
                if backend: backend.save(best_model_path)
                else: torch.save(model.state_dict(), best_model_path)
                print(f"  ★ PROMOTED: gen_{iteration+1} is new champion!")
            # Write to training log
            log_f.write(json.dumps({"_type": "eval", "iter": iteration+1,
                                     "verdict": v, "score_rate": sr,
                                     "delta_elo": elo_d, "published_elo": pub,
                                     "games": eval_result.tally.get("scored",0) if eval_result.tally else 0
                                     }) + "\n")
            log_f.flush()

    log_f.close()
    if bg_worker: bg_worker.stop()
    if backend: backend.save(model_path)
    else: torch.save(model.state_dict(), model_path)
    print(f"\nDone. Model: {model_path}")

if __name__ == "__main__":
    main()

