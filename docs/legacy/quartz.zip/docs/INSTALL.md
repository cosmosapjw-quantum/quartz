# Installation Guide

## Prerequisites

- **Rust** ≥ 1.70 (recommended: 1.94+)
- **Python** ≥ 3.10
- **PyTorch** ≥ 2.0 (CPU, CUDA, or ROCm)
- **Optional**: JAX (for JAX backend), onnxruntime (for ONNX inference)

---

## Option A: Native Install (NVIDIA / CPU)

### 1. Build Rust Engine

```bash
git clone <repo-url> quartz && cd quartz

# Install Rust if needed
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env

# Build
cargo build --release
cargo test --release    # ~270+ tests should pass
```

### 2. Install Python Dependencies

```bash
# Create virtual environment (recommended)
python3 -m venv .venv && source .venv/bin/activate

# NVIDIA GPU (CUDA 12.x)
pip install torch --index-url https://download.pytorch.org/whl/cu121

# CPU only
pip install torch --index-url https://download.pytorch.org/whl/cpu

# Install QUARTZ package
pip install -e .
```

### 3. Verify

```bash
./target/release/mcts_demo --server <<< '{"cmd":"quit"}'
python3 -c "from quartz.evaluation import _run_all; _run_all()"
python3 -m quartz.train --help
```

---

## Option B: AMD ROCm (Native)

ROCm requires Linux with a supported AMD GPU (RDNA2+, e.g. RX 6000/7000 series
or Instinct MI series).

### 1. Install ROCm

```bash
# Ubuntu 22.04/24.04 — follow AMD's official docs:
# https://rocm.docs.amd.com/projects/install-on-linux/en/latest/

# Verify ROCm installation
rocm-smi              # should list your GPU
hipcc --version        # HIP compiler version
```

### 2. PyTorch for ROCm

```bash
# ROCm 6.2 (match your installed ROCm version)
pip install torch --index-url https://download.pytorch.org/whl/rocm6.2

# Verify
python3 -c "import torch; print(torch.cuda.is_available())"  # True on ROCm
python3 -c "import torch; print(torch.version.hip)"            # e.g. '6.2.x'
```

### 3. ONNX Runtime for ROCm

```bash
pip install onnxruntime-rocm

# Verify
python3 -c "
import onnxruntime as ort
print(ort.get_available_providers())
# Should include 'ROCmExecutionProvider' or 'MIGraphXExecutionProvider'
"
```

### 4. JAX for ROCm

JAX ROCm support is experimental. Use Docker (see below) for reliable setup.

```bash
# Native install (may require building from source)
pip install jax[rocm] -f https://storage.googleapis.com/jax-releases/rocm/jaxlib-0.4.30+rocm620.find_links.html

# Verify
python3 -c "import jax; print(jax.devices())"  # should show hip device
```

### 5. Build Rust + Train

```bash
cargo build --release
python3 -m quartz.train --game gomoku7 --iterations 30
```

QUARTZ auto-detects ROCm via `rocm-smi` and selects the GPU device
automatically. Override with `--device cpu` if needed.

---

## Option C: Docker (Recommended for ROCm / Reproducibility)

Docker provides the most reliable environment, especially for AMD GPUs
where driver/library version mismatches are common.

### Dockerfile (ROCm + PyTorch + JAX + ONNX)

```dockerfile
FROM rocm/pytorch:rocm6.2_ubuntu22.04_py3.10_pytorch_release_2.3.0

# System dependencies
RUN apt-get update && apt-get install -y \
    curl build-essential pkg-config libssl-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Rust
RUN curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
ENV PATH="/root/.cargo/bin:${PATH}"

# Python dependencies
RUN pip install --no-cache-dir \
    numpy scipy tqdm \
    onnxruntime-rocm \
    && pip install --no-cache-dir \
    jax[rocm] -f https://storage.googleapis.com/jax-releases/rocm/jaxlib-0.4.30+rocm620.find_links.html \
    || echo "JAX ROCm install failed (optional)"

WORKDIR /workspace/quartz
COPY . .

# Build Rust engine
RUN cargo build --release

# Install Python package
RUN pip install -e .

# Verify
RUN cargo test --release 2>&1 | tail -1
RUN python3 -c "from quartz.evaluation import _run_all; _run_all()"

CMD ["python3", "-m", "quartz.train", "--help"]
```

### Dockerfile (CUDA + PyTorch)

```dockerfile
FROM pytorch/pytorch:2.3.0-cuda12.1-cudnn8-devel

RUN apt-get update && apt-get install -y curl build-essential && rm -rf /var/lib/apt/lists/*
RUN curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
ENV PATH="/root/.cargo/bin:${PATH}"

RUN pip install --no-cache-dir numpy scipy tqdm onnxruntime-gpu

WORKDIR /workspace/quartz
COPY . .
RUN cargo build --release && pip install -e .

CMD ["python3", "-m", "quartz.train", "--help"]
```

### Build and Run

```bash
# Build image
docker build -t quartz-rocm -f Dockerfile.rocm .

# Run training (AMD GPU passthrough)
docker run --rm -it \
    --device=/dev/kfd --device=/dev/dri \
    --group-add video \
    --shm-size=8g \
    -v $(pwd)/models:/workspace/quartz/models \
    quartz-rocm \
    python3 -m quartz.train --game gomoku7 --iterations 30

# Run training (NVIDIA GPU)
docker run --rm -it --gpus all \
    -v $(pwd)/models:/workspace/quartz/models \
    quartz-cuda \
    python3 -m quartz.train --game gomoku7 --iterations 30

# Run ablation
docker run --rm -it --device=/dev/kfd --device=/dev/dri --group-add video \
    quartz-rocm \
    cargo test --release -- ablation_vl --ignored --nocapture
```

### Docker Compose (optional)

```yaml
# docker-compose.yml
services:
  quartz-train:
    build:
      context: .
      dockerfile: Dockerfile.rocm
    devices:
      - /dev/kfd
      - /dev/dri
    group_add:
      - video
    shm_size: '8g'
    volumes:
      - ./models:/workspace/quartz/models
    command: python3 -m quartz.train --game gomoku7 --iterations 50
```

---

## ONNX Export and Inference

ONNX enables deployment without PyTorch/JAX. Supported providers:
CPU, CUDA, ROCm, TensorRT, DirectML, CoreML.

### Export

```python
from quartz.onnx_support import export_onnx
from python.alphazero_train import AlphaZeroNet

cfg = {'board': 7, 'actions': 49, 'channels': 32, 'blocks': 2, 'in_channels': 3}
model = AlphaZeroNet(cfg)
model.load_state_dict(torch.load("models/gomoku7_train/best.pt"))

export_onnx(model, cfg, "model.onnx")
```

### Inference

```python
from quartz.onnx_support import OnnxPredictor

pred = OnnxPredictor("model.onnx")
# pred auto-selects best provider: ROCm > CUDA > CPU

policy, value = pred.predict(board_tensor)
```

### Provider Selection

| Provider | Install | Auto-detected |
|----------|---------|---------------|
| CPU | `pip install onnxruntime` | Always |
| CUDA | `pip install onnxruntime-gpu` | If CUDA available |
| ROCm | `pip install onnxruntime-rocm` | If ROCm available |
| TensorRT | `pip install onnxruntime-gpu` + TensorRT | If TensorRT installed |
| DirectML | `pip install onnxruntime-directml` | Windows + DX12 GPU |

---

## JAX Backend

QUARTZ supports JAX as an alternative training backend. JAX is auto-detected
at runtime; no code changes needed.

### Install

```bash
# CPU
pip install jax jaxlib

# CUDA
pip install jax[cuda12]

# ROCm (use Docker for reliability)
pip install jax[rocm]
```

### Usage

```bash
# JAX is auto-selected when available and PyTorch is not
# Or force via backend config in training script
python3 -m quartz.train --game gomoku7 --iterations 30
```

### Limitations

- JAX backend handles the **training loop** (forward/backward/update)
- Self-play NN evaluation currently uses **PyTorch direct path**
- For full JAX end-to-end, the eval responder would need JAX inference
  (not yet implemented)

---

## Hardware Reference

| Setup | Self-play | NN Eval | Notes |
|-------|-----------|---------|-------|
| CPU only | Rust (rayon) | PyTorch CPU | Works, slow for large boards |
| NVIDIA GPU | Rust (rayon) | PyTorch CUDA | Recommended |
| AMD GPU (ROCm) | Rust (rayon) | PyTorch ROCm | Docker recommended |
| Apple Silicon | Rust (rayon) | PyTorch MPS | Auto-detected |

QUARTZ auto-detects your hardware via `quartz.gpu_detect`. The detection
checks (in order): `nvidia-smi`, `rocm-smi`, macOS `sysctl`, and falls
back to CPU.

```python
from quartz.gpu_detect import detect_gpu, install_commands
gpu = detect_gpu()
print(gpu)          # GpuInfo(vendor='amd', arch='gfx1030', driver='rocm-6.2', vram_mb=8192)
print(install_commands(gpu))  # ['pip install torch --index-url ...rocm6.2']
```

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `cargo build` fails with network error | crates.io unreachable | `cargo build --locked` or vendor deps |
| `RuntimeError: Rust binary not found` | Binary not built | `cargo build --release` |
| `ModuleNotFoundError` on import | Package not installed | `pip install -e .` or set PYTHONPATH |
| CUDA out of memory | Model too large | Reduce `--channels` or `--device cpu` |
| ROCm: `hip error` at runtime | Driver mismatch | Match PyTorch ROCm version to installed ROCm |
| ROCm: `hipErrorNoBinaryForGpu` | Unsupported GPU arch | Check GPU is RDNA2+ or set `HSA_OVERRIDE_GFX_VERSION` |
| JAX: `No GPU/TPU found` | Wrong jaxlib build | Reinstall with correct CUDA/ROCm suffix |
| ONNX: `ROCmExecutionProvider not found` | Wrong onnxruntime | `pip install onnxruntime-rocm` |
| Docker: `/dev/kfd permission denied` | User not in video group | `--group-add video` in docker run |
