# CPU Performance Notes (Python ↔ C++)

## 1) 우리가 원하는 “CPU-only MCTS+NN”에서 병목이 어디냐
대부분의 경우 병목은 두 개로 갈린다.

1) NN 추론 (policy+value)  
2) MCTS 핫루프 (selection/backup + TT)

QUARTZ의 1차 목표는 “CPU-only에서도 시간 분포가 안정적”이어야 하므로,
성능 문제는 v0부터 계속 추적한다.

---

## 2) CPU-only 목표에 맞는 운영(Teacher → Student)
최종 배포는 CPU-only가 목표다. 그래서 “강한 교사 모델”을 만들더라도,
**배포는 student 모델(경량) + CPU MCTS**로 맞춘다.

권장 루트:
- teacher: (GPU) ResNet(+SE,+gpool)로 강한 정책/가치 확보
- student: (CPU) 더 작은 ResNet 또는 경량(conv-separable / quant-ready)
- distillation: teacher 정책(soft)과 value를 student가 모사
- 마지막: CPU budget policy(0.5s/5s/15s/30s cap)로 self-play를 조금 돌려 “배포 분포 정렬”

---

## 3) Python free-threading(no-GIL)이 도움 되는 지점
Python 3.13+의 free-threaded build는 GIL이 꺼진 상태에서
파이썬 스레드가 CPU 코어를 병렬로 쓸 수 있게 해준다.

이게 도움 되는 경우:
- 파이썬 레벨에서 “진짜 CPU 연산”을 많이 하는 코드
- 락이 적고, 큰 작업 단위가 있는 경우(예: feature 추출, 배치 처리)

도움이 제한적인 경우:
- 매우 작은 단위의 업데이트(atomic N++, W+=…)
- dict/list 같은 파이썬 객체를 초고빈도로 만지는 핫루프
- TT 같은 공유 해시맵을 파이썬 dict로 처리

즉, free-threading은 “파이썬에 남아도 되는 범위”를 넓혀주지만,
MCTS 핵심을 파이썬으로 끝까지 밀어붙이는 마법은 아니다.

---

## 4) GIL과 무관하게 먹히는 최적화(가장 먼저 해야 할 것)

### 4.1 배치 추론(가장 큰 레버)
- leaf 평가 요청을 모아서 16~128 배치로 한 번에 NN 호출
- CPU에서도 효과가 크고, GPU inference server를 붙이면 더 커진다.

### 4.2 메모리/배열 구조화
- 파이썬 객체 대신 “구조화 배열/버퍼”
  - 예: numpy structured array, array('I'), memoryview, torch tensor
- 분기/포인터 추적 줄이기

### 4.3 락 범위 줄이기
- per-node lock → per-bucket lock → optimistic read
- virtual loss를 최소한으로 쓰고, 필요할 때만 쓰는 방식도 가능

### 4.4 ONNXRuntime(oneDNN) + (선택) INT8
- student 모델은 ONNX export를 기본 경로로 둔다.
- 성능이 부족하면, INT8(또는 weight-only quant)을 “학생 단계”에서만 적용한다.
  - teacher는 fp16/bf16로 두고, student만 quant하는 게 실전적으로 깔끔하다.

---

## 5) “어느 수준에서 C++이 필수인가” 실전 기준
다음 중 하나라도 해당하면 C++ 이관이 강력 추천이다.

- nps가 스레드 수를 늘려도 거의 안 늘어난다(락/파이썬 오버헤드)
- TT hit rate가 높아지는데도 speedup이 없다(파이썬 dict 병목)
- move 당 수백만 단위의 작은 업데이트가 필요하다(원자 연산 지옥)
- p99 move time이 크게 튄다(파이썬 GC/락 경합)

반대로, 아래는 Python에 남겨도 된다.
- self-play 오케스트레이션
- 데이터 저장/샘플링
- 학습 루프(GPU)
- 실험 자동화/튜닝(Optuna 등)
- stage gate 자동 판정/리포트 생성

---

## 6) 추천 개발 순서
1) Python으로 end-to-end 동작 + 로그/지표 확보  
2) 프로파일링으로 “핫 루프”만 C++로 이관  
3) inference는 ONNXRuntime/oneDNN로 CPU 최적화  
4) Teacher→Student distillation으로 CPU-only 품질 확보  
5) QUARTZ 모듈은 baseline 위에서 ON/OFF로 ablation
