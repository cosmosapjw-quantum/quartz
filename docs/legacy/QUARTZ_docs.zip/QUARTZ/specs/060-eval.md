# specs/060-eval.md

## Purpose
평가/비교/엘로 산출 계약.  
추가로, 커리큘럼(stage gate) 통과/실패 판정을 자동화할 수 있어야 한다.

---

## Modes
- self-play arena (baseline vs candidate)
- teacher vs student arena (선택)
- Gomocup external tournament (optional; gomoku/renju)

---

## Inputs
- engine binary/config
- opening set
- time control / budget policy(쉬움/평균/어려움 분포 정책)

---

## Outputs
- match log(JSONL)
- Elo estimate + CI
- time distribution report(p50/mean/p95/p99 + bucket별 mean)
- stage gate verdict(pass/fail + reason)

---

## Evaluation Contract (Fairness)
- baseline vs QUARTZ 비교는 `docs/BASELINE_FAIRNESS.md`를 따른다.
- QUARTZ vs baseline의 차이는 `SearchController`만이어야 한다.
- time budget policy(분포 포함)는 동일해야 한다.

---

## Stage Gate (요약)
정의는 `specs/090-curriculum.md`를 따른다. 요약하면:
- 기능: 200게임 자동 대국/파싱이 돌아간다.
- 안정성: crash/timeout/illegal move = 0
- 시간: 분포 목표를 만족(p50/mean/p99 및 bucket별 mean)
- 성능: baseline 대비 Elo가 비열화하지 않거나, 목표 ΔElo를 달성

---

## Acceptance Tests
- 200 game match를 자동으로 돌릴 수 있다.
- 결과 파싱이 실패하지 않는다.
- time distribution 리포트가 생성된다.
