"""
QUARTZ Evaluation System — Final Version
=========================================

Architecture: Three-layer separation of concerns.

  Layer 1 — PromotionGate (2-agent, per checkpoint)
  Layer 2 — SanityCheck (diagnostic, periodic)
  Layer 3 — RatingLadder (Glicko-2, analytical)
  Layer 4 — ScaleCalibrator (affine published Elo)
"""

import math
import time
import logging
import random
import json
import uuid
from typing import Dict, List, Tuple, Any, Optional, Protocol, runtime_checkable
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum

import numpy as np

logger = logging.getLogger(__name__)


# §1 Glicko-2 Core

@dataclass
class RatingParams:
    mu0_elo: float = 1500.0
    rd0_elo: float = 350.0
    sigma0: float = 0.06
    tau: float = 0.5
    scale: float = 173.7178
    anchor_target_elo: float = 0.0

@dataclass
class RatingRecord:
    mu_elo: float; rd_elo: float; sigma: float
    games_played: int = 0; last_period: int = 0
    published_elo: Optional[float] = None
    history: List[float] = field(default_factory=list)
    def init_published(self):
        if self.published_elo is None: self.published_elo = self.mu_elo

class Glicko2:
    @staticmethod
    def to_g2(mu_elo, rd_elo, P): return (mu_elo - P.mu0_elo)/P.scale, rd_elo/P.scale
    @staticmethod
    def to_elo(mu, phi, P): return mu*P.scale + P.mu0_elo, phi*P.scale
    @staticmethod
    def g(phi): return 1.0/math.sqrt(1.0 + 3.0*phi*phi/(math.pi*math.pi))
    @staticmethod
    def E(mu, mu_j, phi_j): return 1.0/(1.0+math.exp(-Glicko2.g(phi_j)*(mu-mu_j)))
    @staticmethod
    def update(mu, phi, sigma, terms, tau):
        s_g2E = sum(g*g*E*(1-E) for g,E,_ in terms)
        s_gsE = sum(g*(s-E) for g,E,s in terms)
        if s_g2E <= 0: return mu, phi, sigma
        v = 1.0/s_g2E; delta = v*s_gsE
        a = math.log(sigma*sigma); eps = 1e-6
        def f(x):
            ex=math.exp(x)
            return (ex*(delta**2-phi**2-v-ex)/(2.0*(phi**2+v+ex)**2))-(x-a)/(tau**2)
        A=a; B=math.log(delta**2-phi**2-v) if delta**2>phi**2+v else a-tau
        if delta**2<=phi**2+v:
            k=1
            while f(B)<0 and k<100: k+=1; B=a-k*tau
        fA,fB = f(A),f(B)
        for _ in range(100):
            if abs(B-A)<=eps: break
            C=A+(A-B)*fA/(fB-fA); fC=f(C)
            if fC*fB<=0: A,fA=B,fB
            else: fA*=0.5
            B,fB=C,fC
        sig2=math.exp(A/2.0); phi_s=math.sqrt(phi**2+sig2**2)
        phi2=1.0/math.sqrt(1.0/phi_s**2+1.0/v)
        mu2=mu+phi2**2*s_gsE
        return mu2, phi2, sig2


# §1.5 GameSpec + Anchor

@dataclass
class GameSpec:
    game_type: str; board_size: int = 0; rules_hash: str = ""
    search_budget_type: str = "simulations"; search_budget: int = 800
    opening_book_hash: str = ""; evaluator_version: str = ""; threads: int = 1
    def spec_hash(self) -> str:
        import hashlib
        return hashlib.sha256(json.dumps(self.__dict__,sort_keys=True).encode()).hexdigest()[:16]

@dataclass
class AnchorEntry:
    id: str; engine_hash: str; target_elo: float; weight: float = 1.0
    role: str = "anchor"; description: str = ""

@dataclass
class AnchorManifest:
    version: str = "v1"; game_spec: Optional[GameSpec] = None
    anchors: List[AnchorEntry] = field(default_factory=list); created: str = ""
    def save(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path,"w") as f:
            json.dump({"version":self.version,"game_spec":self.game_spec.__dict__ if self.game_spec else {},
                       "anchors":[a.__dict__ for a in self.anchors],"created":self.created or time.strftime("%Y-%m-%d")},f,indent=2)
    @classmethod
    def load(cls, path: Path) -> "AnchorManifest":
        with open(path) as f: d=json.load(f)
        gs=GameSpec(**d["game_spec"]) if d.get("game_spec") else None
        return cls(version=d.get("version","v1"),game_spec=gs,
                   anchors=[AnchorEntry(**a) for a in d.get("anchors",[])],created=d.get("created",""))
    @classmethod
    def default_gomoku7(cls):
        return cls(game_spec=GameSpec(game_type="gomoku",board_size=7,search_budget=800),
            anchors=[AnchorEntry(id="A0_random",engine_hash="random_v1",target_elo=0.0,weight=1.0,
                                 description="Uniform random legal moves"),
                     AnchorEntry(id="A1_search_only",engine_hash="uct_uniform_128_v1",target_elo=200.0,
                                 weight=1.0,description="UCT + uniform prior, 128 sims")])


# §1.6 Scale Calibrator

class ScaleCalibrator:
    def __init__(self, manifest: AnchorManifest):
        self.manifest=manifest; self.a=1.0; self.b=0.0; self._history=[]
    def calibrate(self, ladder, min_expected=0.05, max_expected=0.95):
        points=[]
        for anchor in self.manifest.anchors:
            if anchor.id not in ladder.players: continue
            rec=ladder.get(anchor.id)
            if rec.games_played==0: continue
            if rec.rd_elo>ladder.P.rd0_elo*0.95: continue
            points.append((rec.mu_elo, anchor.target_elo, anchor.weight))
        if len(points)<1: self.a,self.b=1.0,0.0
        elif len(points)==1:
            r,t,_=points[0]; self.a=1.0; self.b=t-r
        else:
            W=sum(w for _,_,w in points); Sr=sum(w*r for r,_,w in points)/W
            St=sum(w*t for _,t,w in points)/W; Srr=sum(w*r*r for r,_,w in points)/W
            Srt=sum(w*r*t for r,t,w in points)/W; denom=Srr-Sr*Sr
            if abs(denom)>1e-10:
                self.a=(Srt-Sr*St)/denom; self.b=St-self.a*Sr
                if self.a<=0 or self.a>3.0 or self.a<0.3: self.a=1.0; self.b=St-Sr
            else: self.a=1.0; self.b=St-Sr
        self._history.append((self.a,self.b)); return self.a,self.b
    def published_elo(self, internal_elo): return self.a*internal_elo+self.b
    def residuals(self, ladder):
        return {a.id: round(self.published_elo(ladder.get(a.id).mu_elo)-a.target_elo,1)
                for a in self.manifest.anchors if a.id in ladder.players}


# §2 Rating Ladder

class RatingLadder:
    def __init__(self, P=None):
        self.P=P or RatingParams(); self.players={}; self._period=0; self._bootstrapped=False
        self._ensure("random"); self._ensure("search_only"); self._recenter(); self._bootstrapped=True
    def _ensure(self, name):
        if name not in self.players:
            start=self.P.anchor_target_elo if self._bootstrapped else self.P.mu0_elo
            rec=RatingRecord(mu_elo=start,rd_elo=self.P.rd0_elo,sigma=self.P.sigma0)
            rec.init_published(); self.players[name]=rec
        return self.players[name]
    def _recenter(self):
        rand=self._ensure("random"); off=self.P.anchor_target_elo-rand.mu_elo
        if abs(off)<1e-12: return
        for r in self.players.values():
            r.mu_elo+=off
            if r.published_elo is not None: r.published_elo+=off
    def get(self, name): return self._ensure(name)
    def record_match(self, player, opponent, wins, draws, losses):
        total=wins+draws+losses
        if total<=0: return
        P=self.P; A,B=self.get(player),self.get(opponent)
        muA,phiA=Glicko2.to_g2(A.mu_elo,A.rd_elo,P); muB,phiB=Glicko2.to_g2(B.mu_elo,B.rd_elo,P)
        gB,EB=Glicko2.g(phiB),Glicko2.E(muA,muB,phiB); gA,EA=Glicko2.g(phiA),Glicko2.E(muB,muA,phiA)
        termsA,termsB=[],[]
        for c,s in [(wins,1.0),(draws,0.5),(losses,0.0)]: termsA.extend([(gB,EB,s)]*c)
        for c,s in [(losses,1.0),(draws,0.5),(wins,0.0)]: termsB.extend([(gA,EA,s)]*c)
        mu2,phi2,sig2=Glicko2.update(muA,phiA,A.sigma,termsA,P.tau)
        A.mu_elo,A.rd_elo=Glicko2.to_elo(mu2,phi2,P); A.sigma=sig2; A.games_played+=total
        A.last_period=self._period; A.history.append(A.mu_elo)
        mu2,phi2,sig2=Glicko2.update(muB,phiB,B.sigma,termsB,P.tau)
        B.mu_elo,B.rd_elo=Glicko2.to_elo(mu2,phi2,P); B.sigma=sig2; B.games_played+=total
        B.last_period=self._period; B.history.append(B.mu_elo)
        self._recenter()
    def update_from_period(self, matches):
        P=self.P; pre={}
        for p,o,w,d,l in matches:
            for name in (p,o):
                if name not in pre:
                    rec=self.get(name); mu,phi=Glicko2.to_g2(rec.mu_elo,rec.rd_elo,P)
                    pre[name]=(mu,phi,rec.sigma)
        player_terms={}; player_games={}
        for p,o,w,d,l in matches:
            total=w+d+l
            if total<=0: continue
            mu_p,phi_p,_=pre[p]; mu_o,phi_o,_=pre[o]
            gO=Glicko2.g(phi_o); EO=Glicko2.E(mu_p,mu_o,phi_o)
            for c,s in [(w,1.0),(d,0.5),(l,0.0)]: player_terms.setdefault(p,[]).extend([(gO,EO,s)]*c)
            gP=Glicko2.g(phi_p); EP=Glicko2.E(mu_o,mu_p,phi_p)
            for c,s in [(l,1.0),(d,0.5),(w,0.0)]: player_terms.setdefault(o,[]).extend([(gP,EP,s)]*c)
            player_games[p]=player_games.get(p,0)+total; player_games[o]=player_games.get(o,0)+total
        for name,terms in player_terms.items():
            if not terms: continue
            mu,phi,sigma=pre[name]
            mu2,phi2,sig2=Glicko2.update(mu,phi,sigma,terms,P.tau)
            rec=self.get(name); rec.mu_elo,rec.rd_elo=Glicko2.to_elo(mu2,phi2,P)
            rec.sigma=sig2; rec.games_played+=player_games.get(name,0)
            rec.last_period=self._period; rec.history.append(rec.mu_elo)
        self._recenter()
    def advance_period(self):
        self._period+=1; P=self.P
        for rec in self.players.values():
            _,phi=Glicko2.to_g2(rec.mu_elo,rec.rd_elo,P)
            phi_new=min(math.sqrt(phi**2+rec.sigma**2),P.rd0_elo/P.scale)
            rec.rd_elo=phi_new*P.scale
    @property
    def period(self): return self._period
    def summary(self):
        return {name:{"elo":round(r.mu_elo,1),"rd":round(r.rd_elo,1),"sigma":round(r.sigma,5),"games":r.games_played}
                for name,r in sorted(self.players.items(),key=lambda x:-x[1].mu_elo)}
    def save(self, path):
        data={name:{"mu_elo":r.mu_elo,"rd_elo":r.rd_elo,"sigma":r.sigma,"games_played":r.games_played,
                     "last_period":r.last_period,"history":r.history} for name,r in self.players.items()}
        data["_meta"]={"period":self._period}
        path.parent.mkdir(parents=True,exist_ok=True)
        with open(path,"w") as f: json.dump(data,f,indent=2)
    def load(self, path):
        with open(path) as f: data=json.load(f)
        meta=data.pop("_meta",{}); self._period=meta.get("period",0); self._bootstrapped=True
        for name,d in data.items():
            rec=RatingRecord(mu_elo=d["mu_elo"],rd_elo=d["rd_elo"],sigma=d["sigma"],
                             games_played=d.get("games_played",0),last_period=d.get("last_period",0),
                             history=d.get("history",[])); rec.init_published(); self.players[name]=rec


# §3 Statistical Utilities

def wilson_ci(wins, total, z=1.96):
    if total<=0: return (0.0,0.0)
    p=wins/total; d=1.0+z*z/total; c=p+z*z/(2*total)
    w=z*math.sqrt((p*(1-p)+z*z/(4*total))/total)
    return (max(0.0,(c-w)/d), min(1.0,(c+w)/d))

def score_rate_ci(wins, draws, total, z=1.96):
    if total<=0: return 0.0,(0.0,0.0)
    sr=(wins+0.5*draws)/total; losses=total-wins-draws
    var=(wins*(1-sr)**2+draws*(0.5-sr)**2+losses*(0-sr)**2)/total
    se=math.sqrt(var/total) if var>0 else 0.0
    return sr,(max(0.0,sr-z*se),min(1.0,sr+z*se))

def binomial_p_value(wins, total, p0=0.5):
    if total<30: return 1.0
    var=total*p0*(1-p0)
    if var<=0: return 1.0 if wins==total*p0 else 0.0
    z=abs(wins-total*p0)/math.sqrt(var)
    return min(1.0, 2.0*(1.0-0.5*(1.0+math.erf(z/1.4142135))))

Z_TABLE={0.90:1.645, 0.95:1.960, 0.99:2.576}


# §4 Engine & Game Protocols

@runtime_checkable
class Engine(Protocol):
    def select_move(self, state) -> Tuple[int, Dict[str,Any]]: ...
    def reset(self) -> None: ...
    def name(self) -> str: ...

@runtime_checkable
class GameAdapter(Protocol):
    def clone(self) -> "GameAdapter": ...
    def apply_move(self, action: int) -> None: ...
    def is_terminal(self) -> bool: ...
    def outcome_for_black(self) -> Optional[float]: ...
    def current_player(self) -> int: ...
    def legal_moves(self) -> List[int]: ...

class RandomEngine:
    def __init__(self, seed=None): self._rng=random.Random(seed)
    def select_move(self, state):
        return self._rng.choice(state.legal_moves()),{"time_used_ms":0,"simulations":0}
    def reset(self): pass
    def name(self): return "random"


# §5 Match Protocol

@dataclass
class MoveRecord:
    ply:int; player:int; action:int; time_ms:float; sims:int
    root_entropy: Optional[float]=None

@dataclass
class GameRecord:
    game_id:str; engine_black:str; engine_white:str; outcome:str
    score_black: Optional[float]; move_count:int; total_time_ms:float
    moves: List[MoveRecord]=field(default_factory=list)
    opening: List[int]=field(default_factory=list)
    seed: Optional[int]=None; error: Optional[str]=None; is_void:bool=False
    def to_jsonl(self):
        d={"game_id":self.game_id,"outcome":self.outcome,"score_black":self.score_black,
           "engines":[self.engine_black,self.engine_white],"moves":len(self.moves),
           "time_ms":round(self.total_time_ms,1),"is_void":self.is_void}
        if self.error: d["error"]=self.error
        return json.dumps(d,ensure_ascii=False)

class MatchRunner:
    def __init__(self, game_factory, opening_book=None, seed=None, max_moves=500):
        self.game_factory=game_factory; self.opening_book=opening_book or []
        self.rng=random.Random(seed); self.max_moves=max_moves
    def play_game(self, eng_black, eng_white, game_id, opening_idx=None):
        game=self.game_factory(); eng_black.reset(); eng_white.reset()
        engines={0:eng_black,1:eng_white}; moves=[]; opening_applied=[]
        game_seed=self.rng.randint(0,2**31)
        if opening_idx is not None and opening_idx<len(self.opening_book):
            for a in self.opening_book[opening_idx]:
                if game.is_terminal() or a not in game.legal_moves(): break
                game.apply_move(a); opening_applied.append(a)
        t0=time.time(); ply=len(opening_applied)
        try:
            while not game.is_terminal() and ply<self.max_moves:
                p=game.current_player(); action,meta=engines[p].select_move(game)
                moves.append(MoveRecord(ply=ply,player=p,action=action,
                    time_ms=meta.get("time_used_ms",0),sims=meta.get("simulations",0),
                    root_entropy=meta.get("root_entropy")))
                game.apply_move(action); ply+=1
            elapsed=(time.time()-t0)*1000
            if game.is_terminal():
                r=game.outcome_for_black()
                if r is None or r==0: outcome,sb="draw",0.5
                elif r>0: outcome,sb="black_win",1.0
                else: outcome,sb="white_win",0.0
            else: outcome,sb="draw",0.5
            return GameRecord(game_id=game_id,engine_black=eng_black.name(),engine_white=eng_white.name(),
                outcome=outcome,score_black=sb,move_count=ply,total_time_ms=elapsed,
                moves=moves,opening=opening_applied,seed=game_seed)
        except Exception as e:
            return GameRecord(game_id=game_id,engine_black=eng_black.name(),engine_white=eng_white.name(),
                outcome="void",score_black=None,move_count=ply,total_time_ms=(time.time()-t0)*1000,
                moves=moves,opening=opening_applied,seed=game_seed,error=str(e),is_void=True)
    def play_match(self, eng_a, eng_b, num_games, color_swap=True):
        records=[]; ob_n=len(self.opening_book) if self.opening_book else 0; idx=0
        pairs=num_games//2 if color_swap else 0
        for i in range(pairs):
            oi=i%ob_n if ob_n else None
            records.append(self.play_game(eng_a,eng_b,f"g{idx:04d}",oi)); idx+=1
            records.append(self.play_game(eng_b,eng_a,f"g{idx:04d}",oi)); idx+=1
        for _ in range(num_games-2*pairs):
            oi=idx%ob_n if ob_n else None
            records.append(self.play_game(eng_a,eng_b,f"g{idx:04d}",oi)); idx+=1
        return records


# §6 Match Tallying

@dataclass
class MatchTally:
    engine_name:str; opponent_name:str; wins:int=0; draws:int=0; losses:int=0; errors:int=0; total:int=0
    @property
    def scored(self): return self.wins+self.draws+self.losses
    @property
    def score_rate(self):
        n=self.scored; return (self.wins+0.5*self.draws)/n if n>0 else 0.0
    @property
    def win_rate(self):
        n=self.scored; return self.wins/n if n>0 else 0.0

def tally_match(records, engine_name):
    t=MatchTally(engine_name=engine_name,opponent_name="")
    for r in records:
        t.total+=1
        if r.is_void: t.errors+=1; continue
        is_black=r.engine_black==engine_name
        if not t.opponent_name: t.opponent_name=r.engine_white if is_black else r.engine_black
        if r.outcome=="draw": t.draws+=1
        elif r.outcome=="black_win":
            if is_black: t.wins+=1
            else: t.losses+=1
        elif r.outcome=="white_win":
            if is_black: t.losses+=1
            else: t.wins+=1
    return t


# §7 Layer 1 — Promotion Gate

class PromotionVerdict(Enum):
    PROMOTE="promote"; REJECT="reject"; NEED_MORE="need_more"

@dataclass
class PromotionResult:
    verdict:PromotionVerdict; score_rate:float; score_rate_ci:Tuple[float,float]
    wilson_lower:float; p_value:float; is_significant:bool; games_scored:int; reason:str
    def to_dict(self):
        return {"verdict":self.verdict.value,"score_rate":round(self.score_rate,4),
                "score_rate_ci":tuple(round(x,4) for x in self.score_rate_ci),
                "wilson_lower":round(self.wilson_lower,4),"p_value":round(self.p_value,6),
                "is_significant":self.is_significant,"games_scored":self.games_scored,"reason":self.reason}

@dataclass
class PromotionConfig:
    threshold:float=0.55; min_games:int=200; confidence:float=0.95; require_significance:bool=True

class PromotionGate:
    def __init__(self, config=None): self.cfg=config or PromotionConfig()
    def evaluate(self, tally):
        n=tally.scored; z=Z_TABLE.get(self.cfg.confidence,1.96)
        sr,sr_ci=score_rate_ci(tally.wins,tally.draws,n,z)
        wl=wilson_ci(tally.wins,n,z)[0]; pv=binomial_p_value(tally.wins,n,0.5)
        sig=n>=self.cfg.min_games and pv<(1-self.cfg.confidence)
        if n<self.cfg.min_games: verdict=PromotionVerdict.NEED_MORE; reason=f"Only {n}/{self.cfg.min_games} scored games"
        elif sr>=self.cfg.threshold:
            if self.cfg.require_significance and not sig: verdict=PromotionVerdict.NEED_MORE; reason=f"sr={sr:.3f}≥{self.cfg.threshold} but p={pv:.4f} not sig"
            else: verdict=PromotionVerdict.PROMOTE; reason=f"sr={sr:.3f}≥{self.cfg.threshold}"
        else: verdict=PromotionVerdict.REJECT; reason=f"sr={sr:.3f}<{self.cfg.threshold}"
        return PromotionResult(verdict=verdict,score_rate=sr,score_rate_ci=sr_ci,wilson_lower=wl,
                               p_value=pv,is_significant=sig,games_scored=n,reason=reason)


# §8 Layer 2 — Sanity Check

@dataclass
class SanityResult:
    passed:bool; win_rate:float; games_played:int; reason:str
    def to_dict(self): return {"passed":self.passed,"win_rate":round(self.win_rate,3),"games":self.games_played,"reason":self.reason}

class SanityCheck:
    def __init__(self, min_score_rate=0.90, num_games=20):
        self.min_sr=min_score_rate; self.num_games=num_games
    def check(self, candidate, game_factory, seed=None):
        rand_eng=RandomEngine(seed=seed)
        runner=MatchRunner(game_factory,seed=seed,max_moves=300)
        records=runner.play_match(candidate,rand_eng,self.num_games,color_swap=True)
        tally=tally_match(records,candidate.name()); sr=tally.score_rate
        ok=sr>=self.min_sr
        reason=f"sr vs random={sr:.3f} {'≥' if ok else '<'} {self.min_sr}"
        return SanityResult(passed=ok,win_rate=sr,games_played=tally.scored,reason=reason)


# §9 Champion Tracker

@dataclass
class ChampionState:
    model_id:str; generation:int=0; elo:Optional[float]=None
    promotion_history:List[Dict[str,Any]]=field(default_factory=list)

class ChampionTracker:
    def __init__(self, initial_id="gen_0", save_path=None, bridge_size=3):
        self.champion=ChampionState(model_id=initial_id,generation=0)
        self.save_path=save_path; self.bridge_size=bridge_size; self.bridge=[]
    def try_promote(self, candidate_id, generation, result):
        if result.verdict!=PromotionVerdict.PROMOTE: return False
        old_id=self.champion.model_id
        if old_id not in self.bridge: self.bridge.append(old_id)
        while len(self.bridge)>self.bridge_size: self.bridge.pop(0)
        entry={"from":old_id,"to":candidate_id,"generation":generation,
               "score_rate":result.score_rate,"games":result.games_scored,
               "timestamp":time.strftime("%Y-%m-%d %H:%M:%S")}
        self.champion=ChampionState(model_id=candidate_id,generation=generation,
            promotion_history=self.champion.promotion_history+[entry])
        if self.save_path: self._save()
        return True
    def get_bridge_ids(self): return list(self.bridge)
    def _save(self):
        self.save_path.parent.mkdir(parents=True,exist_ok=True)
        with open(self.save_path,"w") as f:
            json.dump({"champion":self.champion.model_id,"generation":self.champion.generation,
                       "history":self.champion.promotion_history,"bridge":self.bridge},f,indent=2)


# §10 JSONL Logger

class MatchLogger:
    def __init__(self, path): self.path=path; self._f=None
    def __enter__(self): self.path.parent.mkdir(parents=True,exist_ok=True); self._f=open(self.path,"a"); return self
    def __exit__(self,*a):
        if self._f: self._f.close()
    def log(self, rec): self._f.write(rec.to_jsonl()+"\n"); self._f.flush()


# §11 Training Evaluator

@dataclass
class EvalConfig:
    num_games:int=200; promotion_threshold:float=0.55; confidence:float=0.95
    sanity_check_interval:int=5; sanity_min_score:float=0.90; sanity_games:int=20
    anchor_match_games:int=20; bridge_match_interval:int=10; bridge_size:int=3
    color_swap:bool=True; max_moves:int=500; seed:Optional[int]=None
    log_path:Optional[str]=None; ladder_path:Optional[str]=None; champion_path:Optional[str]=None

@dataclass
class EvalResult:
    eval_id:str; timestamp:str; candidate:str; champion:str
    promotion:Dict[str,Any]=field(default_factory=dict)
    tally:Optional[Dict[str,Any]]=None; sanity:Optional[Dict[str,Any]]=None
    elo:Optional[Dict[str,Any]]=None; published:Optional[Dict[str,Any]]=None
    duration_s:float=0.0; conditions:Dict[str,Any]=field(default_factory=dict)
    def to_dict(self): return {k:v for k,v in self.__dict__.items() if v is not None}

class TrainingEvaluator:
    def __init__(self, config=None, manifest=None):
        self.cfg=config or EvalConfig()
        self.gate=PromotionGate(PromotionConfig(threshold=self.cfg.promotion_threshold,
            min_games=self.cfg.num_games,confidence=self.cfg.confidence))
        self.sanity=SanityCheck(min_score_rate=self.cfg.sanity_min_score,num_games=self.cfg.sanity_games)
        self.ladder=RatingLadder()
        if self.cfg.ladder_path and Path(self.cfg.ladder_path).exists():
            self.ladder.load(Path(self.cfg.ladder_path))
        self.manifest=manifest or AnchorManifest.default_gomoku7()
        self.calibrator=ScaleCalibrator(self.manifest)
        self.champion=ChampionTracker(save_path=Path(self.cfg.champion_path) if self.cfg.champion_path else None,
                                       bridge_size=self.cfg.bridge_size)
        self._eval_count=0

    def evaluate_checkpoint(self, candidate, champion, game_factory,
                            candidate_id="", generation=0, opening_book=None):
        t0=time.time(); cfg=self.cfg; self._eval_count+=1
        runner=MatchRunner(game_factory,opening_book,cfg.seed,cfg.max_moves)
        records=runner.play_match(candidate,champion,cfg.num_games,cfg.color_swap)
        tally=tally_match(records,candidate.name())
        promo=self.gate.evaluate(tally)
        result=EvalResult(eval_id=str(uuid.uuid4()),timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            candidate=candidate_id or candidate.name(),champion=self.champion.champion.model_id,
            conditions={"num_games":cfg.num_games,"color_swap":cfg.color_swap,"seed":cfg.seed,"generation":generation})
        result.tally={"wins":tally.wins,"draws":tally.draws,"losses":tally.losses,
                      "scored":tally.scored,"score_rate":round(tally.score_rate,4)}
        result.promotion=promo.to_dict()
        if promo.verdict==PromotionVerdict.PROMOTE:
            self.champion.try_promote(candidate_id,generation,promo)
        # Sanity check
        if self._eval_count%cfg.sanity_check_interval==0:
            sr=self.sanity.check(candidate,game_factory,cfg.seed)
            result.sanity=sr.to_dict()
        # Ladder update
        self.ladder.advance_period()
        self.ladder.record_match(candidate.name(),champion.name(),tally.wins,tally.draws,tally.losses)
        cand_rec=self.ladder.get(candidate.name()); champ_rec=self.ladder.get(champion.name())
        a,b=self.calibrator.calibrate(self.ladder)
        result.elo={"candidate":round(cand_rec.mu_elo,1),"champion":round(champ_rec.mu_elo,1),
                     "delta":round(cand_rec.mu_elo-champ_rec.mu_elo,1)}
        result.published={"candidate_abs":round(self.calibrator.published_elo(cand_rec.mu_elo),1),
                          "champion_abs":round(self.calibrator.published_elo(champ_rec.mu_elo),1),
                          "scale_a":round(a,4),"offset_b":round(b,1)}
        if cfg.ladder_path: self.ladder.save(Path(cfg.ladder_path))
        if cfg.log_path:
            with MatchLogger(Path(cfg.log_path)) as ml:
                for r in records: ml.log(r)
        result.duration_s=time.time()-t0
        return result


# §12 Self-Tests

def _run_all():
    # Glicko-2
    terms=[]
    for mu_j,phi_j,s_j in [(-0.5756,0.1727,1.0),(0.2878,0.5756,0.0),(1.1513,1.7269,0.0)]:
        terms.append((Glicko2.g(phi_j),Glicko2.E(0.0,mu_j,phi_j),s_j))
    mu2,phi2,sig2=Glicko2.update(0.0,1.1513,0.06,terms,0.5)
    assert abs(Glicko2.g(1.7269)-0.7242)<0.002; assert abs(mu2-(-0.2069))<0.02
    assert abs(phi2-0.8722)<0.02; assert abs(sig2-0.05999)<0.001
    print("[PASS] Glicko-2 math")
    # Promotion
    gate=PromotionGate(PromotionConfig(threshold=0.55,min_games=10,require_significance=False))
    t=MatchTally("c","b",wins=7,draws=2,losses=1); r=gate.evaluate(t)
    assert r.verdict==PromotionVerdict.PROMOTE
    t2=MatchTally("c","b",wins=4,draws=2,losses=4); r2=gate.evaluate(t2)
    assert r2.verdict==PromotionVerdict.REJECT
    print("[PASS] Promotion gate")
    # Champion tracker
    ct=ChampionTracker(initial_id="gen_0",bridge_size=2)
    promote=PromotionResult(PromotionVerdict.PROMOTE,0.65,(0.55,0.75),0.55,0.01,True,200,"ok")
    ct.try_promote("gen_5",5,promote); assert ct.champion.model_id=="gen_5"
    ct.try_promote("gen_10",10,promote); assert ct.bridge==["gen_0","gen_5"]
    ct.try_promote("gen_15",15,promote); assert ct.bridge==["gen_5","gen_10"]
    print("[PASS] Champion tracker + bridge")
    # Wilson CI
    sr,ci=score_rate_ci(40,20,100); assert abs(sr-0.50)<0.001
    print("[PASS] Score rate CI")
    # RD inflation
    ladder=RatingLadder(); ladder.record_match("m","random",10,0,0)
    rd0=ladder.get("m").rd_elo; ladder.advance_period()
    assert ladder.get("m").rd_elo>rd0
    print("[PASS] RD inflation")
    # Batch vs sequential
    ls=RatingLadder(); ls.record_match("A","B",8,1,1); ls.record_match("A","C",1,1,8)
    lb=RatingLadder(); lb.update_from_period([("A","B",8,1,1),("A","C",1,1,8)])
    assert abs(ls.get("A").mu_elo-lb.get("A").mu_elo)>0.5
    print("[PASS] Batch vs sequential")
    # Scale calibrator
    mf=AnchorManifest(anchors=[AnchorEntry(id="A0",engine_hash="r",target_elo=0.0),
                                AnchorEntry(id="A1",engine_hash="u",target_elo=400.0)])
    ld=RatingLadder(); ld.record_match("A0","A1",2,1,7)
    cal=ScaleCalibrator(mf); a,b=cal.calibrate(ld)
    assert abs(cal.published_elo(ld.get("A0").mu_elo))<50
    assert abs(cal.published_elo(ld.get("A1").mu_elo)-400)<50
    print(f"[PASS] Scale calibrator (a={a:.3f}, b={b:.1f})")
    print(f"\n[ALL PASS] 7 tests passed.")

if __name__=="__main__":
    import sys,argparse
    parser=argparse.ArgumentParser(); parser.add_argument("--self-test",action="store_true")
    args=parser.parse_args()
    if args.self_test: _run_all(); sys.exit(0)
    print("Use TrainingEvaluator programmatically. --self-test for verification.")
