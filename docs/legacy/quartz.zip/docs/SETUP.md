# Setup Guide

## Rust
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
rustup default 1.82.0  # for ONNX support; 1.75+ works without ONNX
cargo build --release
cargo test --release
```

## Python
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install torch numpy tqdm

# AMD GPU (ROCm 6.3):
pip install torch --index-url https://download.pytorch.org/whl/rocm6.2
export HSA_OVERRIDE_GFX_VERSION=10.3.0

# JAX (Docker recommended):
docker run -it --device=/dev/kfd --device=/dev/dri --group-add video \
  --ipc=host --shm-size 16G -e HSA_OVERRIDE_GFX_VERSION=10.3.0 \
  -v $(pwd):/workspace rocm/jax-community:latest
```

## Docker
```bash
docker compose -f docker/docker-compose.yml run pytorch
```

## Verify
```bash
python3 -c "import torch; print(torch.cuda.is_available())"
python3 python/alphazero_train.py --game gomoku7 --iterations 2 --device cpu
```
