# References (External)

이 파일은 “외부에서 확인 가능한 사실”의 근거 링크를 모아둔다.  
(프로젝트 문서 안에서는 가능한 한 여기로 모으고, 중복을 줄인다.)

## Python free-threading / no-GIL
- Official docs: https://docs.python.org/3/howto/free-threading-python.html
- Extension guidance: https://docs.python.org/3/howto/free-threading-extensions.html
- Community hub: https://py-free-threading.github.io/

## Gomocup / Gomocup Manager
- Gomocup 공식: https://gomocup.org/
- Gomocup Manager 다운로드(페이지에 Piskvork 등 언급): https://gomocup.org/download-gomocup-manager/

## Gomoku / Renju 기본 정보
- Wikipedia(Gomoku): https://en.wikipedia.org/wiki/Gomoku
- Wikipedia(Renju): https://en.wikipedia.org/wiki/Renju

## AlphaZero 계열(기본 구조 레퍼런스)
- AlphaGo Zero (Nature 2017): https://www.nature.com/articles/nature24270
- Leela Zero (오픈 구현): https://github.com/leela-zero/leela-zero
- Leela Chess Zero (Lc0): https://github.com/LeelaChessZero/lc0
- KataGo: https://github.com/lightvector/KataGo

## 네트워크 모듈(참고)
- Squeeze-and-Excitation Networks (SE): https://arxiv.org/abs/1709.01507

## JAX / MCTS(완전 GPU teacher 경로 참고)
- mctx (MCTS in JAX): https://github.com/deepmind/mctx
- PGX (JAX boardgame envs): https://github.com/sotetsuk/pgx
