import numpy as np
from scipy.stats import uniform
from scipy.stats import gaussian_kde
from sklearn.decomposition import PCA
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp
import os
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque
import gym
from gym import spaces
import pandas as pd
from torch.utils.data import DataLoader, Dataset
import cProfile
import pstats
import emcee
import pickle
import h5py

# Define device for PyTorch
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load precomputed log-likelihood grid data
def load_log_likelihood_grid(filename):
    with h5py.File(filename, 'r') as file:
        log_likelihood_grid = file['log_likelihood_grid'][:]
        coords = [file[f'coord_{i}'][:] for i in range(len(file.keys()) - 1)]
    return log_likelihood_grid, coords

log_likelihood_grid, coord_grids = load_log_likelihood_grid('log_likelihood_grid.h5')
log_likelihood_grid = torch.tensor(log_likelihood_grid, dtype=torch.float32).to(device)
coord_grids = [torch.tensor(coord, dtype=torch.float32).to(device) for coord in coord_grids]

def multilinear_interpolate(im, coords):
    """
    Perform multilinear interpolation for an n-dimensional image.

    Parameters:
    im (torch.Tensor): n-dimensional tensor of shape (D1, D2, ..., Dn).
    coords (list of torch.Tensor): List of n 1-dimensional coordinate tensors.

    Returns:
    torch.Tensor: Interpolated values at the given coordinates.
    """
    num_dims = len(coords)
    shape = im.shape
    coords = [coord.to(im.device) for coord in coords]
    
    # Initialize the interpolation result with the input image
    result = im

    # Iterate over each dimension
    for dim in range(num_dims):
        # Compute indices for linear interpolation
        floor_idx = torch.floor(coords[dim]).long()
        ceil_idx = floor_idx + 1
        
        # Ensure indices are within bounds
        floor_idx = torch.clamp(floor_idx, 0, shape[dim] - 1)
        ceil_idx = torch.clamp(ceil_idx, 0, shape[dim] - 1)
        
        # Compute the weights
        floor_weight = (ceil_idx.float() - coords[dim])
        ceil_weight = (coords[dim] - floor_idx.float())
        
        # Expand dimensions for broadcasting
        for _ in range(num_dims - dim - 1):
            floor_weight = floor_weight.unsqueeze(-1)
            ceil_weight = ceil_weight.unsqueeze(-1)
        
        # Interpolate along the current dimension
        result = (floor_weight * torch.index_select(result, dim, floor_idx) +
                  ceil_weight * torch.index_select(result, dim, ceil_idx))
    
    return result

# Use multilinear interpolation
def interpolate_log_likelihood(*coords):
    normalized_coords = []
    for i, coord in enumerate(coords):
        coord_min = coord_grids[i].min()
        coord_max = coord_grids[i].max()
        normalized_coord = (coord - coord_min) / (coord_max - coord_min) * (coord_grids[i].shape[0] - 1)
        normalized_coords.append(normalized_coord)
    
    interpolated = multilinear_interpolate(log_likelihood_grid, normalized_coords)
    
    return interpolated.cpu().numpy()

def compute_log_likelihood_vectorized(*chunks):
    # Convert inputs to numpy arrays of floats and ensure valid values
    chunks = [np.asarray(chunk, dtype=np.float32).flatten() for chunk in chunks]
    if not all(np.issubdtype(chunk.dtype, np.number) for chunk in chunks):
        raise ValueError("Non-numerical value found in chunks")

    # Convert to torch tensors and move to the appropriate device
    coords_tensors = [torch.tensor(chunk, dtype=torch.float32).to(device) for chunk in chunks]

    # Compute log likelihood using the interpolate_log_likelihood function
    log_likelihood = interpolate_log_likelihood(*coords_tensors)
    
    # Prepare the results in a structured array
    results = np.empty(len(chunks[0]), dtype=[('coords', np.float32, len(chunks)), ('log_likelihood', np.float32)])
    results['coords'] = np.stack(chunks, axis=-1)
    results['log_likelihood'] = log_likelihood
    
    return results

def log_likelihood_function(point):
    point = np.asarray(point).flatten()  # Ensure point is a 1-dimensional array
    if not np.issubdtype(point.dtype, np.number):
        raise ValueError("Non-numerical value found")
    
    # Ensure point has the same number of elements as the dimensions in coord_grids
    if point.shape[0] != len(coord_grids):
        raise ValueError(f"Input does not have {len(coord_grids)} elements")

    # Split the point into individual coordinates
    coords_chunks = [np.array([coord]) for coord in point]

    # Compute the log likelihood for the given point
    results = compute_log_likelihood_vectorized(*coords_chunks)
    log_likelihoods = results['log_likelihood']
    
    log_likelihood_value = log_likelihoods[0]
    
    if np.isnan(log_likelihood_value) or np.isinf(log_likelihood_value):
        return -np.inf  # Return a very low likelihood value if NaN or Inf
    
    return log_likelihood_value  # Return a scalar value

def vectorized_log_likelihood(inputs):
    inputs = np.asarray(inputs)
    
    # Ensure inputs have the correct number of dimensions
    if inputs.shape[1] != len(coord_grids):
        raise ValueError(f"Each input must have {len(coord_grids)} elements")
    
    # Split the inputs into individual coordinate arrays
    coords_chunks = [inputs[:, i] for i in range(inputs.shape[1])]
    
    # Compute the log likelihood for the given inputs
    results = compute_log_likelihood_vectorized(*coords_chunks)
    
    return results['log_likelihood']

# Parallel log-likelihood computation using ProcessPoolExecutor
def parallel_log_likelihood(params_list):
    params_array = np.array(params_list)
    with ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
        results = list(executor.map(log_likelihood_function, params_array))
    return np.array(results).flatten()  # Ensure the results are flattened to 1D

def sample_from_dist(dist, nums):
    return dist.rvs(nums)

def sample_function(args):
    dist, nums = args
    return sample_from_dist(dist, nums)

def sample_from_product_dist(product_dist, nums):
    with mp.Pool(os.cpu_count()) as pool:
        samples = pool.map(sample_function, [(d, nums) for d in product_dist])
    return np.array(samples).T

# Generate mixed sampling points
def mixed_sampling(num_live_points, iniloc, iniscale, region):
    gaussian_samples = np.random.normal(loc=iniloc, scale=iniscale, size=(num_live_points // 2, len(iniloc)))
    lower_bounds = [r[0] for r in region]
    upper_bounds = [r[1] for r in region]
    uniform_samples = np.random.uniform(low=lower_bounds, high=upper_bounds, size=(num_live_points - num_live_points // 2, len(iniloc)))
    ini_live_points = np.vstack((gaussian_samples, uniform_samples))
    np.random.shuffle(ini_live_points)
    return ini_live_points

# Run MCMC using emcee
def emcee_sample(log_prob_fn, init_positions, n_steps, n_walkers=None):
    ndim = init_positions.shape[1]
    if n_walkers is None:
        n_walkers = 2 * ndim  # Typically you want 2 * ndim walkers

    # Initialize the sampler
    sampler = emcee.EnsembleSampler(n_walkers, ndim, log_prob_fn)

    # Run MCMC with parallelization
    with mp.Pool(mp.cpu_count()) as pool:
        sampler.pool = pool
        sampler.run_mcmc(init_positions, n_steps, progress=True)

    return sampler.chain, sampler.lnprobability

# Patch the ptemcee library to fix the np.float deprecation
def patch_ptemcee():
    import ptemcee.sampler
    ptemcee.sampler.np.float = np.float64

patch_ptemcee()

# Run Parallel Tempering using ptemcee
def pt_sample(log_prob_fn, init_positions, n_steps, n_temps=10):
    from ptemcee.sampler import Sampler

    ndim = init_positions.shape[1]
    n_walkers = 2 * ndim
    betas = np.logspace(0, -1, n_temps)

    sampler = Sampler(n_walkers, ndim, log_prob_fn, log_prob_fn, ntemps=n_temps, betas=betas)

    # Initialize walker positions
    p0 = np.zeros((n_temps, n_walkers, ndim))
    for i in range(n_temps):
        p0[i, :, :] = init_positions + 1e-4 * np.random.randn(n_walkers, ndim)

    # Run the sampler
    sampler.run_mcmc(p0, n_steps)

    # Return the flattened chain
    return sampler.chain[:, -1, :, :].reshape(-1, ndim)

def sample_and_evaluate(like, points, nums, product_dist, method, n_walkers, Li):
    if method == "emcee":
        positions = emcee_sample(like, points[:n_walkers, :], nums)[0][:, -1, :]
    elif method == "pt":
        positions = pt_sample(like, points[:n_walkers, :], nums)
    else:
        raise ValueError("Unknown sampling method")

    init_positions = np.vstack((positions, sample_from_product_dist(product_dist, nums)))
    sample_points = init_positions
    
    like_vals = parallel_log_likelihood([tuple(p) for p in sample_points])
    
    if like_vals.shape[0] != sample_points.shape[0]:
        raise ValueError("Mismatch in number of likelihood values and sample points")

    new_points = sample_points[like_vals > Li]
    new_lis = parallel_log_likelihood([tuple(p) for p in new_points])
    
    return new_points, new_lis

def update_point(like, points, region, nums, lives, Li):

    like_vals = parallel_log_likelihood([tuple(l) for l in lives])
    live_min_index = np.argmin(like_vals)
    new_lives = np.delete(lives, live_min_index, axis=0)

    product_dist = [uniform(loc=low, scale=high-low) for low, high in region]

    n_walkers = 2 * points.shape[1]
    pt_points, pt_lis = sample_and_evaluate(like, points, nums, product_dist, "pt", n_walkers, Li)
    emcee_points, emcee_lis = sample_and_evaluate(like, points, nums, product_dist, "emcee", n_walkers, Li)

    combined_points = np.vstack((emcee_points, pt_points))
    combined_lis = np.hstack((emcee_lis, pt_lis))

    iniloc_new = np.mean(combined_points, axis=0)
    iniscale_new = np.std(combined_points, axis=0)

    if len(combined_lis) == 0:
        return new_lives, iniloc_new, iniscale_new

    min_like_index = np.argmin(combined_lis)
    replaced_point = combined_points[min_like_index]
    new_lives = np.insert(new_lives, live_min_index, replaced_point, axis=0)

    return new_lives, iniloc_new, iniscale_new

# Weighted resampling of points based on normalized weights
def weighted_resampling(sample_points, weights):
    normalized_weights = weights / np.sum(weights)
    cumulative_weights = np.cumsum(normalized_weights)
    
    num_samples = len(sample_points)
    random_thresholds = np.random.rand(num_samples)
    chosen_indices = np.searchsorted(cumulative_weights, random_thresholds)
    
    return [sample_points[index] for index in chosen_indices]

# Replay buffer dataset for DataLoader
class ReplayBufferDataset(Dataset):
    def __init__(self, buffer):
        self.buffer = buffer

    def __len__(self):
        return len(self.buffer)

    def __getitem__(self, idx):
        return self.buffer[idx]

# Nested Sampling environment for reinforcement learning
class NestedSamplingEnv(gym.Env):
    def __init__(self, coord_ranges):
        super(NestedSamplingEnv, self).__init__()
        self.num_params = len(coord_ranges)
        self.coord_ranges = coord_ranges
        self.action_space = spaces.Box(low=-1, high=1, shape=(self.num_params,), dtype=np.float32)
        self.observation_space = spaces.Box(
            low=np.array([r[0] for r in coord_ranges], dtype=np.float32), 
            high=np.array([r[1] for r in coord_ranges], dtype=np.float32), 
            dtype=np.float32
        )
        self.state = np.random.uniform(low=self.observation_space.low, high=self.observation_space.high, size=(self.num_params,))
        self.previous_state = self.state
        self.previous_likelihood = None
        self.best_likelihood = -np.inf
        self.visit_count = {}
        self.sample_history = []

    def reset(self):
        self.state = np.random.uniform(low=self.observation_space.low, high=self.observation_space.high, size=(self.num_params,))
        self.previous_state = self.state
        self.previous_likelihood = None
        self.best_likelihood = -np.inf
        self.visit_count = {}
        self.sample_history = []
        return self.state

    def step(self, action):
        action = np.clip(action, self.action_space.low, self.action_space.high)
        self.state = self.state + action
        self.state = np.clip(self.state, self.observation_space.low, self.observation_space.high)

        current_likelihood = vectorized_log_likelihood(np.array([self.state]))[0]

        if self.previous_likelihood is None:
            self.previous_likelihood = current_likelihood

        # Log-likelihood improvement reward
        log_likelihood_reward = current_likelihood - self.previous_likelihood

        # Exploration reward
        state_tuple = tuple(self.state)
        if state_tuple in self.visit_count:
            self.visit_count[state_tuple] += 1
        else:
            self.visit_count[state_tuple] = 1
        exploration_reward = 1 / (1 + self.visit_count[state_tuple])

        # Diversity reward
        diversity_reward = np.min([np.linalg.norm(self.state - past_state) for past_state in self.sample_history]) if self.sample_history else 0

        # Expected improvement reward
        expected_improvement_reward = max(0, current_likelihood - self.best_likelihood)

        # Combine rewards
        reward = (0.4 * log_likelihood_reward + 
                  0.2 * exploration_reward + 
                  0.2 * diversity_reward + 
                  0.2 * expected_improvement_reward)

        # Update best likelihood
        self.best_likelihood = max(self.best_likelihood, current_likelihood)

        # Update history
        self.previous_likelihood = current_likelihood
        self.previous_state = self.state
        self.sample_history.append(self.state)

        done = False
        info = {}

        return self.state, reward, done, info

# Actor model for PPO
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, max_action):
        super(Actor, self).__init__()
        self.l1 = nn.Linear(state_dim, 256)
        self.l2 = nn.Linear(256, 256)
        self.l3 = nn.Linear(256, action_dim)
        self.max_action = max_action

    def forward(self, state):
        a = torch.relu(self.l1(state))
        a = torch.relu(self.l2(a))
        return self.max_action * torch.tanh(self.l3(a))

# Critic model for PPO
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        self.l1 = nn.Linear(state_dim + action_dim, 256)
        self.l2 = nn.Linear(256, 256)
        self.l3 = nn.Linear(256, 1)
        self.l4 = nn.Linear(state_dim + action_dim, 256)
        self.l5 = nn.Linear(256, 256)
        self.l6 = nn.Linear(256, 1)

    def forward(self, state, action):
        sa = torch.cat([state, action], 1)
        q1 = torch.relu(self.l1(sa))
        q1 = torch.relu(self.l2(q1))
        q1 = self.l3(q1)
        q2 = torch.relu(self.l4(sa))
        q2 = torch.relu(self.l5(q2))
        q2 = self.l6(q2)
        return q1, q2

    def Q1(self, state, action):
        sa = torch.cat([state, action], 1)
        q1 = torch.relu(self.l1(sa))
        q1 = torch.relu(self.l2(q1))
        q1 = self.l3(q1)
        return q1

# PPO Agent
class PPO:
    def __init__(self, state_dim, action_dim, max_action):
        self.actor = Actor(state_dim, action_dim, max_action).to(device)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=3e-4)

        self.critic = Critic(state_dim, action_dim).to(device)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=3e-4)

        self.max_action = max_action
        self.replay_buffer = deque(maxlen=1000000)

    def select_action(self, state):
        state = torch.FloatTensor(state.reshape(1, -1)).to(device)
        return self.actor(state).cpu().data.numpy().flatten()

    def train(self, batch_size=256, discount=0.99, tau=0.005):
        if len(self.replay_buffer) < batch_size:
            return

        replay_buffer_dataset = ReplayBufferDataset(self.replay_buffer)
        dataloader = DataLoader(replay_buffer_dataset, batch_size=batch_size, shuffle=True)

        for batch in dataloader:
            state, next_state, action, reward, not_done = batch
            state = torch.FloatTensor(state).to(device)
            next_state = torch.FloatTensor(next_state).to(device)
            action = torch.FloatTensor(action).to(device)
            reward = torch.FloatTensor(reward).to(device)
            not_done = torch.FloatTensor(not_done).to(device)

            current_Q1, current_Q2 = self.critic(state, action)
            target_Q = reward + not_done * discount * self.critic.Q1(next_state, self.actor(next_state)).detach()
            critic_loss = F.mse_loss(current_Q1, target_Q) + F.mse_loss(current_Q2, target_Q)

            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            self.critic_optimizer.step()

            actor_loss = -self.critic.Q1(state, self.actor(state)).mean()
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()

    def add_to_replay_buffer(self, state, next_state, action, reward, done):
        self.replay_buffer.append((state, next_state, action, reward, done))

# Function to compute KDE with PCA if needed
def compute_kde_with_pca(points_sample_np):
    if points_sample_np.shape[0] > 1:
        try:
            # Attempt to compute KDE directly
            kde = gaussian_kde(points_sample_np.T)
            priors = kde(points_sample_np.T)
        except np.linalg.LinAlgError:
            # If there's a LinAlgError, perform PCA and then compute KDE
            pca = PCA(n_components=min(points_sample_np.shape[0], points_sample_np.shape[1]))
            transformed_points = pca.fit_transform(points_sample_np)
            kde = gaussian_kde(transformed_points.T)
            priors = kde(transformed_points.T)
    else:
        # Assign a uniform prior for a single sample to avoid errors
        priors = np.ones(points_sample_np.shape[0])
    
    return priors

# Clear terminal function
def clear_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')
    
def save_checkpoint(filename, iteration, evidence, Xprev, points_sample, weights_sample, evidence_list, convergence_list, Z):
    with open(filename, 'wb') as f:
        pickle.dump({
            'iteration': iteration,
            'evidence': evidence,
            'Xprev': Xprev,
            'points_sample': points_sample,
            'weights_sample': weights_sample,
            'evidence_list': evidence_list,
            'convergence_list': convergence_list,
            'Z': Z
        }, f)

def load_checkpoint(filename):
    with open(filename, 'rb') as f:
        checkpoint = pickle.load(f)
    return checkpoint

# Main nested sampling function using reinforcement learning
def nested_sampling_with_rl(likelihood_function, agent, iniloc, iniscale, region, nums, max_iterations, tol, max_update_iteration, checkpoint_file=None):
    if checkpoint_file and os.path.exists(checkpoint_file):
        checkpoint = load_checkpoint(checkpoint_file)
        iteration_num = checkpoint['iteration']
        evidence = checkpoint['evidence']
        Xprev = checkpoint['Xprev']
        points_sample = checkpoint['points_sample']
        weights_sample = checkpoint['weights_sample']
        evidence_list = checkpoint['evidence_list']
        convergence_list = checkpoint['convergence_list']
        Z = checkpoint['Z']
        print(f"Resuming from checkpoint {checkpoint_file}")
    else:
        iteration_num = 1
        evidence = 0
        Xprev = 1.
        points_sample = []
        weights_sample = []
        evidence_list = []
        convergence_list = []
        Z = []

    Xi = 0.
    evidence_contribution = 0.
    log_evidence = 0.
    kl_divergence = 0.
    
    all_lis = []
    evidence_contribution_list = []
    
    iniloc_new = iniloc
    iniscale_new = iniscale

    print("Sampling started!")

    for iteration in range(iteration_num, max_iterations + 1):
        
        num_live_points = nums
        iniguess = np.random.normal(loc=iniloc_new, scale=iniscale_new, size=(nums, len(iniloc)))
        ini_live_points = mixed_sampling(num_live_points, iniloc, iniscale, region)
        
        with ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
            likelihood_vals = np.array(list(executor.map(likelihood_function, ini_live_points)))

        # Ensure likelihood_vals is 1D and matches the length of ini_live_points
        likelihood_vals = likelihood_vals.flatten()

        live_points = ini_live_points[likelihood_vals > np.log(np.finfo(float).tiny)]
        live_points = [item for item in live_points if isinstance(item, np.ndarray)]
        
        if len(live_points) == 0:
            print(f"Iteration {iteration}: No valid live points found. Skipping this iteration.")
            continue
        
        print("---------------------")
        print("Running RL agent...")
        state = live_points[np.argmin(likelihood_vals)]
        state_tensor = torch.FloatTensor(state).unsqueeze(0)
        action = agent.select_action(state_tensor).squeeze()

        # Ensure action is a PyTorch tensor
        if isinstance(action, np.ndarray):
            action = torch.from_numpy(action).to(device)

        action = action.detach().cpu().numpy()
        next_point = state + action
        next_point = np.clip(next_point, region[:, 0], region[:, 1])
        
        print("Estimating evidence...")
        new_likelihood = likelihood_function(next_point)
        live_points[np.argmin(likelihood_vals)] = next_point
        likelihood_vals[np.argmin(likelihood_vals)] = new_likelihood
        Li = np.min(likelihood_vals)
        
        all_lis.append(Li)
        
        Xi = np.exp(-iteration / num_live_points)
        wi = Xprev - Xi

        evidence_contribution = wi * np.exp(Li)
        evidence_contribution_list.append(evidence_contribution)
        evidence += evidence_contribution
        log_evidence = np.log(evidence) if evidence != 0 else -np.finfo(float).max

        kl_divergence_deviation = wi * (Li - log_evidence)
        kl_divergence += kl_divergence_deviation

        points_sample.append(live_points[np.argmin(likelihood_vals)])
        weights_sample.append(wi)
        Z.append((live_points[np.argmin(likelihood_vals)], wi))
        
        # Convert points_sample to a NumPy array for KDE
        # points_sample_np = np.array(points_sample)
        
        # priors = compute_kde_with_pca(points_sample_np)

        # Compute the entropy H with checks to avoid division by zero and invalid log operations
        H = - np.sum(evidence_contribution * np.log(evidence_contribution / evidence)) if evidence != 0 else np.finfo(float).max

        # Add a small value to the length of Z to avoid division by zero
        sigma_log_Z = np.sqrt(H / (len(Z) + 1e-10))
                
        # Compute error in KL divergence using delta method
        # kl_variance = np.sum((evidence_contribution / evidence * np.log(evidence_contribution / (evidence * priors)))**2 * (np.sqrt(evidence_contribution) / evidence_contribution)**2)
        # sigma_KL = np.sqrt(kl_variance)
        
        evidence_list.append((Li, log_evidence, sigma_log_Z))
        convergence_list.append((H, kl_divergence))
        
        print("Saving data...")
        df = pd.DataFrame(Z, columns=['Point', 'Weight'])
        df.to_csv('nested_sampling_results.csv', index=False)
        
        df1 = pd.DataFrame(evidence_list, columns=['Likelihood', 'Log-Evidence', 'Log-Evidence Error'])
        df1.to_csv('nested_sampling_evidence.csv', index=False)
        df2 = pd.DataFrame(convergence_list, columns=['Information', 'KL-Divergence'])
        df2.to_csv('nested_sampling_convergence.csv', index=False)
        
        print("Updating live points...")
        ini_live_points, iniloc_new, iniscale_new = update_point(likelihood_function, iniguess, region, nums, live_points, Li)

        messages = [
            f"Iteration: {iteration}, Weight: {wi}, Log-Likelihood: {Li}",
            f"Log-Evidence: {log_evidence}, Log-Evidence Error: {sigma_log_Z}",
            f"Evidence Change: {evidence_contribution / evidence if evidence != 0 else float('inf')}",
            f"Information: {H}, KL-Divergence: {kl_divergence}",
            f"KL-Divergence Change: {kl_divergence_deviation}"
        ]
        
        is_last_message = iteration == max_iterations or (abs(evidence_contribution / evidence if evidence != 0 else 10 * tol) < tol and abs(kl_divergence_deviation / kl_divergence) < tol)

        save_checkpoint("checkpoint.pkl", iteration, evidence, Xprev, points_sample, weights_sample, evidence_list, convergence_list, Z)

        print("checkpoint saved.")

        if not is_last_message:
            clear_terminal()
        
        for message in messages:
            print(message)
        
        if is_last_message:
            print("Sampling finished!")
            save_checkpoint("checkpoint.pkl", iteration, evidence, Xprev, points_sample, weights_sample, evidence_list, convergence_list, Z)
            break

        Xprev = Xi
    return Z

if __name__ == "__main__":
    num_dimensions = len(coord_grids)
    coord_ranges = [(coord_grids[i].min().item(), coord_grids[i].max().item()) for i in range(num_dimensions)]

    env = NestedSamplingEnv(coord_ranges)
    agent = PPO(state_dim=num_dimensions, action_dim=num_dimensions, max_action=2)
    
    iniloc = np.array([coord_grids[i].mean().item() for i in range(num_dimensions)])
    iniscale = np.array([coord_grids[i].std().item() for i in range(num_dimensions)])
    region = np.array(coord_ranges)
    nums = 10
    max_iterations = 10000
    tol = 1e-5
    max_update_iteration = 3
    likelihood_function = log_likelihood_function

    profiler = cProfile.Profile()
    profiler.enable()
    
    results = nested_sampling_with_rl(likelihood_function, agent, iniloc, iniscale, region, nums, max_iterations, tol, max_update_iteration, checkpoint_file="checkpoint.pkl")
    
    profiler.disable()
    profiler.dump_stats("profile_results.prof")
    
    with open("profile_results.txt", "w") as f:
        ps = pstats.Stats(profiler, stream=f)
        ps.sort_stats(pstats.SortKey.CUMULATIVE)
        ps.print_stats()
    
    print("Profiling completed. Results saved to profile_results.txt")