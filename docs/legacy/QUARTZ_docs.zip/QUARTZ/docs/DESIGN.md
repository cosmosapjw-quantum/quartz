# QUARTZ Developer Design Doc

## 1) 시스템 개요
QUARTZ는 크게 3가지 레이어로 본다.

- Layer A: **Baseline AlphaZero stack (공정 비교의 기준선)**
  - 규칙 기반 게임 엔진(C++ 또는 동등한 레퍼런스 구현)
  - 정책+가치 NN
  - PUCT MCTS + TT + 병렬화
  - self-play / 학습 / 평가 파이프라인

- Layer B: **QUARTZ 모듈(스케줄러, ON/OFF 가능)**
  - “동적 truncation / 동적 widening / 동적 halting”
  - 같은 평균 시간 예산에서 계산을 재배치해서 Elo를 올린다.
  - baseline과의 차이는 오직 `SearchController` 뿐이어야 한다.

- Layer C: **Teacher → Student (CPU-only) distillation 레이어**
  - teacher(보통 GPU): 더 강한 정책/가치 타깃을 빨리 만든다.
  - student(배포/평가, CPU-only): teacher를 모사 + CPU 조건에 맞게 추가학습한다.
  - 최종 목표가 CPU-only 엔진이므로, C 레이어는 “선택”이 아니라 사실상 핵심 루트다.

v0에서는 Layer A(=baseline)가 “정확하고 빠르고 재현 가능”하게 돌아가야 하고,  
Layer B는 ON/OFF로 공정 비교가 가능한 형태로 붙어야 하며,  
Layer C는 커리큘럼 초반(쉬운 게임)부터 실험할 수 있게 최소 계약을 갖춘다.

---

## 2) 커리큘럼(순차 진행)과 stage gate
커리큘럼은 다음 순서로 진행한다.

TicTacToe → Gomoku 9×9 → Gomoku 13×13 → Gomoku 15×15 → Renju 15×15  
→ Chess/Chess960(가능성 실험) → Go 9×9 → Go 19×19(가능성 실험)

각 단계는 “(A) 기능 테스트 + (B) 성능/시간분포 테스트 + (C) Elo/품질 게이트”를 통과해야만 다음으로 넘어간다.  
정의는 `docs/CURRICULUM.md`, 규격은 `specs/090-curriculum.md`.

---

## 3) 주요 컴포넌트

### 3.1 Game Engine Adapter (C++ ↔ Python)
- 목적: 모든 게임을 동일 API로 취급
- 구현: pybind11 wrapper(권장)
- 책임:
  - 상태 표현/복사/적용
  - 합법수 생성
  - terminal 판정 + outcome
  - Zobrist hash(또는 canonical hash) 제공
  - (선택) symmetry transforms 제공

> 참고: mctx/JAX로 “완전 GPU self-play”를 붙이고 싶다면,
> (1) C++ 엔진을 JAX로 옮기는 것부터가 큰 일이라서
> 초기에는 **CPU 엔진(정답 구현) vs JAX 엔진(가속 구현)** 을 “상태 샘플 기반으로 교차검증”하는 테스트가 필수다.

### 3.2 NN Inference
- 입력: canonical state tensor
- 출력: `(policy_logits, value)`
- 요구: policy+value “한 번에”
- 런타임:
  - CPU: ONNXRuntime(oneDNN) 또는 TorchScript
  - GPU: PyTorch 또는 JAX(mctx 사용 시)

권장: **Policy head를 fully-convolutional로 설계**해서 보드 크기(9/13/15) 변경에 재사용성을 확보한다.
- 예: policy logits을 `[..., H, W]`로 만들고, 최종적으로 `flatten(+pass)` 하는 방식.

### 3.3 MCTS Core
- `SearchTree`: 노드/엣지 저장
- `NodeStats`: N, W, Q, prior, virtual loss, child pointers
- `TranspositionTable`: state hash → node id (또는 stats)
- `SelectionPolicy`: PUCT
- `Backup`: value backup(negamax)
- `RootPolicy`: temperature / dirichlet noise(학습)

### 3.4 SearchController (Baseline vs QUARTZ)
- baseline: fixed-budget(또는 동일한 budget policy)에서 “그냥 끝까지 돌기”
- QUARTZ: 같은 평균 예산을 유지하면서
  - 쉬운 수는 빠르게 stop
  - 어려운 수는 더 오래/더 넓게
  - widening/halting을 조절

Time distribution 목표(기본):
- 쉬운 수: p50 ≤ 0.5s
- 평균: mean ≤ 5s
- 어려운 수: 상위 구간 mean ≤ 15s
- 최악: p99 ≤ 30s cap

### 3.5 Self-Play Runner
- 멀티게임 병렬 실행(프로세스 단위 추천)
- 각 게임은 내부적으로 스레드 병렬 MCTS 사용 가능
- (고급) GPU 배치 추론 서버:
  - leaf evaluation 요청을 모아서 GPU에 마이크로배치로 던진다.
  - CPU를 “풀로” 쓰면서 GPU도 먹이는 정석 구조.

### 3.6 Trainer (GPU)
- 리플레이 샘플링
- 정책 loss(KL/CE), 가치 loss(MSE), L2
- EMA 또는 best checkpoint 선택
- export(ONNX/TS)

### 3.7 Distiller (Teacher → Student)
- teacher 네트워크가 생성한 `policy_target`(soft)과 `value`를
  student가 모사하도록 학습한다.
- student는 CPU 런타임(ONNX)에서 latency/throughput 목표를 만족해야 한다.
- 정의/계약: `specs/085-distillation.md`

### 3.8 Evaluation Harness
- 내부 평가: arena match, 고정 opening set
- 외부 평가: Gomocup Manager(가능하면)
- stage gate(승격 조건) 자동 판정 포함

---

## 4) 병렬화 설계(핵심)
요구: “CPU-only에서도 안정적인 시간 분포”를 만들려면,
스레드들이 같은 트리/같은 TT를 공유해야 한다.

### 4.1 기본 전략
- 스레드 = simulation worker
- 루트에서 동시에 selection/expansion/backup을 수행
- 충돌 완화:
  - virtual loss
  - atomic visit count
  - TT는 lock striping(버킷 락) 또는 RWLock

### 4.2 추천 락 구조(실전형)
- `NodeStats` 내부:
  - `N`, `W` 업데이트는 원자적 또는 per-node mutex
  - child 생성(확장)은 “한 번만” 이뤄지므로 CAS 플래그 + 단일 락
- `TT`:
  - key→entry 삽입은 버킷 락
  - 조회는 optimistic read 시도 가능(ABA는 버전 카운터로 방지)

### 4.3 Inference batching
CPU에서도 batch를 묶으면 이득이 크다.
- 각 스레드는 leaf를 확장할 때 “평가 요청”을 큐에 넣는다.
- `InferenceServer` 스레드가 일정 마이크로배치(예: 16~128)로 NN을 호출.
- 결과를 Future/Promise로 돌려준다.

---

## 5) 보드 크기(9→13→15) 확장 전략
보드 사이즈가 바뀔 때 “완전 재학습”만 하면 실험 비용이 폭발한다. 그래서 옵션을 3단계로 둔다.

### 5.1 옵션 A (기본, 가장 추천): Fully-Conv + Transfer
- 같은 네트워크(fully-conv head)로 입력 H×W를 늘리고,
- 9×9 체크포인트를 13×13/15×15로 전이(fine-tune)한다.
- 추가로 좌표 feature(예: x/y plane, edge distance)를 넣어 size generalization을 돕는다.

### 5.2 옵션 B (강화): gpool/SE로 global context 강화
- SE로 채널 중요도를 재조정
- gpool(전역 pooling feature)로 “보드 전체 맥락”을 policy/value에 주입
- 오목/렌주에서 특히 “장거리 패턴”을 빨리 잡는 데 유리할 수 있다.

### 5.3 옵션 C (실험): 작은 GNN head로 scale invariance 강화
- 앞단에 아주 작은 message passing(예: 2~4 step)으로
  보드 크기 변화에 덜 민감한 representation을 만든다.
- 장점: size-invariant한 inductive bias
- 단점: CPU inference에서 느려질 가능성(구현/최적화 난이도↑)
- 권장 운영: teacher(GPU)에서만 먼저 실험하고,
  이득이 확인되면 student에 “극소형”으로 이식

---

## 6) 로그/관측성
필수: “성능”과 “학습”이 같이 돌아야 한다.

- Search logs(매 move):
  - total simulations, nps
  - eval batch size 평균
  - TT hit/collision
  - root entropy, top-k policy mass
  - difficulty bucket(easy/avg/hard)와 실제 시간 분포
- Training logs:
  - losses, entropy, value variance
  - self-play Elo trend
- Distillation logs:
  - teacher-student policy KL
  - student latency(ONNX) 스모크 테스트 결과

상세 정의는 `docs/LOGGING_METRICS.md`.

---

## 7) 파일/모듈 레이아웃(권장)
- `quartz/`
  - `engine/` (pybind wrapper)
  - `mcts/` (core)
  - `controller/` (budget policy + QUARTZ scheduler)
  - `nn/` (models + inference runtimes)
  - `selfplay/`
  - `train/`
  - `distill/`
  - `eval/`
  - `utils/` (logging, config)
- `cpp/` (엔진/TT/핫루프)
- `tests/`
- `docs/`, `specs/`
