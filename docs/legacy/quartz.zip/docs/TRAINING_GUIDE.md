# Training Guide

## Architecture: Rust MCTS + Python NN (sole training engine)

All training self-play uses the Rust MCTS engine with Python NN evaluation
via the bidirectional search_nn IPC protocol.

### Search Features (all active during training)

- Transposition table (Zobrist hashing)
- Virtual loss (adaptive split vvisit/vvalue via ParallelismController)
- Progressive widening
- QUARTZ controller (6 penalty modes)
- Tree reuse (advance_root)
- FEN tracking (chess)

### Self-Play Flow

Python main loop calls selfplay_rust_nn_batched(parallel=4):
1. Launch N Rust server processes
2. Each process: Rust MCTS tree search (TT+VL+PW+QUARTZ)
3. Eval requests collected, batched into 1 GPU forward pass
4. Responses distributed back to Rust processes
5. Game trajectories returned to training loop

### Background Actor (--concurrent)

Main thread: training (SGD on replay buffer)
Background: SelfPlayWorker (Rust+NN, frozen model snapshot)
- Uses selfplay_rust_nn_batched(parallel=2)
- Backpressure: pauses at 80% replay capacity
- Model snapshot refreshed after each checkpoint

## Requirements

- Rust binary required: cargo build --release (training exits if not found)
- PyTorch: for NN model (training + evaluation)
- Recommended GPU: for NN forward pass throughput

## Legacy Components

- TreeMCTS: retained for arena evaluation (lightweight model comparison)
- selfplay_rust(): Tier 1 ShortRollout, internal function for search-only ablation (not exposed as standalone CLI)

## Checkpoint Evaluation

Training-time checkpoint evaluation uses RustNNEvaluatorEngine (same Rust+NN stack as training self-play)
when the Rust binary is available. This ensures evaluation semantics match training semantics.
Falls back to TreeMCTSEngine only when Rust binary is missing (with explicit warning).

The search_nn result payload includes controller telemetry (partial; core stats):
- p_flip, sigma_q, hbar_eff: QUARTZ controller state
- stop_reason: why search terminated (Budget/VOC/Threshold/ConfAdaptive)
- iterations: actual visit count
