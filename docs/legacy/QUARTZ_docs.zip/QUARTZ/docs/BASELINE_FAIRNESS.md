# Baseline Fairness Contract (MCTS+NN)

목표: “QUARTZ 모듈이 진짜로 계산 재배치로 이득을 주는지” 보려면 baseline이 허술하면 안 된다.  
즉, baseline은 최소한 “동급의 인프라”를 가져야 한다.

이 문서는 baseline이 **반드시 포함해야 하는 요소**를 체크리스트로 고정한다.

---

## A. 동일하게 가져가야 하는 MCTS 인프라(필수)

### A1) Transposition Table (TT)
- shared TT (모든 스레드/모든 시뮬레이션이 공유)
- key: `hash(canonical_state)`
- 저장:
  - node pointer 또는 통계 구조체
- collision policy:
  - replace/keep/2-way 등 선택하되 baseline/QUARTZ 동일

### A2) Tree Parallelization
- 스레드들이 하나의 트리를 동시에 탐색
- virtual loss(또는 equivalent)로 스레드 충돌 완화
- node stats 업데이트는 atomic 또는 per-node lock
- 확장(자식 생성)은 exactly-once 보장(CAS flag + lock)

### A3) Node Statistics (정의 고정)
- 방문수: N(s), N(s,a)
- 누적 value: W(s,a)
- 평균 Q(s,a) = W/N
- prior P(s,a) (NN에서 제공)
- terminal 처리: outcome는 정확히 negamax convention에 맞춰 backup

### A4) Selection (Baseline)
- PUCT:
  - argmax_a [ Q + c_puct * P * sqrt(N_parent)/(1+N_child) ]
- tie-breaking 규칙 고정(결과 재현성에 영향)

### A5) Progressive Widening (Baseline에서의 최소)
Gomoku 같은 게임은 branching이 크지 않을 수 있지만,
공정성을 위해 baseline에도 동일한 widening 정책을 둔다:
- (baseline) fixed PW schedule
- (QUARTZ) dynamic PW schedule
즉 PW 자체를 켜고 끄는 게 아니라 “스케줄러만” 바꾼다.

### A6) Root Noise / Temperature (학습 모드)
- 학습 시 root에 Dirichlet noise를 섞어 exploration 확보
- 평가 모드에서는 noise OFF
- temperature schedule 고정(예: 첫 k수는 τ>0)

### A7) Batched NN Inference
- leaf evaluation은 “가능하면 batch”로 묶는다
- baseline/QUARTZ 동일한 inference server 사용

### A8) Time Budget Policy (쉬움/평균/어려움 분포까지 동일)
QUARTZ의 핵심이 “계산 재배치”라서, 시간 예산 정책 자체가 달라지면 비교가 무의미해진다.

따라서 baseline과 QUARTZ는 다음을 **같은 정책**으로 공유한다:
- per-move “목표 분포” (예: 쉬운 수 ≤0.5s, 평균 ≤5s, 어려운 수 ≤15s, cap 30s)
- 난이도 판정에 쓰는 지표(예: root entropy, value variance 등)
- cap(최대 시간) 및 초과 시 처리(즉시 stop / 안전 반환)

QUARTZ는 오직:
- 같은 총예산/정책 하에서 “어디에 더 쓸지(트리 내부 스케줄링)”만 바꾼다.

---

## B. 동일하게 가져가야 하는 학습/평가 프로토콜
- 같은 NN 구조(동일 비교 시)
- 같은 optimizer/lr schedule
- 같은 self-play 설정(오프닝/색상/seed/시간 정책)
- 같은 Elo 산출 방식(로지스틱 또는 BayesElo)
- 같은 하드웨어 조건(가능하면) + 로그에 명시

> 주의: Teacher→Student 실험은 “baseline vs QUARTZ 공정 비교”와 목적이 다르다.
> Teacher/Student 비교는 `specs/085-distillation.md`와 stage gate(`specs/090-curriculum.md`)에 따른다.

---

## C. QUARTZ가 추가로 하는 것(차이점은 여기만!)
- `SearchController`를 교체:
  - baseline: fixed-time / fixed-widening(또는 동일 budget policy 하의 기본 스케줄)
  - QUARTZ: dynamic halting / dynamic widening / compute scheduling
- 그 외 엔진/NN/TT/병렬화는 동일해야 한다.

---

## D. 체크리스트(실험 전에 반드시 확인)
- [ ] baseline과 QUARTZ가 동일한 executable을 쓴다
- [ ] 동일 TT / 동일 collision policy
- [ ] 동일 스레드 수 / 동일 time budget policy
- [ ] 동일 NN 가중치
- [ ] 동일 오프닝/랜덤 시드 정책
- [ ] 로그에서 “실험 조건”이 자동 기록된다
