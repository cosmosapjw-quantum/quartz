# Quickstart: Training and Experiments

## 1. Training a Model from Scratch

### Gomoku 7×7 (recommended first experiment)

```bash
# Basic training run: ~30 iterations, ~5000 positions
python3 -m quartz.train \
    --game gomoku7 \
    --iters 200 \
    --games 20 \
    --steps 50 \
    --lr 0.01 \
    --iterations 30

# Monitor training: loss should decrease from ~3.8 toward ~2.0
# Output: models/<game>/ckpt_iter*.pt, training_log.json
```

### Key training parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--game` | gomoku7 | Game: gomoku7, gomoku15, go9, chess |
| `--iters` | 200 | MCTS iterations per move |
| `--games` | 20 | Self-play games per training iteration |
| `--steps` | 50 | SGD steps per training iteration |
| `--lr` | 0.01 | Learning rate |
| `--iterations` | 30 | Total training iterations |
| `--channels` | 32 | ResNet filter count (scales model size) |
| `--blocks` | 2 | ResNet block count |
| `--concurrent` | false | Background self-play worker |
| `--eval-interval` | 5 | Evaluate checkpoint every N iterations |

### Concurrent training (faster, requires more RAM)

```bash
python3 -m quartz.train \
    --game gomoku7 \
    --concurrent \
    --iters 200 \
    --games 20
```

This runs self-play in a background thread while the main thread trains.
The worker uses a frozen model snapshot, updated at each checkpoint.

## 2. Understanding Training Output

Training produces:
- `models/<game>/ckpt_iter*.pt` — model checkpoints
- `models/<game>/best.pt` — best model (promoted via Glicko-2)
- `training_log.json` — per-iteration metrics

### Training log fields

```json
{
    "iter": 10,
    "loss": 2.15,
    "policy_loss": 1.82,
    "value_loss": 0.33,
    "positions": 2400,
    "games_done": 200,
    "replay_freshness": 0.85,
    "policy_entropy": 2.1,
    "value_std": 0.42,
    "avg_pflip": 0.38,
    "elapsed": 45.2
}
```

Key indicators:
- **loss decreasing**: model is learning
- **replay_freshness > 0.5**: replay buffer has recent data
- **avg_pflip decreasing**: search is converging (requires loss < ~1.0)

## 3. Running Search Ablations

### Level 1: Search-only (no training, fixed evaluator)

These run inside the Rust test suite:

```bash
# VL ablation: component isolation + budget scaling + QUARTZ interaction
cargo test --release -- ablation_vl::tests::vl_ablation_gomoku7 --ignored --nocapture

# P_flip convergence experiment
cargo test --release -- ablation_pflip::tests::pflip_convergence_curves --ignored --nocapture

# Prior refresh ablation
cargo test --release -- ablation_refresh_v2 --ignored --nocapture
```

### Level 2: Training-level ablation

Compare QUARTZ modes across full training runs:

```bash
# Baseline: no QUARTZ penalty
python3 -m quartz.train --game gomoku7 --penalty-mode None --iterations 30

# GatedRefresh (default)
python3 -m quartz.train --game gomoku7 --penalty-mode GatedRefresh --iterations 30

# SelfAdaptive
python3 -m quartz.train --game gomoku7 --penalty-mode SelfAdaptive --iterations 30
```

Compare by examining `training_log.json` loss curves and arena win rates.

### Level 3: Arena evaluation

```bash
# Compare two checkpoints (strict Rust+NN engine)
python3 -m quartz.train \
    --arena models/gomoku7/ckpt_iter010.pt models/gomoku7/ckpt_iter030.pt \
    --arena-games 100
```

## 4. Interpreting Ablation Results

### VL ablation table columns

| Column | Meaning |
|--------|---------|
| Agree | % moves matching serial (1-thread) reference |
| Entrop | Root policy entropy (higher = more exploration) |
| Q_Sprd | Q-value spread across root actions |
| NPS | Nodes per second |
| AvgVV | Average virtual value applied (lower = less pessimism) |
| DupRt | Duplicate leaf rate (how often threads collide) |
| MaxP | Maximum pending threads at any node |

Key relationships:
- **Fixed VL**: AvgVV≈1.0, DupRt≈0.27 (over-pessimistic, avoids overlap)
- **Adaptive VL**: AvgVV≈0.17, DupRt≈0.38 (controlled overlap, less waste)
- Fixed + SelfAdaptive = worst (double pessimism)
- Adaptive + SelfAdaptive = rescued (σ_Q auto-correction)

### P_flip interpretation

- P_flip ≈ 0.5: evaluator provides no useful signal (random)
- P_flip < 0.25: search is converging, safe to stop early
- P_flip threshold (0.159): adaptive stopping trigger

P_flip convergence requires NN loss < ~1.0. With weak evaluators
(ShortRollout, Uniform), P_flip stays at 0.4-0.5 regardless of budget.

## 5. Supported Games

| Game | Board | Actions | Encoder | Status |
|------|-------|---------|---------|--------|
| gomoku7 | 7×7 | 49 | 3ch | Full training + evaluation |
| gomoku15 | 15×15 | 225 | 6ch | Full training + evaluation |
| go9 | 9×9 | 82 | 5ch | Search + self-play |
| chess | 8×8 | 4672 | 16ch | Search + self-play (FEN) |

## 6. Project Structure

```
quartz/
├── train.py              CLI entrypoint (thin wrapper)
├── evaluation.py         Glicko-2 evaluation system
├── encoders.py           Game-specific board encoders
├── onnx_support.py       ONNX export/inference
├── gpu_detect.py         GPU auto-detection
├── backend.py            JAX/PyTorch backend abstraction

python/
├── alphazero_train.py    Core training loop (~2300 lines)
├── calibration_eval.py   Evaluation protocol + self-tests
├── backend.py            Standalone backend module

src/
├── mcts/
│   ├── quartz.rs         QUARTZ search controller
│   ├── parallel.rs       ParallelismController (adaptive VL)
│   ├── select.rs         PUCT selection + score shaping
│   ├── search.rs         Search loop + stop reasons
│   └── ...               backup, expand, eval, node, tt, rng
├── games/                chess, go, gomoku, gomoku15, tictactoe
├── mcts_server.rs        JSON-line IPC server
├── ablation_vl.rs        VL ablation suite (3 experiments)
├── ablation_pflip.rs     P_flip ablation suite (3 experiments)
└── main.rs               Entry point + legacy experiments

docs/                     This documentation
configs/                  Preset configurations
models/                   Trained checkpoints
```
