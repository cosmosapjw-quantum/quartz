# specs/040-selfplay.md

## Purpose
self-play 데이터 생성 계약을 정의한다.  
baseline/QUARTZ 공정 비교와, teacher→student distillation을 모두 지원해야 한다.

---

## Output Record (per step)
필수 필드:
- `state`
- `pi_target` (visit distribution; sparse/top-k 가능)
- `z` (game outcome; win/loss/draw)
- `meta`:
  - `move_idx`
  - `player`
  - `time_used_ms`
  - `sims`
  - `root_value`
  - `root_entropy`
  - `difficulty_bucket` (easy/avg/hard)
  - `engine_mode` (baseline/quartz)
  - `stage_id` (gomoku9, gomoku13, ...)

선택 필드(distillation용):
- `teacher_policy_logits` 또는 `teacher_policy`(soft target)
- `teacher_value`
- `teacher_temp` (soft target temperature; 쓰는 경우)

---

## Requirements
- data 포맷은 “baseline/QUARTZ 동일”이어야 한다.
- resign 정책을 쓰면, 그 기준이 로그에 남아야 한다.
- (권장) 같은 시드/동일 조건에서 “재현 가능한” 샘플링이 가능해야 한다.
- distillation을 쓰더라도, 원본 `pi_target`(MCTS 방문분포)은 항상 남긴다.
  - 이유: teacher가 바뀌어도 baseline 비교 실험은 계속 가능해야 한다.

---

## Invariants
- `pi_target`은 합법수에 대해서만 양수 mass를 가진다.
- `z`는 terminal outcome과 일치해야 한다.
- `difficulty_bucket`의 판정 규칙(임계값)은 config로 고정되고 record에 간접적으로 추적 가능해야 한다(config hash).

---

## Acceptance Tests
- 100게임 생성 시 파일/레코드가 누락되지 않는다.
- state/π/z 정합성 검사 통과.
- (옵션) distillation 필드가 켜진 모드에서도 동일 테스트가 통과한다.
