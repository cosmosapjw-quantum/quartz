# specs/010-game-api.md

## Purpose
게임별 엔진(C++)을 QUARTZ에서 공통 방식으로 다루기 위한 최소 API를 정의한다.

## Data Types
- `State`: immutable-ish object (copy cheap or reference-counted)
- `Move`: compact, hashable, comparable

## Required API
- `initial_state() -> State`
- `current_player(s: State) -> int`  # {+1, -1} 또는 {0,1}
- `legal_moves(s: State) -> list[Move]`
- `apply_move(s: State, a: Move) -> State`
- `is_terminal(s: State) -> bool`
- `outcome(s: State) -> float`  # terminal에서만 유효, 현재 플레이어 관점(+1 win / 0 draw / -1 loss)
- `hash(s: State) -> uint64`  # TT key
- `encode(s: State) -> Tensor`  # NN 입력 텐서 (canonical form)

## Optional API
- `symmetries(s: State) -> list[Transform]`
- `apply_symmetry(s: State, t: Transform) -> State`
- `transform_policy(pi, t) -> pi_t`

## Invariants
- `apply_move`는 pure해야 한다(입력 상태를 mutate하지 않거나, mutate한다면 외부에서 절대 재사용하지 않도록 계약).
- `hash`는 동일한 상태에 대해 항상 동일해야 한다.
- `outcome`은 negamax convention과 일치해야 한다.

## Concurrency
- State는 여러 스레드에서 읽어도 안전해야 한다.
- 엔진이 내부적으로 캐시를 쓰면 락 또는 thread-local로 격리.

## Acceptance Tests
- legal moves가 비어있지 않으면 apply_move 후 상태가 변한다.
- terminal이면 legal_moves는 빈 리스트이거나, apply_move가 금지되어야 한다.
- 1만 랜덤 플레이에서 hash 충돌이 통계적으로 “관측되지 않을” 정도로 낮아야 한다(실험 기반).
