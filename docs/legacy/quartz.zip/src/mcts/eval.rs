//! Evaluator 구현체 (v0.4.2)
//!
//! UniformEval     — 균등 prior, value=0.0
//! ShortRollout    — max_depth 제한 랜덤 플레이아웃 (Gomoku용 실질 signal)
//! RandomPlayout   — 완전 랜덤 플레이아웃 (TicTacToe용)
//! PythonIpcEval   — eval_server.py JSON-line IPC (center_preference prior)

use rand::seq::SliceRandom;
use rand::thread_rng;
use rand::{Rng, SeedableRng};
use rand::rngs::StdRng;
use std::io::{BufRead, BufReader, Write};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::sync::Mutex;

use crate::game::{EvalResult, Evaluator, GameState};

// ─────────────────────────────────────────────
// § UniformEval
// ─────────────────────────────────────────────

pub struct UniformEval;

impl<G: GameState> Evaluator<G> for UniformEval {
    fn evaluate(&self, state: &G) -> EvalResult<G::Move> {
        EvalResult::uniform(&state.legal_moves(), 0.0)
    }
}

// ─────────────────────────────────────────────
// § ShortRollout — max_depth 제한 플레이아웃
//
// Gomoku/Chess처럼 playout이 긴 게임에서 실질 value signal을 생성하기 위해
// 최대 `max_depth` 수까지만 플레이아웃하고 terminal이 아니면 `draw_value`를 반환.
//
// 결과:
//   - Q에 실제 ±1 역전파 → σ_Q > 0 → QUARTZ 신호 활성화
//   - 완전 플레이아웃보다 빠르고 메모리 safe
// ─────────────────────────────────────────────

pub struct ShortRollout {
    /// 최대 플레이아웃 깊이 (0 = immediate eval only)
    pub max_depth:  usize,
    /// terminal에 도달하지 못한 경우 반환 값
    pub draw_value: f32,
    /// 재현성 시드 (None = 비결정적)
    pub seed:       Option<u64>,
}

impl ShortRollout {
    pub fn new(max_depth: usize) -> Self {
        ShortRollout { max_depth, draw_value: 0.0, seed: None }
    }

    pub fn seeded(max_depth: usize, seed: u64) -> Self {
        ShortRollout { max_depth, draw_value: 0.0, seed: Some(seed) }
    }
}

impl<G: GameState> Evaluator<G> for ShortRollout {
    fn evaluate(&self, state: &G) -> EvalResult<G::Move> {
        let legal = state.legal_moves();
        if legal.is_empty() {
            return EvalResult::uniform(&[], state.outcome());
        }

        // 균등 prior (향후 NN prior로 교체)
        let p = 1.0 / legal.len() as f32;
        let policy: Vec<(G::Move, f32)> = legal.iter().map(|&m| (m, p)).collect();

        let value = short_playout(state, self.max_depth, self.draw_value, self.seed);
        EvalResult { policy, value }
    }
}

fn short_playout<G: GameState>(
    start:      &G,
    max_depth:  usize,
    draw_value: f32,
    seed:       Option<u64>,
) -> f32 {
    let mut state   = start.clone();
    let root_player = start.current_player();

    let mut seeded_rng = seed.map(StdRng::seed_from_u64);

    for _depth in 0..max_depth.max(1) {
        if state.is_terminal() {
            let raw  = state.outcome();
            let flip = if state.current_player() == root_player { 1.0 } else { -1.0 };
            return raw * flip;
        }
        let legal = state.legal_moves();
        if legal.is_empty() { break; }

        // 1-ply immediate win check — [OPT] uses is_winning_move (no state clone)
        // Semantically identical to: apply_move + is_terminal + outcome check
        let mut chosen = None;
        for &mv in &legal {
            if state.is_winning_move(mv) { chosen = Some(mv); break; }
        }

        let mv = chosen.unwrap_or_else(|| {
            if let Some(ref mut rng) = seeded_rng {
                *legal.choose(rng).unwrap()
            } else {
                *legal.choose(&mut thread_rng()).unwrap()
            }
        });
        state = state.apply_move(mv);
    }

    if state.is_terminal() {
        let raw  = state.outcome();
        let flip = if state.current_player() == root_player { 1.0 } else { -1.0 };
        raw * flip
    } else {
        draw_value
    }
}

// ─────────────────────────────────────────────
// § RandomPlayout — 완전 플레이아웃
// ─────────────────────────────────────────────

pub struct RandomPlayout;

impl<G: GameState> Evaluator<G> for RandomPlayout {
    fn evaluate(&self, state: &G) -> EvalResult<G::Move> {
        let legal = state.legal_moves();
        if legal.is_empty() {
            return EvalResult::uniform(&[], state.outcome());
        }
        let p = 1.0 / legal.len() as f32;
        let policy = legal.iter().map(|&m| (m, p)).collect();
        let value  = full_playout(state);
        EvalResult { policy, value }
    }
}

fn full_playout<G: GameState>(start: &G) -> f32 {
    let mut state   = start.clone();
    let root_player = start.current_player();
    let mut rng     = thread_rng();
    loop {
        if state.is_terminal() {
            let raw  = state.outcome();
            let flip = if state.current_player() == root_player { 1.0 } else { -1.0 };
            return raw * flip;
        }
        let legal = state.legal_moves();
        let mv = if let Some(w) = immediate_win(&state, &legal) { w }
                 else { *legal.choose(&mut rng).unwrap() };
        state = state.apply_move(mv);
    }
}

fn immediate_win<G: GameState>(state: &G, legal: &[G::Move]) -> Option<G::Move> {
    for &mv in legal {
        let next = state.apply_move(mv);
        if next.is_terminal() && next.outcome() < 0.0 { return Some(mv); }
    }
    None
}

// ─────────────────────────────────────────────
// § PythonIpcEval — eval_server.py IPC
// ─────────────────────────────────────────────

struct IpcInner {
    child:  Child,
    stdin:  ChildStdin,
    reader: BufReader<ChildStdout>,
}

pub struct PythonIpcEval {
    inner:        Mutex<Option<IpcInner>>,
    server_path:  String,
    /// 보드 크기 힌트 (eval_server.py의 center_preference용)
    pub board_size: usize,
}

impl PythonIpcEval {
    pub fn new(server_path: &str) -> std::io::Result<Self> {
        Ok(PythonIpcEval {
            inner:      Mutex::new(None),
            server_path: server_path.to_string(),
            board_size: 0,
        })
    }

    pub fn with_board_size(mut self, size: usize) -> Self {
        self.board_size = size;
        self
    }

    fn ensure_started(&self) -> Result<(), String> {
        let mut lock = self.inner.lock().unwrap();
        if lock.is_some() { return Ok(()); }
        let mut child = Command::new("python3")
            .arg(&self.server_path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .map_err(|e| format!("failed to start eval server: {e}"))?;
        let stdin  = child.stdin.take().unwrap();
        let stdout = child.stdout.take().unwrap();
        *lock = Some(IpcInner { child, stdin, reader: BufReader::new(stdout) });
        Ok(())
    }

    fn call<G: GameState>(&self, state: &G) -> EvalResult<G::Move> {
        let legal   = state.legal_moves();
        let n_act   = state.num_actions();
        let mut mask = vec![0u8; n_act];
        for &mv in &legal { mask[state.move_to_idx(mv)] = 1; }

        let bs = if self.board_size > 0 { self.board_size }
                 else {
                     // 자동 감지: num_actions가 제곱수면 sqrt 사용
                     let sq = (n_act as f64).sqrt() as usize;
                     if sq * sq == n_act { sq } else { 0 }
                 };

        let req = serde_json::json!({
            "num_actions": n_act,
            "action_mask": mask,
            "board_size":  bs,
            "features":    state.encode_planes(),
        });

        let mut lock = self.inner.lock().unwrap();
        let inner = lock.as_mut().expect("eval server not started");

        if inner.stdin.write_all((req.to_string() + "\n").as_bytes()).is_err()
            || inner.stdin.flush().is_err()
        {
            return EvalResult::uniform(&legal, 0.0);
        }

        let mut line = String::new();
        if inner.reader.read_line(&mut line).unwrap_or(0) == 0 {
            return EvalResult::uniform(&legal, 0.0);
        }

        let resp: serde_json::Value = match serde_json::from_str(line.trim()) {
            Ok(v)  => v,
            Err(_) => return EvalResult::uniform(&legal, 0.0),
        };
        if resp["status"].as_str() != Some("ok") {
            return EvalResult::uniform(&legal, 0.0);
        }

        let policy_raw: Vec<f32> = resp["policy"].as_array()
            .map(|a| a.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect())
            .unwrap_or_default();
        let value = resp["value"].as_f64().unwrap_or(0.0) as f32;

        let policy: Vec<(G::Move, f32)> = legal.iter()
            .filter_map(|&mv| policy_raw.get(state.move_to_idx(mv))
                .copied().map(|p| (mv, p.max(0.0))))
            .collect();

        let total: f32 = policy.iter().map(|(_, p)| p).sum();
        let policy = if total > 1e-8 {
            policy.into_iter().map(|(m, p)| (m, p / total)).collect()
        } else {
            EvalResult::uniform(&legal, value).policy
        };
        EvalResult { policy, value }
    }
}

impl<G: GameState> Evaluator<G> for PythonIpcEval {
    fn evaluate(&self, state: &G) -> EvalResult<G::Move> {
        if self.ensure_started().is_err() {
            return EvalResult::uniform(&state.legal_moves(), 0.0);
        }
        self.call(state)
    }
}

impl Drop for PythonIpcEval {
    fn drop(&mut self) {
        let mut lock = self.inner.lock().unwrap();
        if let Some(mut inner) = lock.take() {
            let _ = inner.stdin.write_all(b"{\"cmd\":\"quit\"}\n");
            let _ = inner.child.wait();
        }
    }
}

unsafe impl Send for PythonIpcEval {}
unsafe impl Sync for PythonIpcEval {}

// ─── StdioCallbackEval: bidirectional NN evaluation via server stdin/stdout ───


/// Evaluator that sends eval requests to stdout and reads responses from stdin.
/// Used by `search_nn` server command for NN-backed MCTS.
///
/// Protocol:
///   Rust → Python: {"eval_req":{"features":[...],"action_mask":[...],"num_actions":N}}
///   Python → Rust: {"eval_resp":{"policy":[...],"value":V}}
pub struct StdioCallbackEval {
    n_actions: usize,
    io: std::sync::Mutex<(std::io::Stdin, std::io::Stdout)>,
}

impl StdioCallbackEval {
    pub fn new(n_actions: usize) -> Self {
        StdioCallbackEval {
            n_actions,
            io: std::sync::Mutex::new((std::io::stdin(), std::io::stdout())),
        }
    }
}

impl<G: GameState> Evaluator<G> for StdioCallbackEval where usize: From<G::Move> {
    fn evaluate(&self, state: &G) -> EvalResult<G::Move> {
        let legal = state.legal_moves();
        if legal.is_empty() {
            return EvalResult { policy: vec![], value: 0.0 };
        }

        let planes = state.encode_planes();
        let legal_moves = state.legal_moves();
        let mut mask = vec![false; self.n_actions];
        for &mv in &legal_moves {
            let idx: usize = mv.into();
            if idx < self.n_actions { mask[idx] = true; }
        }

        let features_str = planes.iter().map(|f| format!("{:.4}", f)).collect::<Vec<_>>().join(",");
        let mask_str = mask.iter().map(|&b| if b { "1" } else { "0" }).collect::<Vec<_>>().join(",");
        let req = format!("{{\"eval_req\":{{\"features\":[{}],\"action_mask\":[{}],\"num_actions\":{}}}}}\n",
            features_str, mask_str, self.n_actions);

        // Mutex serializes ALL evaluate() calls — critical for bidirectional I/O.
        // Only one thread can write eval_req + read eval_resp at a time.
        let _guard = self.io.lock().unwrap();

        // Write eval_req
        {
            let mut out = std::io::stdout().lock();
            let _ = out.write_all(req.as_bytes());
            let _ = out.flush();
        }

        // Read eval_resp
        let mut line = String::new();
        {
            let stdin = std::io::stdin();
            let mut reader = stdin.lock();
            let _ = reader.read_line(&mut line);
        }

        drop(_guard);  // release Mutex after I/O complete

        // Parse response
        let line = line.trim();
        if let Some(start) = line.find("\"policy\":[") {
            let pol_start = start + "\"policy\":[".len();
            if let Some(pol_end) = line[pol_start..].find(']') {
                let pol_str = &line[pol_start..pol_start + pol_end];
                let probs: Vec<f32> = pol_str.split(',')
                    .filter_map(|s| s.trim().parse().ok())
                    .collect();

                let value = if let Some(vs) = line.find("\"value\":") {
                    let vstart = vs + "\"value\":".len();
                    let vrest = line[vstart..].trim_start();
                    let vend = vrest.find(|c: char| !c.is_ascii_digit() && c != '-' && c != '.')
                        .unwrap_or(vrest.len());
                    vrest[..vend].parse::<f32>().unwrap_or(0.0)
                } else { 0.0 };

                let mut policy = Vec::with_capacity(legal_moves.len());
                let mut sum = 0.0f32;
                for &mv in &legal_moves {
                    let idx: usize = mv.into();
                    let p = if idx < probs.len() { probs[idx].max(0.0) } else { 0.0 };
                    sum += p;
                    policy.push((mv, p));
                }
                if sum > 0.0 { for (_, p) in &mut policy { *p /= sum; } }
                return EvalResult { policy, value };
            }
        }

        EvalResult::uniform(&legal_moves, 0.0)
    }
}

unsafe impl Send for StdioCallbackEval {}
unsafe impl Sync for StdioCallbackEval {}

// ─── CachedEval: evaluator that pops pre-computed results from a queue ───

use std::collections::VecDeque;

/// Evaluator that returns pre-cached results from an internal queue.
/// Used by batch MCTS: K results are pushed in, K evaluate() calls pop them out.
pub struct CachedEval<M: Copy> {
    pub cache: std::sync::Mutex<VecDeque<EvalResult<M>>>,
    pub n_actions: usize,
}

impl<M: Copy> CachedEval<M> {
    pub fn new(n_actions: usize) -> Self {
        CachedEval {
            cache: std::sync::Mutex::new(VecDeque::new()),
            n_actions,
        }
    }

    pub fn push(&self, result: EvalResult<M>) {
        self.cache.lock().unwrap().push_back(result);
    }
}

impl<G: GameState> Evaluator<G> for CachedEval<G::Move> {
    fn evaluate(&self, state: &G) -> EvalResult<G::Move> {
        // Pop from cache if available
        if let Some(result) = self.cache.lock().unwrap().pop_front() {
            return result;
        }
        // Fallback: uniform
        EvalResult::uniform(&state.legal_moves(), 0.0)
    }
}

unsafe impl<M: Copy> Send for CachedEval<M> {}
unsafe impl<M: Copy> Sync for CachedEval<M> {}
