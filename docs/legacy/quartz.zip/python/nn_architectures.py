#!/usr/bin/env python3
"""
NN Architectures for all supported games.
PyTorch implementations — export to ONNX via export_onnx.py.

Games: Gomoku 7×7, Gomoku 15×15, Chess, Go 9×9, Go 19×19
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# ═══════════════════════════════════════════════════════
# § Building blocks
# ═══════════════════════════════════════════════════════

class SEBlock(nn.Module):
    """Squeeze-and-Excitation: channel attention at ~0.1% param cost."""
    def __init__(self, ch, r=4):
        super().__init__()
        self.fc1 = nn.Linear(ch, ch // r)
        self.fc2 = nn.Linear(ch // r, ch)
    def forward(self, x):
        w = x.mean(dim=(2,3))
        w = torch.sigmoid(self.fc2(F.relu(self.fc1(w))))
        return x * w.unsqueeze(-1).unsqueeze(-1)

class ResBlock(nn.Module):
    """Pre-activation residual block with optional SE."""
    def __init__(self, ch, se=False):
        super().__init__()
        self.bn1 = nn.BatchNorm2d(ch)
        self.conv1 = nn.Conv2d(ch, ch, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(ch)
        self.conv2 = nn.Conv2d(ch, ch, 3, padding=1, bias=False)
        self.se = SEBlock(ch) if se else None
    def forward(self, x):
        out = self.conv1(F.relu(self.bn1(x)))
        out = self.conv2(F.relu(self.bn2(out)))
        if self.se: out = self.se(out)
        return x + out

# ═══════════════════════════════════════════════════════
# § AlphaZeroNet — game-agnostic dual-head ResNet
# ═══════════════════════════════════════════════════════

class AlphaZeroNet(nn.Module):
    def __init__(self, board_size, in_ch, n_actions, n_filters=128,
                 n_blocks=8, value_hidden=256, se_blocks=2):
        super().__init__()
        self.board_size = board_size
        self.n_actions = n_actions
        ch = n_filters
        n2 = board_size * board_size

        self.input_conv = nn.Conv2d(in_ch, ch, 3, padding=1, bias=False)
        self.input_bn = nn.BatchNorm2d(ch)

        blocks = []
        for i in range(n_blocks):
            blocks.append(ResBlock(ch, se=(i >= n_blocks - se_blocks)))
        self.tower = nn.Sequential(*blocks)

        # Policy head (2-conv)
        self.p_conv1 = nn.Conv2d(ch, 32, 1, bias=False)
        self.p_bn1 = nn.BatchNorm2d(32)
        self.p_conv2 = nn.Conv2d(32, 4, 1, bias=False)
        self.p_bn2 = nn.BatchNorm2d(4)
        self.p_fc = nn.Linear(4 * n2, n_actions)

        # Value head (global pool)
        self.v_conv = nn.Conv2d(ch, 32, 1, bias=False)
        self.v_bn = nn.BatchNorm2d(32)
        self.v_fc1 = nn.Linear(32, value_hidden)
        self.v_fc2 = nn.Linear(value_hidden, 1)

    def forward(self, x):
        h = F.relu(self.input_bn(self.input_conv(x)))
        h = self.tower(h)
        p = F.relu(self.p_bn1(self.p_conv1(h)))
        p = F.relu(self.p_bn2(self.p_conv2(p)))
        p = self.p_fc(p.reshape(p.size(0), -1))
        v = F.relu(self.v_bn(self.v_conv(h)))
        v = v.mean(dim=(2,3))
        v = torch.tanh(self.v_fc2(F.relu(self.v_fc1(v))))
        return p, v.squeeze(-1)

    @torch.no_grad()
    def predict(self, x):
        self.eval()
        if x.dim() == 3: x = x.unsqueeze(0)
        logits, v = self(x)
        return F.softmax(logits, dim=-1).cpu().numpy(), v.cpu().numpy()

# ═══════════════════════════════════════════════════════
# § Game-specific constructors
# ═══════════════════════════════════════════════════════

def make_gomoku7():
    """Gomoku 7×7: 3ch, 49 actions, 64f×4b (~100K params)"""
    return AlphaZeroNet(7, 3, 49, n_filters=64, n_blocks=4, value_hidden=64, se_blocks=0)

def make_gomoku15():
    """Gomoku 15×15: 3ch, 225 actions, 128f×8b+SE (~1.2M params)"""
    return AlphaZeroNet(15, 3, 225, n_filters=128, n_blocks=8, value_hidden=256, se_blocks=2)

def make_chess():
    """Chess: 119ch input (AlphaZero encoding), 4672 actions.
    
    Input planes (119 = 8×14 + 7):
      8 steps × (6 piece types × 2 colors + 2 repetition) = 112
      + castling(4) + en passant(1) + halfmove(1) + fullmove(1) = 7
    
    Policy: 8×8 from-square × 73 move-types = 4672
      - 56 queen moves (7 distances × 8 directions)
      - 8 knight moves
      - 9 underpromotions (3 piece types × 3 directions)
    
    128f×10b+SE (~2.5M params). Batch≤256 at 16GB VRAM.
    """
    return AlphaZeroNet(8, 119, 4672, n_filters=128, n_blocks=10, value_hidden=256, se_blocks=2)

def make_go9():
    """Go 9×9: 17ch, 82 actions (81+pass), 128f×10b+SE (~1.5M params).
    
    Input planes (17):
      8 history steps × 2 colors = 16
      + color-to-play = 1
    """
    return AlphaZeroNet(9, 17, 82, n_filters=128, n_blocks=10, value_hidden=256, se_blocks=2)

def make_go19():
    """Go 19×19: 17ch, 362 actions (361+pass), 192f×15b+SE (~8M params).
    
    Larger net for 19×19 complexity:
    - 192 filters (vs 128 for smaller boards)
    - 15 blocks (vs 8-10)
    - SE on last 4 blocks
    - Value hidden: 256
    
    VRAM at batch=512: ~6GB (fits in 16GB).
    Training: ~2s per batch on RX 6950 XT.
    Inference: ~1ms per position.
    """
    return AlphaZeroNet(19, 17, 362, n_filters=192, n_blocks=15, value_hidden=256, se_blocks=4)

# ═══════════════════════════════════════════════════════
# § Input encoding helpers
# ═══════════════════════════════════════════════════════

import numpy as np

def encode_gomoku(board, player, size):
    """Gomoku 3-plane encoding: my_stones, opp_stones, color."""
    out = np.zeros((3, size, size), dtype=np.float32)
    for i in range(size * size):
        r, c = i // size, i % size
        if board[i] == player:      out[0, r, c] = 1.0
        elif board[i] == -player:   out[1, r, c] = 1.0
    if player == 1: out[2] = 1.0
    return out

def encode_chess_alphazero(board_history, castling, ep, halfmove, fullmove, side):
    """Chess 119-plane AlphaZero encoding.
    
    board_history: list of up to 8 board states, each [64] with piece codes
    Piece codes: 1-6 = WP,WN,WB,WR,WQ,WK; 7-12 = BP,BN,BB,BR,BQ,BK; 0=empty
    """
    planes = np.zeros((119, 8, 8), dtype=np.float32)
    for t, board in enumerate(board_history[-8:]):
        offset = t * 14
        for sq in range(64):
            r, c = sq // 8, sq % 8
            piece = board[sq]
            if 1 <= piece <= 6:   planes[offset + piece - 1, r, c] = 1.0
            elif 7 <= piece <= 12: planes[offset + 6 + piece - 7, r, c] = 1.0
        # Repetition planes (simplified: just mark if same as t-2)
        if t >= 2 and board_history[-(t+1)] == board_history[-(t-1)]:
            planes[offset + 12] = 1.0
    # Meta planes
    for i in range(4):
        if castling & (1 << i): planes[112 + i] = 1.0
    if 0 <= ep < 8:
        planes[116, :, ep] = 1.0  # EP file
    planes[117] = halfmove / 100.0
    planes[118] = fullmove / 200.0
    return planes

def encode_go(board_history, size, player, komi=7.5):
    """Go 17-plane encoding: 8 history × 2 colors + color plane."""
    planes = np.zeros((17, size, size), dtype=np.float32)
    n2 = size * size
    for t, board in enumerate(board_history[-8:]):
        for i in range(n2):
            r, c = i // size, i % size
            if board[i] == 1:   planes[t * 2, r, c] = 1.0      # black
            elif board[i] == 2: planes[t * 2 + 1, r, c] = 1.0  # white
    if player == 1: planes[16] = 1.0  # black to play
    return planes

# ═══════════════════════════════════════════════════════
# § Summary
# ═══════════════════════════════════════════════════════

ARCHITECTURES = {
    "gomoku7":  (make_gomoku7,  7,  3,  49),
    "gomoku15": (make_gomoku15, 15, 3,  225),
    "chess":    (make_chess,    8,  119, 4672),
    "go9":      (make_go9,     9,  17,  82),
    "go19":     (make_go19,    19, 17,  362),
}

def print_summary():
    for name, (make_fn, bs, ch, acts) in ARCHITECTURES.items():
        m = make_fn()
        n = sum(p.numel() for p in m.parameters())
        print(f"  {name:12} {bs}×{bs}  {ch:>3}ch  {acts:>5} actions  {n:>10,} params")

if __name__ == "__main__":
    print("QUARTZ NN Architectures:")
    print_summary()
