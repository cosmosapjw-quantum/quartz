# QUARTZ
**QUAntized Resource Tree Search**  
CPU-first AlphaZero baseline + (later) physics-inspired dynamic MCTS truncation / compute scheduling.

## 지금 이 리포지토리는 뭘 하려는 거냐
1) 먼저 **공정한 AlphaZero-style baseline(정책+가치 NN + PUCT MCTS)** 을 만든다.  
2) 그 위에 QUARTZ 모듈(동적 truncation / dynamic halting / dynamic widening / compute scheduling)을 “플러그인”처럼 얹는다.  
3) 같은 평균 시간 예산(기본값: 5초/수)에서 **더 높은 Elo**가 나오는지 검증한다.

> 핵심 철학: “추가 계산”이 아니라 “계산 재배치”로 이겨야 한다.  
> 쉬운 수는 0.5초 내, 평균 5초 내, 어려운 수는 평균 15초 내(최대 30초 cap) 같은 **시간 분포를 안정적으로 만들고**,  
> 그 동일 분포/평균 예산에서 Elo가 오르는지 본다.

---

## 커리큘럼(순차 진행)
“스펙에 적힌 단계별 실험/테스트(=stage gate)”를 통과해야 다음으로 넘어간다.

TicTacToe → Gomoku 9×9 → Gomoku 13×13 → Gomoku 15×15 → Renju 15×15  
→ Chess/Chess960(가능성 실험) → Go 9×9 → Go 19×19(가능성 실험)

- 상세: `docs/CURRICULUM.md`, `specs/090-curriculum.md`

---

## Teacher → Student (CPU-only) 전략
최종 목표가 CPU-only 엔진이므로, 학습 단계에서는 “GPU 교사(teacher)”를 만들고,  
배포 단계에서는 “CPU 학생(student)”으로 distillation/추가학습해서 성능을 내는 방향을 1순위로 둔다.

- teacher: ResNet(+SE,+gpool) 계열을 기본
- student: 더 작은 ResNet 또는 경량(conv-separable / quant-ready)
- 계약: `specs/085-distillation.md`

---

## 리포 구조(문서 중심)
- `PRD.md` — 제품 요구/성공지표/공정 비교 원칙/커리큘럼 요약
- `AGENT.md` — LLM 코딩 에이전트 작업 규칙
- `docs/` — 디자인/파이프라인/성능/병렬화/로그/커리큘럼
- `specs/` — spec-driven development 문서 세트(컴포넌트별 계약)
- `references/` — 외부 링크/너가 올린 노트(그대로 보관)

---

## 빌드/실행(예시 스케치)
> 코드 스켈레톤은 문서 우선이라, 여기선 “우리가 만들게 될” 커맨드 형태만 적어둠.

### (1) Python 환경
- Python 3.13+ 권장(가능하면 free-threading build)
- PyTorch(학습용), ONNXRuntime 또는 TorchScript(추론용) 중 택1

### (2) C++ 엔진 + pybind11
- `pip install -e .` 형태로 빌드할 계획
- AVX2 최적화는 C++ 쪽에서 우선 적용(옵션)

### (3) Self-play & Training
- `quartz selfplay --game gomoku --size 9 --threads 8 --budget_policy adaptive`
- `quartz train --data ./replay --gpus 1`
- `quartz distill --teacher ./teacher.onnx --student ./student.onnx`
- `quartz export --format onnx`

### (4) Evaluation
- 내부: `quartz eval --vs baseline --games 200`
- 외부: Gomocup Manager(가능하면)

---

## 공정 비교(Fairness)
QUARTZ가 “이상한 편법으로만 이기는” 걸 막기 위해 baseline과 QUARTZ는 다음을 공유한다:
- 동일 NN
- 동일 엔진
- 동일 TT
- 동일 tree parallelization
- 동일 time budget policy

상세는 `docs/BASELINE_FAIRNESS.md`.

---

## 라이선스 / 저작권
- 이 프로젝트는 개인 연구/개발 용도 전제를 기본으로 문서를 구성했다.
- 대회(Gomocup) 제출을 염두에 두면, 외부 라이브러리/모델 가중치/데이터의 라이선스 정리가 필요하다.
