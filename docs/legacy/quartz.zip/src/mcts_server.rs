//! Multi-game MCTS JSON-line server — trajectory + move protocols
//!
//! Protocol 1 (single move): {"cmd":"move","game":"chess","fen":"...","iters":200}
//! Protocol 2 (self-play):   {"cmd":"selfplay","game":"gomoku15_std","iters":400,"n_games":1,"temp_threshold":15}
//!   → full game trajectory with (state_planes, policy, player, outcome)

use std::io::{self, BufRead, Write};
use std::sync::Arc;
use std::sync::atomic::Ordering;

use crate::game::{GameState, EvalResult};
use crate::mcts::{MctsConfig, MctsEngine};
use crate::mcts::eval::{ShortRollout, CachedEval};
use crate::mcts::quartz::{QuartzConfig, QuartzController, PenaltyMode};
use crate::mcts::select::select;
use crate::mcts::backup::backprop;
use crate::mcts::expand::expand_and_evaluate;

use crate::games::gomoku15::{Gomoku15, GomokuVariant, gomoku15_quartz};
use crate::games::Gomoku;
use crate::games::chess::{Chess, chess_quartz};
use crate::games::go::{Go, go_quartz};

fn jstr<'a>(s: &'a str, key: &str) -> Option<&'a str> {
    let pat = format!("\"{}\":", key);
    let start = s.find(&pat)? + pat.len();
    let rest = s[start..].trim_start();  // skip whitespace after colon
    if rest.starts_with('"') {
        let inner = &rest[1..];
        let end = inner.find('"')?;
        Some(&inner[..end])
    } else {
        None
    }
}
fn jint(s: &str, key: &str) -> Option<i64> {
    let pat = format!("\"{}\":", key);
    let start = s.find(&pat)? + pat.len();
    let rest = s[start..].trim_start();
    let end = rest.find(|c: char| !c.is_ascii_digit() && c != '-').unwrap_or(rest.len());
    rest[..end].parse().ok()
}
fn jarr(s: &str, key: &str) -> Vec<i64> {
    let pat = format!("\"{}\":[", key);
    if let Some(start) = s.find(&pat) {
        let rest = &s[start + pat.len()..];
        if let Some(end) = rest.find(']') {
            return rest[..end].split(',').filter_map(|v| v.trim().parse().ok()).collect();
        }
    }
    vec![]
}
fn jfloat(s: &str, key: &str) -> Option<f64> {
    let pat = format!("\"{}\":", key);
    let start = s.find(&pat)? + pat.len();
    let rest = s[start..].trim_start();
    let end = rest.find(|c: char| !c.is_ascii_digit() && c != '-' && c != '.').unwrap_or(rest.len());
    rest[..end].parse().ok()
}
fn f_or(v: f32, d: f32) -> f32 { if v.is_finite() { v } else { d } }

/// Run one self-play game with tree reuse via advance_root().
fn selfplay_one<G: GameState>(
    initial: G, config_fn: impl Fn() -> MctsConfig,
    iters: u32, temp_thresh: usize, num_actions: usize,
) -> String where G::Move: Into<usize> + PartialEq {
    let eval: Arc<ShortRollout> = Arc::new(ShortRollout::new(12));
    let first_player = initial.current_player();
    let mut positions = Vec::new();
    let mut move_n = 0usize;

    // Create engine ONCE, reuse tree across moves
    let config = config_fn();
    let qcfg_template = config.quartz.clone().unwrap_or_default();
    let mut engine = MctsEngine::new(initial, eval.clone(), config);

    while !engine.root_state().is_terminal() && move_n < 500 {
        let legal = engine.root_state().legal_moves();
        if legal.is_empty() { break; }

        // Search from current root (reusing subtree from previous move)
        let mut ctrl = QuartzController::new(iters, qcfg_template.clone());
        engine.run_quartz(&mut ctrl);

        // Visit distribution
        let guard = engine.root.edges.lock().unwrap();
        let mut visits = vec![0u32; num_actions];
        let mut total = 0u32;
        for e in guard.iter() {
            let idx: usize = e.mv.into();
            let n = e.n.load(Ordering::Relaxed);
            if idx < num_actions { visits[idx] = n; total += n; }
        }
        drop(guard);

        let policy: Vec<f32> = visits.iter().map(|&n|
            if total > 0 { n as f32 / total as f32 } else { 0.0 }).collect();
        let planes = engine.root_state().encode_planes();

        let pol_str: Vec<String> = policy.iter().enumerate()
            .filter(|(_, &p)| p > 1e-6)
            .map(|(i, p)| format!("\"{}:{:.4}\"", i, p))
            .collect();
        let board_str: String = planes.iter()
            .map(|v| if *v > 0.5 { "1" } else { "0" })
            .collect::<Vec<_>>().join("");

        // Controller telemetry per position (Doc 23 patch)
        let stats = ctrl.last_stats();
        let pf = f_or(stats.p_flip, 0.0);
        let sq = f_or(stats.sigma_q, 0.0);
        let hb = f_or(stats.hbar_eff, 0.0);

        positions.push(format!(
            "{{\"pl\":{},\"bd\":\"{}\",\"pol\":[{}],\"pf\":{:.4},\"sq\":{:.4},\"hb\":{:.4}}}",
            engine.root_state().current_player(), board_str, pol_str.join(","), pf, sq, hb
        ));

        // Move selection
        let chosen = if move_n < temp_thresh {
            let seed = engine.root_state().hash().wrapping_mul(6364136223846793005).wrapping_add(1);
            let r = (seed >> 33) as f32 / (1u64 << 31) as f32;
            let mut cum = 0.0f32;
            let mut sel = legal[0];
            for &mv in &legal {
                let idx: usize = mv.into();
                if idx < num_actions { cum += policy[idx]; if cum >= r { sel = mv; break; } }
            }
            sel
        } else {
            let mut best = legal[0]; let mut bn = 0u32;
            for &mv in &legal { let i: usize = mv.into(); if i < num_actions && visits[i] > bn { bn = visits[i]; best = mv; } }
            best
        };

        // Tree reuse: advance root to chosen child
        if !engine.advance_root(chosen) {
            // Fallback: if advance fails, rebuild engine from current state
            let new_state = engine.root_state().apply_move(chosen);
            let cfg = config_fn();
            engine = MctsEngine::new(new_state, eval.clone(), cfg);
        }
        move_n += 1;
    }

    let outcome = if engine.root_state().is_terminal() {
        let raw = engine.root_state().outcome();
        if engine.root_state().current_player() == first_player { raw } else { -raw }
    } else { 0.0 };

    format!("{{\"outcome\":{:.4},\"n_moves\":{},\"positions\":[{}]}}",
        outcome, move_n, positions.join(","))
}

fn parse_penalty_mode(s: &str) -> PenaltyMode {
    match s {
        "None" => PenaltyMode::None,
        "Legacy" => PenaltyMode::Legacy,
        "EffectiveV2" => PenaltyMode::EffectiveV2,
        "SelfAdaptive" => PenaltyMode::SelfAdaptive,
        "GatedRefresh" => PenaltyMode::GatedRefresh,
        "PFlipMixture" => PenaltyMode::PFlipMixture,
        _ => PenaltyMode::GatedRefresh, // default
    }
}

fn override_penalty(mut cfg: MctsConfig, mode: PenaltyMode, cap: f32) -> MctsConfig {
    if let Some(ref mut q) = cfg.quartz {
        q.penalty_mode = mode;
        if cap > 0.0 { q.hbar_penalty_cap = cap; }
    }
    cfg
}

fn handle_selfplay(line: &str) -> String {
    let game = jstr(line, "game").unwrap_or("gomoku15_std");
    let iters = jint(line, "iters").unwrap_or(200) as u32;
    let n = jint(line, "n_games").unwrap_or(1) as usize;
    let tt = jint(line, "temp_threshold").unwrap_or(15) as usize;
    let pm_str = jstr(line, "penalty_mode").unwrap_or("GatedRefresh");
    let pm = parse_penalty_mode(pm_str);
    let cap = jfloat(line, "hbar_penalty_cap").unwrap_or(0.3) as f32;
    let cpuct = jfloat(line, "c_puct").unwrap_or(0.0) as f32; // 0 = use game default

    let mut games = Vec::new();
    for _ in 0..n {
        let g = match game {
            "gomoku7" => {
                let mut cfg = MctsConfig::evaluation(if cpuct > 0.0 { cpuct } else { 2.0 })
                    .with_quartz(QuartzConfig { min_visits: 15, check_interval: 20, ..Default::default() });
                cfg = override_penalty(cfg, pm, cap);
                selfplay_one(Gomoku::new_with_win(7, 4), move || cfg.clone(), iters, tt, 49)
            },
            "gomoku15_std"|"gomoku15" => {
                let mut cfg = gomoku15_quartz(GomokuVariant::Standard);
                cfg = override_penalty(cfg, pm, cap);
                if cpuct > 0.0 { cfg.c_puct = cpuct; }
                selfplay_one(Gomoku15::standard(), move || cfg.clone(), iters, tt, 225)
            },
            "gomoku15_omok"|"omok" => {
                let mut cfg = gomoku15_quartz(GomokuVariant::Omok);
                cfg = override_penalty(cfg, pm, cap);
                if cpuct > 0.0 { cfg.c_puct = cpuct; }
                selfplay_one(Gomoku15::omok(), move || cfg.clone(), iters, tt, 225)
            },
            "go9" => {
                let mut cfg = go_quartz(9);
                cfg = override_penalty(cfg, pm, cap);
                if cpuct > 0.0 { cfg.c_puct = cpuct; }
                selfplay_one(Go::new_9x9(), move || cfg.clone(), iters, tt, 82)
            },
            "chess" => {
                let mut cfg = chess_quartz();
                cfg = override_penalty(cfg, pm, cap);
                if cpuct > 0.0 { cfg.c_puct = cpuct; }
                selfplay_one(Chess::standard(), move || cfg.clone(), iters, tt, 4672)
            },
            _ => {
                let mut cfg = gomoku15_quartz(GomokuVariant::Standard);
                cfg = override_penalty(cfg, pm, cap);
                selfplay_one(Gomoku15::standard(), move || cfg.clone(), iters, tt, 225)
            }
        };
        games.push(g);
    }
    format!("[{}]", games.join(","))
}

fn search_gomoku15(line: &str, variant: GomokuVariant, iters: u32) -> String {
    let board_raw = jarr(line, "board");
    let player = jint(line, "player").unwrap_or(1) as i8;
    let state = if board_raw.len() == 225 {
        Gomoku15::from_board(&board_raw.iter().map(|&v| v as i8).collect::<Vec<_>>(), player, variant)
    } else { Gomoku15::new(variant) };
    let config = gomoku15_quartz(variant);
    let qcfg = config.quartz.clone().unwrap();
    let eval: Arc<ShortRollout> = Arc::new(ShortRollout::new(12));
    let engine = MctsEngine::new(state, eval, config);
    let mut ctrl = QuartzController::new(iters, qcfg);
    engine.run_quartz(&mut ctrl);
    let best = engine.best_move().unwrap_or(0);
    let s = ctrl.last_stats();
    let it = engine.root.n_total.load(Ordering::Relaxed);
    format!("{{\"move\":{},\"move_str\":\"({},{})\",\"hbar_eff\":{:.4},\"p_flip\":{:.4},\"iters\":{}}}",
        best, best as usize/15, best as usize%15, f_or(s.hbar_eff,0.0), f_or(s.p_flip,0.0), it)
}

fn search_chess(line: &str, iters: u32) -> String {
    let fen = jstr(line, "fen").unwrap_or("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    let state = Chess::from_fen(fen).unwrap_or_else(|_| Chess::standard());
    let config = chess_quartz();
    let qcfg = config.quartz.clone().unwrap();
    let eval: Arc<ShortRollout> = Arc::new(ShortRollout::new(12));
    let engine = MctsEngine::new(state, eval, config);
    let mut ctrl = QuartzController::new(iters, qcfg);
    engine.run_quartz(&mut ctrl);
    let best = engine.best_move().unwrap_or_else(|| crate::games::chess::ChessMove::new(0,0,0));
    let s = ctrl.last_stats();
    let it = engine.root.n_total.load(Ordering::Relaxed);
    format!("{{\"move\":{},\"move_str\":\"{}\",\"hbar_eff\":{:.4},\"p_flip\":{:.4},\"iters\":{}}}",
        best.0, best.to_uci(), f_or(s.hbar_eff,0.0), f_or(s.p_flip,0.0), it)
}

fn search_go(line: &str, size: usize, iters: u32) -> String {
    let board_raw = jarr(line, "board");
    let player = jint(line, "player").unwrap_or(1) as u8;
    let board: Vec<u8> = board_raw.iter().map(|&v| v as u8).collect();
    let state = if board.is_empty() { Go::new(size, 7.5) } else { Go::from_board(size, 7.5, &board, player) };
    let config = go_quartz(size);
    let qcfg = config.quartz.clone().unwrap();
    let eval: Arc<ShortRollout> = Arc::new(ShortRollout::new(12));
    let engine = MctsEngine::new(state.clone(), eval, config);
    let mut ctrl = QuartzController::new(iters, qcfg);
    engine.run_quartz(&mut ctrl);
    let best = engine.best_move().unwrap_or(state.pass_action());
    let s = ctrl.last_stats();
    let it = engine.root.n_total.load(Ordering::Relaxed);
    let n2 = size * size;
    let ms = if best as usize == n2 { "pass".into() } else { format!("({},{})", best as usize/size, best as usize%size) };
    format!("{{\"move\":{},\"move_str\":\"{}\",\"hbar_eff\":{:.4},\"p_flip\":{:.4},\"iters\":{}}}",
        best, ms, f_or(s.hbar_eff,0.0), f_or(s.p_flip,0.0), it)
}

pub fn serve() {
    eprintln!("MCTS server ready (selfplay + move + search_nn protocols)");
    // NOTE: We do NOT hold stdin/stdout locks across the loop.
    // search_nn needs direct stdio access for bidirectional eval protocol.
    loop {
        let mut line = String::new();
        {
            let stdin = io::stdin();
            let mut reader = stdin.lock();
            if reader.read_line(&mut line).unwrap_or(0) == 0 { break; }
        }
        let line = line.trim().to_string();
        if line.is_empty() { continue; }
        let cmd = jstr(&line, "cmd").unwrap_or("move");
        if cmd == "quit" { break; }

        if cmd == "search_nn" {
            let resp = handle_search_nn(&line);
            {
                let mut out = io::stdout().lock();
                let _ = writeln!(out, "{}", resp);
                let _ = out.flush();
            }
            continue;
        }

        let resp = match cmd {
            "selfplay" => handle_selfplay(&line),
            _ => {
                let game = jstr(&line, "game").unwrap_or("gomoku15_std");
                let iters = jint(&line, "iters").unwrap_or(200) as u32;
                match game {
                    "gomoku15_std"|"gomoku15" => search_gomoku15(&line, GomokuVariant::Standard, iters),
                    "gomoku15_omok"|"omok" => search_gomoku15(&line, GomokuVariant::Omok, iters),
                    "chess" => search_chess(&line, iters),
                    "go9" => search_go(&line, 9, iters),
                    "go13" => search_go(&line, 13, iters),
                    "go19" => search_go(&line, 19, iters),
                    _ => format!("{{\"error\":\"unknown game: {}\"}}", game),
                }
            }
        };
        {
            let mut out = io::stdout().lock();
            let _ = writeln!(out, "{}", resp);
            let _ = out.flush();
        }
    }
}

/// NN-backed single-move search using bidirectional eval protocol.
/// Python sends board state, Rust does MCTS with eval callbacks to Python NN.
/// Batch MCTS search: select K leaves → 1 batch eval → K expand+backprop.
/// Throughput: ~K× fewer IPC round-trips, ~K× better GPU utilization.
fn handle_search_nn(line: &str) -> String {
    let game = jstr(line, "game").unwrap_or("gomoku15_std");
    let iters = jint(line, "iters").unwrap_or(200) as u32;
    let pm = parse_penalty_mode(jstr(line, "penalty_mode").unwrap_or("GatedRefresh"));
    let cap = jfloat(line, "hbar_penalty_cap").unwrap_or(0.3) as f32;

    let n_actions: usize = match game {
        "gomoku7" => 49,
        "gomoku15_std"|"gomoku15"|"gomoku15_omok" => 225,
        "go9" => 82,
        "chess" => 4672,
        _ => 225,
    };

    let eval: Arc<crate::mcts::eval::StdioCallbackEval> =
        Arc::new(crate::mcts::eval::StdioCallbackEval::new(n_actions));

    // Helper: extract visits → policy JSON + controller/search telemetry
    fn extract_result<M: Into<usize> + Copy>(
        engine: &MctsEngine<impl GameState<Move=M>>,
        ctrl: &QuartzController, n_act: usize,
    ) -> String {
        let best: usize = engine.best_move().map(|m| m.into()).unwrap_or(0);
        let guard = engine.root.edges.lock().unwrap();
        let mut visits = vec![0u32; n_act];
        for e in guard.iter() {
            let i: usize = e.mv.into();
            if i < n_act { visits[i] = e.n.load(Ordering::Relaxed); }
        }
        drop(guard);
        let total: u32 = visits.iter().sum();
        let pol: Vec<String> = visits.iter().enumerate()
            .filter(|(_, &n)| n > 0)
            .map(|(i, &n)| format!("\"{}:{:.4}\"", i, n as f32 / total.max(1) as f32))
            .collect();
        let s = ctrl.last_stats();
        let stop = format!("{:?}", ctrl.last_stop_reason());
        format!(concat!(
            "{{\"result\":{{",
            "\"best_move\":{},\"policy\":[{}],",
            "\"p_flip\":{:.4},\"value\":{:.4},",
            "\"sigma_q\":{:.4},\"hbar_eff\":{:.4},",
            "\"stop_reason\":\"{}\",\"iterations\":{}",
            "}}}}"),
            best, pol.join(","),
            f_or(s.p_flip,0.0), f_or(s.mean_q,0.0),
            f_or(s.sigma_q,0.0), f_or(s.hbar_eff,0.0),
            stop, total)
    }

    match game {
        "gomoku7" => {
            let board_raw = jarr(line, "board");
            let player = jint(line, "player").unwrap_or(1) as i8;
            let player_12: u8 = if player == 1 { 1 } else { 2 };
            let board_12: Vec<i64> = if board_raw.len() == 49 {
                board_raw.iter().map(|&v| match v { 1 => 1, -1 => 2, _ => 0 }).collect()
            } else { vec![0i64; 49] };
            let state = Gomoku::from_board_12(7, 4, &board_12, player_12);
            let mut cfg = MctsConfig::evaluation(2.0)
                .with_quartz(QuartzConfig { min_visits: 15, check_interval: 20, ..Default::default() });
            cfg = override_penalty(cfg, pm, cap);
            let qcfg = cfg.quartz.clone().unwrap();
            let engine = MctsEngine::new(state, eval, cfg);
            let mut ctrl = QuartzController::new(iters, qcfg);
            engine.run_quartz(&mut ctrl);
            extract_result(&engine, &ctrl, 49)
        },
        "gomoku15_std"|"gomoku15" => {
            let board_raw = jarr(line, "board");
            let player = jint(line, "player").unwrap_or(1) as i8;
            let state = if board_raw.len() == 225 {
                Gomoku15::from_board(&board_raw.iter().map(|&v| v as i8).collect::<Vec<_>>(), player, GomokuVariant::Standard)
            } else { Gomoku15::standard() };
            let mut cfg = gomoku15_quartz(GomokuVariant::Standard);
            cfg = override_penalty(cfg, pm, cap);
            let qcfg = cfg.quartz.clone().unwrap();
            let engine = MctsEngine::new(state, eval, cfg);
            let mut ctrl = QuartzController::new(iters, qcfg);
            engine.run_quartz(&mut ctrl);
            extract_result(&engine, &ctrl, 225)
        },
        "go9" => {
            let board_raw = jarr(line, "board");
            let player = jint(line, "player").unwrap_or(1);
            let side: u8 = if player == 1 { 1 } else { 2 };
            let state = if board_raw.len() == 81 {
                Go::from_board(9, 7.5, &board_raw.iter().map(|&v| v as u8).collect::<Vec<_>>(), side)
            } else { Go::new_9x9() };
            let mut cfg = go_quartz(9);
            cfg = override_penalty(cfg, pm, cap);
            let qcfg = cfg.quartz.clone().unwrap();
            let engine = MctsEngine::new(state, eval, cfg);
            let mut ctrl = QuartzController::new(iters, qcfg);
            engine.run_quartz(&mut ctrl);
            extract_result(&engine, &ctrl, 82)
        },
        "chess" => {
            let fen = jstr(line, "fen").unwrap_or("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
            let state = Chess::from_fen(fen).unwrap_or_else(|_| Chess::standard());
            let mut cfg = chess_quartz();
            cfg = override_penalty(cfg, pm, cap);
            let qcfg = cfg.quartz.clone().unwrap();
            let engine = MctsEngine::new(state, eval, cfg);
            let mut ctrl = QuartzController::new(iters, qcfg);
            engine.run_quartz(&mut ctrl);

            // Extract result + compute result_fen after applying best move
            let best: usize = engine.best_move().map(|m| m.into()).unwrap_or(0);
            let guard = engine.root.edges.lock().unwrap();
            let mut visits = vec![0u32; 4672];
            for e in guard.iter() {
                let i: usize = e.mv.into();
                if i < 4672 { visits[i] = e.n.load(Ordering::Relaxed); }
            }
            drop(guard);
            let total: u32 = visits.iter().sum();
            let pol: Vec<String> = visits.iter().enumerate()
                .filter(|(_, &n)| n > 0)
                .map(|(i, &n)| format!("\"{}:{:.4}\"", i, n as f32 / total.max(1) as f32))
                .collect();
            let s = ctrl.last_stats();

            // Generate FEN after applying the best move
            let result_fen = if let Some(mv) = engine.best_move() {
                let new_state = engine.root_state().apply_move(mv);
                new_state.to_fen()
            } else {
                fen.to_string()
            };

            let stop = format!("{:?}", ctrl.last_stop_reason());
            format!(concat!(
                "{{\"result\":{{",
                "\"best_move\":{},\"policy\":[{}],",
                "\"p_flip\":{:.4},\"value\":{:.4},",
                "\"sigma_q\":{:.4},\"hbar_eff\":{:.4},",
                "\"stop_reason\":\"{}\",\"iterations\":{},",
                "\"result_fen\":\"{}\"",
                "}}}}"),
                best, pol.join(","),
                f_or(s.p_flip,0.0), f_or(s.mean_q,0.0),
                f_or(s.sigma_q,0.0), f_or(s.hbar_eff,0.0),
                stop, total, result_fen)
        },
        _ => format!("{{\"error\":\"search_nn not yet supported for {}\"}}", game),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn test_json() { assert_eq!(jstr(r#"{"cmd":"selfplay"}"#, "cmd"), Some("selfplay")); }
    #[test] fn test_chess() { let r = search_chess(r#"{}"#, 30); assert!(r.contains("move_str")); }
    #[test] fn test_go9() { let r = search_go(r#"{}"#, 9, 30); assert!(r.contains("move")); }
    #[test] fn test_gomoku15() { let r = search_gomoku15(r#"{}"#, GomokuVariant::Standard, 30); assert!(r.contains("move")); }
}
