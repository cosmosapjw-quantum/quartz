#!/usr/bin/env python3
"""
Unified ML Backend — auto-detects JAX or PyTorch, selects best available.

Priority:
  1. JAX + GPU (ROCm/CUDA) — fastest (XLA JIT compilation)
  2. PyTorch + GPU — good (ROCm/CUDA)
  3. JAX + CPU — decent (JIT still helps)
  4. PyTorch + CPU — fallback

Usage:
  from backend import create_backend
  be = create_backend(game_cfg, device="auto")
  be.train_step(states, policies, values)  # JIT-compiled if JAX
  policy, value = be.predict(state)         # JIT-compiled if JAX
"""
import os, time
import numpy as np

# ═══════════════════════════════════════════
# § Detection
# ═══════════════════════════════════════════

def detect_backends():
    """Detect available ML backends and their GPU support."""
    result = {"jax": False, "jax_gpu": False, "jax_devices": [],
              "torch": False, "torch_gpu": False, "torch_device": "cpu"}

    # JAX detection
    try:
        import jax
        result["jax"] = True
        devices = jax.devices()
        result["jax_devices"] = [str(d) for d in devices]
        result["jax_gpu"] = any("gpu" in str(d).lower() or "rocm" in str(d).lower()
                                or "cuda" in str(d).lower() for d in devices)
    except Exception:
        pass

    # PyTorch detection
    try:
        import torch
        result["torch"] = True
        if torch.cuda.is_available():
            result["torch_gpu"] = True
            result["torch_device"] = "cuda"
    except Exception:
        pass

    return result


def select_backend(detection, preference="auto"):
    """Select best backend based on detection results.
    
    Returns: "jax" or "torch"
    """
    if preference == "jax" and detection["jax"]:
        return "jax"
    if preference == "torch" and detection["torch"]:
        return "torch"

    # Auto: prefer JAX with GPU > PyTorch with GPU > JAX CPU > PyTorch CPU
    if detection["jax_gpu"]:
        return "jax"
    if detection["torch_gpu"]:
        return "torch"
    if detection["jax"]:
        return "jax"
    if detection["torch"]:
        return "torch"
    raise RuntimeError("No ML backend available. Install PyTorch or JAX.")


# ═══════════════════════════════════════════
# § JAX Backend
# ═══════════════════════════════════════════

class JAXBackend:
    """JIT-compiled training and inference via JAX/Flax.
    
    All hot paths are compiled with @jax.jit on first call.
    Subsequent calls run at XLA speed (~2-5× faster than eager PyTorch).
    """

    def __init__(self, cfg):
        import jax
        import jax.numpy as jnp
        import flax.linen as nn
        import optax
        from flax.training import train_state

        self.jax = jax
        self.jnp = jnp
        self.cfg = cfg
        self.name = "jax"

        # Import model
        try:
            from jax_models import AlphaZeroJAX
        except ImportError:
            from .jax_models import AlphaZeroJAX
        bs = cfg['board']
        model = AlphaZeroJAX(
            board_size=bs, in_ch=cfg['ch'], n_actions=cfg['actions'],
            n_filters=cfg['filters'], n_blocks=cfg['blocks'],
            value_hidden=cfg['vh'], se_blocks=min(2, cfg['blocks']))
        self.model = model

        # Initialize
        rng = jax.random.PRNGKey(42)
        dummy = jnp.ones((1, cfg['ch'], bs, bs))
        variables = model.init(rng, dummy, train=False)
        self.params = variables['params']
        self.batch_stats = variables.get('batch_stats', {})

        # Optimizer
        self.tx = optax.chain(
            optax.clip_by_global_norm(1.0),
            optax.sgd(learning_rate=0.02, momentum=0.9),
            optax.add_decayed_weights(1e-4),
        )
        self.opt_state = self.tx.init(self.params)

        # JIT-compile hot paths
        self._jit_train_step = jax.jit(self._train_step_impl)
        self._jit_predict = jax.jit(self._predict_impl)

        n_params = sum(p.size for p in jax.tree.leaves(self.params))
        devices = jax.devices()
        print(f"  JAX backend: {n_params:,} params on {devices}")

    def _train_step_impl(self, params, batch_stats, opt_state, states, policies, values):
        jnp = self.jnp

        def loss_fn(p):
            variables = {'params': p, 'batch_stats': batch_stats}
            (logits, vals), updates = self.model.apply(
                variables, states, train=True, mutable=['batch_stats'])
            log_probs = logits - self.jax.scipy.special.logsumexp(logits, axis=-1, keepdims=True)
            p_loss = -(policies * log_probs).sum(axis=-1).mean()
            v_loss = ((vals - values) ** 2).mean()
            return p_loss + v_loss, (p_loss, v_loss, updates.get('batch_stats', batch_stats))

        (loss, (p_loss, v_loss, new_bs)), grads = self.jax.value_and_grad(
            loss_fn, has_aux=True)(params)
        updates, new_opt = self.tx.update(grads, opt_state, params)
        new_params = optax.apply_updates(params, updates)
        return new_params, new_bs, new_opt, loss, p_loss, v_loss

    def _predict_impl(self, params, batch_stats, x):
        variables = {'params': params, 'batch_stats': batch_stats}
        logits, values = self.model.apply(variables, x, train=False)
        probs = self.jax.nn.softmax(logits, axis=-1)
        return probs, values

    def train_step(self, states_np, policies_np, values_np):
        """One training step. Returns (loss, p_loss, v_loss)."""
        jnp = self.jnp
        states = jnp.array(states_np)
        policies = jnp.array(policies_np)
        values = jnp.array(values_np)

        self.params, self.batch_stats, self.opt_state, loss, p_loss, v_loss = \
            self._jit_train_step(self.params, self.batch_stats, self.opt_state,
                                 states, policies, values)
        return float(loss), float(p_loss), float(v_loss)

    def predict(self, state_np):
        """Batch prediction. Returns (policies_np, values_np)."""
        x = self.jnp.array(state_np)
        if x.ndim == 3: x = x[None]
        probs, vals = self._jit_predict(self.params, self.batch_stats, x)
        return np.array(probs), np.array(vals)

    def set_lr(self, lr):
        """Update learning rate (recreate optimizer)."""
        import optax
        self.tx = optax.chain(
            optax.clip_by_global_norm(1.0),
            optax.sgd(learning_rate=lr, momentum=0.9),
            optax.add_decayed_weights(1e-4),
        )
        self.opt_state = self.tx.init(self.params)

    def save(self, path):
        """Save model parameters."""
        import pickle
        with open(path, 'wb') as f:
            pickle.dump({'params': self.params, 'batch_stats': self.batch_stats}, f)

    def load(self, path):
        """Load model parameters."""
        import pickle
        if os.path.exists(path):
            with open(path, 'rb') as f:
                data = pickle.load(f)
            self.params = data['params']
            self.batch_stats = data.get('batch_stats', {})
            return True
        return False

    def get_torch_model(self):
        """Not available for JAX backend."""
        return None


# ═══════════════════════════════════════════
# § PyTorch Backend
# ═══════════════════════════════════════════

class PyTorchBackend:
    """Standard PyTorch training and inference."""

    def __init__(self, cfg, device="auto"):
        import torch
        import torch.nn.functional as F
        self.torch = torch
        self.F = F
        self.cfg = cfg
        self.name = "torch"

        if device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        # Import and create model
        # Use inline definition to avoid circular imports
        try:
            from alphazero_train import AlphaZeroNet
        except ImportError:
            from .alphazero_train import AlphaZeroNet
        self.model = AlphaZeroNet(cfg).to(self.device)
        self.optimizer = torch.optim.SGD(
            self.model.parameters(), lr=0.02, momentum=0.9, weight_decay=1e-4)

        n_params = sum(p.numel() for p in self.model.parameters())
        print(f"  PyTorch backend: {n_params:,} params on {self.device}")

    def train_step(self, states_np, policies_np, values_np):
        torch = self.torch
        self.model.train()
        states = torch.tensor(states_np, dtype=torch.float32).to(self.device)
        policies = torch.tensor(policies_np, dtype=torch.float32).to(self.device)
        values = torch.tensor(values_np, dtype=torch.float32).to(self.device)

        logits, pred_v = self.model(states)
        log_probs = self.F.log_softmax(logits, dim=-1)
        p_loss = -(policies * log_probs).sum(dim=-1).mean()
        v_loss = self.F.mse_loss(pred_v, values)
        loss = p_loss + v_loss

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        self.optimizer.step()
        return loss.item(), p_loss.item(), v_loss.item()

    def predict(self, state_np):
        torch = self.torch
        self.model.eval()
        with torch.no_grad():
            x = torch.tensor(state_np, dtype=torch.float32).to(self.device)
            if x.dim() == 3: x = x.unsqueeze(0)
            logits, vals = self.model(x)
            probs = self.F.softmax(logits, dim=-1).cpu().numpy()
            return probs, vals.cpu().numpy()

    def set_lr(self, lr):
        for pg in self.optimizer.param_groups:
            pg['lr'] = lr

    def save(self, path):
        self.torch.save(self.model.state_dict(), path)

    def load(self, path):
        import os
        if os.path.exists(path):
            self.model.load_state_dict(
                self.torch.load(path, map_location=self.device, weights_only=True))
            return True
        return False

    def get_torch_model(self):
        return self.model


# ═══════════════════════════════════════════
# § Factory
# ═══════════════════════════════════════════

def create_backend(cfg, device="auto", preference="auto"):
    """Create the best available backend.
    
    Args:
        cfg: game config dict (from GAME_CONFIGS)
        device: "auto", "cpu", "cuda", "jax", "torch"
        preference: "auto", "jax", "torch"
    
    Returns: JAXBackend or PyTorchBackend
    """
    det = detect_backends()
    print(f"  Backend detection: JAX={'✅' if det['jax'] else '❌'}"
          f"{'(GPU)' if det['jax_gpu'] else ''} "
          f"PyTorch={'✅' if det['torch'] else '❌'}"
          f"{'(GPU)' if det['torch_gpu'] else ''}")

    if device in ("jax",): preference = "jax"
    elif device in ("torch", "cuda"): preference = "torch"

    backend_name = select_backend(det, preference)

    if backend_name == "jax":
        try:
            be = JAXBackend(cfg)
            # Warmup JIT
            bs = cfg['board']
            dummy = np.zeros((2, cfg['ch'], bs, bs), dtype=np.float32)
            dummy_pol = np.zeros((2, cfg['actions']), dtype=np.float32)
            dummy_val = np.zeros(2, dtype=np.float32)
            t0 = time.time()
            be.train_step(dummy, dummy_pol, dummy_val)
            be.predict(dummy)
            jit_time = time.time() - t0
            print(f"  JAX JIT warmup: {jit_time:.1f}s (subsequent calls ~10-100× faster)")
            return be
        except Exception as e:
            print(f"  JAX init failed ({e}), falling back to PyTorch")

    return PyTorchBackend(cfg, device=device)
