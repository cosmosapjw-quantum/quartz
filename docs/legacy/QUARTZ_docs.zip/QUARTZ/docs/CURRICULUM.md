# Curriculum & Stage Gates (QUARTZ)

이 문서는 “어떤 순서로, 무엇을 통과해야 다음 단계로 갈지”를 개발자 관점에서 정리한다.  
정확한 계약(spec)은 `specs/090-curriculum.md`가 기준이다.

---

## 0) 큰 원칙 3개
1) **다음 게임/보드로 넘어가기 전에, CPU-only 엔진이 ‘그렇게 느리지 않으면서’ Elo가 오른다는 증거**가 있어야 한다.  
2) baseline vs QUARTZ 비교는 항상 공정 비교 계약(`docs/BASELINE_FAIRNESS.md`)을 지킨다.  
3) “교사(teacher)는 GPU로 강하게”, “배포(student)는 CPU로 빠르게”가 기본이다.  
   teacher→student distillation을 통해 CPU-only 성능을 확보하고, 마지막에 CPU 조건으로 정렬한다.

---

## 1) 목표 시간 분포(기본값)
- 쉬운 수: p50 ≤ 0.5초
- 전체 평균: mean ≤ 5초
- 어려운 수: (난이도 상위 구간) mean ≤ 15초
- 최악: p99 ≤ 30초 cap

난이도 버킷(easy/avg/hard)은 “root entropy / root top-k mass / value uncertainty” 같은 지표로 정의하고,
임계값은 config로 고정한다(로그에 남겨야 함).

---

## 2) 단계별 진행 순서(너의 확정 루트)
1) TicTacToe  
2) Gomoku 9×9  
3) Gomoku 13×13  
4) Gomoku 15×15  
5) Renju 15×15  
6) Chess / Chess960 (아마추어 수준 가능성 실험만)  
7) Go 9×9  
8) Go 19×19 (아마추어 수준 가능성 실험만)

---

## 3) 네트워크 권장 프리셋(단일 5900X + 단일 3090 기준)
권장 프리셋은 `specs/030-nn-model.md`의 Teacher/Student 프로파일을 따른다.

- Teacher-S: ResNet 10×128 + SE + (가벼운) gpool  
- Teacher-M: ResNet 15×192 + SE + gpool  
- Teacher-L: ResNet 20×256 + SE + gpool  
- Student-S: ResNet 6×96(또는 8×96) + 최소 gpool  
- Student-XS(옵션): depthwise-separable conv 기반(quant-ready)

---

## 4) Stage Gate (통과 조건) — “빠르게 넘어가기용”과 “강하게 증명하기용”
각 단계는 두 레벨의 게이트를 가진다.

### 4.1 Gate-Lite (개발 흐름 유지용)
- 기능: acceptance tests 통과(엔진 API / MCTS invariants / export)
- 안정성: crash/timeout/illegal move = 0
- 시간: p99 ≤ cap(30초), 평균 5초 예산에서 스파이크가 없어야 함
- 성능: baseline 대비 “명백한 비열화”가 없어야 함(예: winrate < 45%면 실패)

### 4.2 Gate-Strict (다음 단계로 넘어가기용)
- Gate-Lite 전부 +  
- 성능: baseline 대비 ΔElo가 양수(가능하면 CI 하한도 양수)  
  - 표본은 기본 400게임(최소 200) 권장
- 시간: bucket별 목표를 대체로 만족(특히 easy p50 ≤ 0.5초)

> 현실적으로, 초반에는 Gate-Lite로 개발 속도를 유지하고,  
> “다음 보드/게임으로 확장”할 때 Gate-Strict로 증명을 남기는 흐름이 가장 효율적이다.

---

## 5) 단계별 구체 계획(추천)
### Stage 0: TicTacToe
- 목적: 파이프라인/재현성/평가 자동화를 완성
- NN: Tiny(또는 Student-S 그대로) 아무거나 상관 없음
- Gate-Strict:
  - 충분한 예산(예: 0.2초)에서 최적 수를 안정적으로 선택
  - 재현성: 동일 seed에서 동일 선택

### Stage 1: Gomoku 9×9
- 목적: “CPU-only + adaptive budget policy”가 실제로 Elo를 올리는지 첫 증명
- Teacher: Teacher-S
- Student: Student-S (teacher→student distill 권장)
- 추천 루트:
  1) teacher를 짧게 부팅(강한 π_target 만들기)
  2) student distill → CPU-only 평가
  3) QUARTZ ON/OFF ablation으로 ΔElo 측정

### Stage 2: Gomoku 13×13
- 목적: 보드 크기 확장 시 ‘매번 재학습’이 얼마나 비효율적인지 측정
- Teacher: Teacher-M (또는 S에서 시작해도 됨)
- Student: Student-S
- 추천 실험(작게라도 꼭 해보기):
  - (A) from-scratch
  - (B) 9×9 체크포인트 전이(fine-tune)
  - (C) (옵션) 좌표/경계 feature 추가
- Gate-Strict: 전이(B)가 from-scratch(A)보다 “시간 대비 효율”이 나은지 판단 근거를 남긴다.

### Stage 3: Gomoku 15×15
- 목적: “실전 크기”에서 time distribution 안정성 + Elo 개선
- Teacher: Teacher-M 또는 Teacher-L(필요할 때만)
- Student: Student-S(필요하면 quant)
- 주의: 15×15는 branching/오프닝 편향이 커서 평가 프로토콜(고정 opening set)이 더 중요해진다.

### Stage 4: Renju 15×15
- 목적: 룰 제약(금수/오프닝)에서 QUARTZ가 여전히 이득인지 확인
- Teacher: Teacher-M
- Student: Student-S
- 구현 포인트:
  - legal move 생성/금수 판정 정확성 테스트 강화
  - 오프닝 규정/색상 스왑/랜덤성 고정

### Stage 5: Chess / Chess960 (가능성 실험)
- 목적: “로컬 1GPU+1CPU로 아마추어 수준까지 갈 가능성이 있나”만 판단
- Teacher: Teacher-S/M (Lc0 스타일의 SE-ResNet 계열을 참고)
- Student: Student-S
- Gate-Strict 대신 Gate-Lite+:
  - 엔진이 불법 수 없이 안정적으로 동작
  - baseline(고정 탐색) 대비 QUARTZ가 time distribution을 안정적으로 만들고,
    성능이 최소 비열화하지 않음
  - 외부 강자(Stockfish)와 정면승부는 목표 밖(가능하면 약한 레벨/짧은 시간으로만 스모크)

### Stage 6: Go 9×9
- 목적: 9×9에서 self-play/data 생성 속도와 “학습이 진짜 되는지” 확인
- Teacher: Teacher-L 권장(또는 M + gpool 강화)
- Student: Student-S
- 주의: 바둑은 ‘pass’ 처리/수읽기/가치 안정성 등 디테일이 많아 correctness 테스트가 먼저다.

### Stage 7: Go 19×19 (가능성 실험)
- 목적: 로컬 단일 GPU로 “아마추어 수준” 가능성이 있는지 탐색
- Teacher: Teacher-L(또는 더 큰 실험은 나중)
- Student: Student-S(현실적으로 CPU-only는 느릴 수 있음)
- Gate: Gate-Lite 중심(파이프라인/안정성/학습 신호 확인)

---

## 6) 보드 크기마다 재학습이 너무 비효율적일 때: “Scale invariance” 체크리스트
완전 재학습이 너무 비싸다고 판단되면, 아래 순서로 실험한다.

1) Fully-conv policy head로 통일(필수)
2) 좌표/경계 plane 추가(가성비 높음)
3) gpool/SE(전역맥락 + 채널 재가중)
4) (마지막 카드) 작은 GNN head
   - teacher에서만 먼저 시도
   - 이득이 확인될 때만 student에 극소형으로 이식

---

## 7) 권장 산출물(“다음 단계로 넘어갈 때 남길 것”)
- stage gate 리포트 1장(통과/실패, 이유, 다음 액션)
- ΔElo + CI(최소 200판, 가능하면 400판)
- 시간 분포(전체 + bucket별)
- 모델 카드(teacher/student 구조, 파라미터 수, CPU latency)
