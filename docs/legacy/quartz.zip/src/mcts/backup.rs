//! Negamax Backpropagation + Welford online variance
//!
//! 매 backup step:
//!   1. Virtual Loss 환원
//!   2. N += 1, W += value  (negamax 부호 반전)
//!   3. M2 Welford update: M2 += (value - Q_prev)(value - Q_new)
//!      → edge_sigma() = √(M2/(N-1)) = 정확한 per-edge std
//!   4. parent.n_total += 1

use std::sync::atomic::Ordering;

use crate::game::GameState;
use crate::mcts::node::{atomic_f64_add, atomic_f64_load, PathEdge};

pub fn backprop<G: GameState>(path: &[PathEdge<G::Move>], leaf_value: f32) {
    let mut value = leaf_value;

    for pe in path.iter().rev() {
        value = -value;   // negamax: 부모 관점 부호 반전

        let e = &pe.edge_arc;

        // Virtual Loss: remove the exact (vvisit, vvalue) applied during select
        let (vv, vq) = pe.applied_vl;
        e.remove_vl(vv, vq);

        // N 증가
        let n_old = e.n.fetch_add(1, Ordering::AcqRel) as f64;
        let n_new = n_old + 1.0;

        // W 갱신
        e.add_w(value);

        // Welford M2 (per-edge σᵢ for §6.1.1)
        if n_old >= 1.0 {
            let w_old   = atomic_f64_load(&e.w) as f64 - value as f64;
            let mu_old  = w_old / n_old;
            let w_new   = atomic_f64_load(&e.w) as f64;
            let mu_new  = w_new / n_new;
            let delta_m2 = (value as f64 - mu_old) * (value as f64 - mu_new);
            atomic_f64_add(&e.m2, delta_m2);
        }

        // §6.3 MERGE: 같은 엣지가 2번 이상 백업 = 여러 경로가 이 child에 수렴
        // n_old >= 1 (이번 backup 전 N이 1 이상) = 이전에도 방문됐음 = transposition
        if n_old >= 1.0 {
            e.child.record_rtt_hit(value);
        }

        pe.parent.n_total.fetch_add(1, Ordering::AcqRel);
    }
}
